import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface MealPlanSuggestion {
  mealType: "breakfast" | "lunch" | "dinner";
  recipeName: string;
  description: string;
  ingredients: string[];
  instructions: string[];
  cookTime: number;
  servings: number;
  difficulty: "Easy" | "Medium" | "Hard";
}

export interface RecipeSuggestion {
  name: string;
  description: string;
  ingredients: string[];
  instructions: string[];
  cookTime: number;
  servings: number;
  difficulty: "Easy" | "Medium" | "Hard";
  tags: string[];
}

export async function generateMealPlan(preferences: string, dietaryRestrictions: string = ""): Promise<MealPlanSuggestion[]> {
  try {
    const prompt = `Generate a daily meal plan based on these preferences: ${preferences}. 
    ${dietaryRestrictions ? `Dietary restrictions: ${dietaryRestrictions}` : ''}
    
    Provide 3 meals (breakfast, lunch, dinner) with complete recipes. Respond with JSON in this format:
    {
      "meals": [
        {
          "mealType": "breakfast|lunch|dinner",
          "recipeName": "string",
          "description": "string",
          "ingredients": ["ingredient1", "ingredient2"],
          "instructions": ["step1", "step2"],
          "cookTime": number,
          "servings": number,
          "difficulty": "Easy|Medium|Hard"
        }
      ]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a professional chef and nutritionist. Create balanced, delicious meal plans with detailed recipes."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{"meals": []}');
    return result.meals || [];
  } catch (error) {
    console.error("Failed to generate meal plan:", error);
    throw new Error("Failed to generate meal plan: " + (error as Error).message);
  }
}

export async function findRecipesByIngredients(ingredients: string[]): Promise<RecipeSuggestion[]> {
  try {
    const prompt = `Find 3 recipe suggestions using these ingredients: ${ingredients.join(', ')}. 
    
    Respond with JSON in this format:
    {
      "recipes": [
        {
          "name": "string",
          "description": "string", 
          "ingredients": ["ingredient1", "ingredient2"],
          "instructions": ["step1", "step2"],
          "cookTime": number,
          "servings": number,
          "difficulty": "Easy|Medium|Hard",
          "tags": ["tag1", "tag2"]
        }
      ]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a creative chef. Suggest recipes using the provided ingredients, adding minimal additional ingredients as needed."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{"recipes": []}');
    return result.recipes || [];
  } catch (error) {
    console.error("Failed to find recipes:", error);
    throw new Error("Failed to find recipes: " + (error as Error).message);
  }
}

export async function parseVoiceCommand(voiceText: string): Promise<{
  intent: string;
  entities: Record<string, any>;
  response: string;
}> {
  try {
    const prompt = `Parse this voice command for a cooking app: "${voiceText}"
    
    Identify the intent and extract relevant entities. Common intents include:
    - add_to_grocery_list
    - find_recipe
    - plan_meal
    - start_cooking
    - set_timer
    - next_step
    - previous_step
    
    Respond with JSON in this format:
    {
      "intent": "string",
      "entities": {
        "ingredients": ["item1", "item2"],
        "quantity": "string",
        "meal_type": "breakfast|lunch|dinner",
        "cuisine": "string",
        "time": "string"
      },
      "response": "Confirmation message for the user"
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a voice assistant for a cooking app. Parse user commands and extract cooking-related intents and entities."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{"intent": "unknown", "entities": {}, "response": "I didn\'t understand that command."}');
    return result;
  } catch (error) {
    console.error("Failed to parse voice command:", error);
    return {
      intent: "error",
      entities: {},
      response: "Sorry, I couldn't understand that command. Please try again."
    };
  }
}

export async function generateGroceryList(mealPlans: string[]): Promise<{ name: string; quantity: string; category: string }[]> {
  try {
    const prompt = `Generate a grocery list for these meals: ${mealPlans.join(', ')}
    
    Combine similar ingredients and provide reasonable quantities. Respond with JSON in this format:
    {
      "groceryList": [
        {
          "name": "string",
          "quantity": "string", 
          "category": "produce|meat|dairy|pantry|seafood|other"
        }
      ]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a meal planning assistant. Generate comprehensive grocery lists with appropriate quantities and categories."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{"groceryList": []}');
    return result.groceryList || [];
  } catch (error) {
    console.error("Failed to generate grocery list:", error);
    throw new Error("Failed to generate grocery list: " + (error as Error).message);
  }
}
