import { Request, Response, NextFunction } from 'express';

interface RateLimitStore {
  [key: string]: {
    count: number;
    resetTime: number;
  };
}

const store: RateLimitStore = {};

// Clean up old entries every 10 minutes
setInterval(() => {
  const now = Date.now();
  Object.keys(store).forEach(key => {
    if (store[key].resetTime < now) {
      delete store[key];
    }
  });
}, 10 * 60 * 1000);

export function createRateLimit(options: {
  windowMs: number;
  max: number;
  message?: string;
}) {
  return (req: Request, res: Response, next: NextFunction) => {
    try {
      // Safely get IP address
      const key = (req.ip || req.connection?.remoteAddress || req.headers['x-forwarded-for'] || 'anonymous').toString();
      const now = Date.now();
      
      if (!store[key] || store[key].resetTime < now) {
        store[key] = {
          count: 1,
          resetTime: now + options.windowMs
        };
        return next();
      }
      
      store[key].count++;
      
      if (store[key].count > options.max) {
        return res.status(429).json({
          message: options.message || 'Too many requests, please try again later.'
        });
      }
      
      next();
    } catch (error) {
      console.error('Rate limit middleware error:', error);
      next();
    }
  };
}