import { useState, useEffect } from "react";
import { useStripe, Elements, PaymentElement, useElements } from '@stripe/react-stripe-js';
import { loadStripe } from '@stripe/stripe-js';
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useSEO, pageSEO } from "@/lib/seo";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Check, Tag, Clock, AlertCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import PaymentSuccess from "@/components/payment-success";
import PaymentError from "@/components/payment-error";

// Load Stripe with robust error handling
const stripePromise = import.meta.env.VITE_STRIPE_PUBLIC_KEY 
  ? loadStripe(import.meta.env.VITE_STRIPE_PUBLIC_KEY).catch((error) => {
      console.error('Stripe loading failed:', error);
      return null;
    })
  : Promise.resolve(null);

interface SubscriptionPlan {
  id: string;
  name: string;
  description: string;
  stripePriceId: string;
  price: number;
  interval: string;
  features: string[];
  isActive: boolean;
  trialDays?: number;
  maxUsers?: number;
  currentUsers?: number;
}

interface Coupon {
  id: string;
  code: string;
  name: string;
  description: string;
  discountType: 'percentage' | 'fixed_amount';
  discountValue: number;
  minAmount: number;
}

const SubscribeForm = ({ 
  plan, 
  onSuccess, 
  onError,
  couponCode,
  appliedCoupon,
  trialDays 
}: { 
  plan: SubscriptionPlan;
  onSuccess: () => void;
  onError: (error: string, code?: string) => void;
  couponCode?: string;
  appliedCoupon?: Coupon;
  trialDays?: number;
}) => {
  const stripe = useStripe();
  const elements = useElements();
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!stripe || !elements) {
      return;
    }

    setIsLoading(true);

    try {
      const { error } = await stripe.confirmPayment({
        elements,
        confirmParams: {
          return_url: window.location.origin,
        },
      });

      if (error) {
        onError(error.message || "Subscription failed", error.code);
      } else {
        onSuccess();
      }
    } catch (err) {
      onError("An unexpected error occurred. Please try again.");
    }

    setIsLoading(false);
  };

  // Calculate final price after coupon
  const calculateFinalPrice = () => {
    if (!appliedCoupon) return plan.price;
    
    if (appliedCoupon.discountType === 'percentage') {
      return plan.price - Math.round((plan.price * appliedCoupon.discountValue) / 100);
    } else {
      return Math.max(0, plan.price - appliedCoupon.discountValue);
    }
  };

  const finalPrice = calculateFinalPrice();
  const savings = plan.price - finalPrice;

  return (
    <div className="space-y-6">
      {/* Trial Information */}
      {trialDays && trialDays > 0 && (
        <div className="bg-green-50 dark:bg-green-950 border border-green-200 dark:border-green-800 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <Clock className="h-5 w-5 text-green-600 dark:text-green-400" />
            <div>
              <h3 className="font-semibold text-green-800 dark:text-green-200">
                {trialDays}-Day Free Trial
              </h3>
              <p className="text-sm text-green-600 dark:text-green-400">
                Start your free trial today. No payment required until your trial ends.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Applied Coupon Information */}
      {appliedCoupon && (
        <div className="bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
          <div className="flex items-center space-x-2">
            <Tag className="h-5 w-5 text-blue-600 dark:text-blue-400" />
            <div>
              <h3 className="font-semibold text-blue-800 dark:text-blue-200">
                {appliedCoupon.name}
              </h3>
              <p className="text-sm text-blue-600 dark:text-blue-400">
                {appliedCoupon.description}
              </p>
              <p className="text-sm font-medium text-blue-800 dark:text-blue-200">
                Savings: ${(savings / 100).toFixed(2)}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Price Summary */}
      <div className="bg-gray-50 dark:bg-gray-900 rounded-lg p-4 space-y-2">
        <div className="flex justify-between">
          <span>Subtotal:</span>
          <span>${(plan.price / 100).toFixed(2)}</span>
        </div>
        {appliedCoupon && (
          <div className="flex justify-between text-green-600 dark:text-green-400">
            <span>Discount:</span>
            <span>-${(savings / 100).toFixed(2)}</span>
          </div>
        )}
        <hr className="border-gray-200 dark:border-gray-700" />
        <div className="flex justify-between font-semibold">
          <span>
            {trialDays && trialDays > 0 ? `After ${trialDays} days:` : 'Total:'}
          </span>
          <span>
            ${(finalPrice / 100).toFixed(2)}
            {plan.interval === "lifetime" ? " one-time" : `/${plan.interval}`}
          </span>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {(!trialDays || trialDays === 0) && <PaymentElement />}
        <Button 
          type="submit" 
          disabled={!stripe || isLoading}
          className="w-full"
        >
          {isLoading 
            ? "Processing..." 
            : trialDays && trialDays > 0 
              ? `Start ${trialDays}-Day Free Trial`
              : plan.interval === "lifetime" 
              ? `Get Lifetime Access for $${(finalPrice / 100).toFixed(2)}`
              : `Subscribe for $${(finalPrice / 100).toFixed(2)}/${plan.interval}`
          }
        </Button>
      </form>
    </div>
  );
};

const PlanCard = ({ plan, onSelect }: { plan: SubscriptionPlan; onSelect: (plan: SubscriptionPlan) => void }) => {
  return (
    <Card className={`relative cursor-pointer hover:shadow-lg transition-shadow ${
      plan.name === "Lifetime Pass" ? "border-2 border-yellow-500 shadow-lg" : ""
    }`} onClick={() => onSelect(plan)}>
      {plan.name === "Premium" && (
        <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2">
          Most Popular
        </Badge>
      )}
      {plan.name === "Lifetime Pass" && (
        <Badge className="absolute -top-2 left-1/2 transform -translate-x-1/2 bg-yellow-500 text-black">
          🎯 Best Value - Lifetime Access
        </Badge>
      )}
      {plan.name === "Lifetime Pass" && plan.maxUsers && (
        <Badge variant="outline" className="absolute -top-2 right-4 text-xs bg-red-50 border-red-200 text-red-700">
          Only {plan.maxUsers - (plan.currentUsers || 0)} left!
        </Badge>
      )}
      {plan.trialDays && plan.trialDays > 0 && (
        <Badge variant="secondary" className="absolute -top-2 right-4">
          <Clock className="h-3 w-3 mr-1" />
          {plan.trialDays} days free
        </Badge>
      )}
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          {plan.name}
          <div className="text-right">
            {plan.trialDays && plan.trialDays > 0 && (
              <div className="text-sm text-green-600 dark:text-green-400 font-medium">
                Free for {plan.trialDays} days
              </div>
            )}
            <span className="text-2xl font-bold">
              ${(plan.price / 100).toFixed(2)}
              <span className="text-sm font-normal text-muted-foreground">
                {plan.interval === "lifetime" ? " one-time" : `/${plan.interval}`}
              </span>
            </span>
          </div>
        </CardTitle>
        <CardDescription>
          {plan.description}
          {plan.name === "Lifetime Pass" && plan.maxUsers && (
            <div className="mt-2 text-sm font-medium text-orange-600 dark:text-orange-400">
              ⚡ Limited offer: Only {plan.maxUsers - (plan.currentUsers || 0)} spots remaining out of {plan.maxUsers}
            </div>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <ul className="space-y-2">
          {plan.features.map((feature, index) => (
            <li key={index} className="flex items-center">
              <Check className="h-4 w-4 text-green-500 mr-2" />
              <span className="text-sm">{feature}</span>
            </li>
          ))}
        </ul>
        <Button className="w-full mt-4">
          {plan.trialDays && plan.trialDays > 0 ? `Start ${plan.trialDays}-Day Free Trial` : `Select ${plan.name}`}
        </Button>
      </CardContent>
    </Card>
  );
};

export default function Subscribe() {
  // SEO optimization
  useSEO(pageSEO.subscribe);
  
  const [selectedPlan, setSelectedPlan] = useState<SubscriptionPlan | null>(null);
  const [clientSecret, setClientSecret] = useState("");
  const [paymentStatus, setPaymentStatus] = useState<"form" | "success" | "error">("form");
  const [paymentError, setPaymentError] = useState<{message: string; code?: string}>({message: ""});
  const [couponCode, setCouponCode] = useState("");
  const [appliedCoupon, setAppliedCoupon] = useState<Coupon | null>(null);
  const [couponError, setCouponError] = useState("");
  const [isValidatingCoupon, setIsValidatingCoupon] = useState(false);
  const [trialDays, setTrialDays] = useState<number>(0);
  const [isRetrying, setIsRetrying] = useState(false);
  const { toast } = useToast();

  const validateCoupon = async (code: string) => {
    if (!code.trim()) {
      setAppliedCoupon(null);
      setCouponError("");
      return;
    }

    setIsValidatingCoupon(true);
    setCouponError("");

    try {
      const response = await apiRequest("POST", "/api/validate-coupon", {
        code: code.trim(),
        planId: selectedPlan?.stripePriceId
      });

      const data = await response.json();
      
      if (data.valid) {
        setAppliedCoupon(data.coupon);
        setCouponError("");
        toast({
          title: "Coupon Applied!",
          description: `${data.coupon.name} has been applied to your order.`,
        });
      } else {
        setAppliedCoupon(null);
        setCouponError(data.message || "Invalid coupon code");
      }
    } catch (error) {
      setAppliedCoupon(null);
      setCouponError("Failed to validate coupon. Please try again.");
    }

    setIsValidatingCoupon(false);
  };

  const handlePaymentSuccess = () => {
    setPaymentStatus("success");
  };

  const handlePaymentError = (message: string, code?: string) => {
    setPaymentError({message, code});
    setPaymentStatus("error");
  };

  const handleRetry = async () => {
    if (!selectedPlan) return;
    
    setIsRetrying(true);
    setPaymentStatus("form");
    setClientSecret("");
    
    try {
      const response = await apiRequest("POST", "/api/create-subscription", {
        email: "dxmylesx22@gmail.com", // Development fallback
        username: "Myles Barber", 
        stripePriceId: selectedPlan.stripePriceId
      });
      
      const data = await response.json();
      
      if (data.clientSecret) {
        setClientSecret(data.clientSecret);
      } else {
        handlePaymentError("Failed to initialize subscription retry. Please refresh and try again.");
      }
    } catch (error) {
      handlePaymentError("Failed to initialize subscription retry. Please refresh and try again.");
    }
    
    setIsRetrying(false);
  };

  const handleGoBack = () => {
    setPaymentStatus("form");
    setPaymentError({message: ""});
    setSelectedPlan(null);
    setClientSecret("");
  };

  const { data: plans, isLoading: plansLoading } = useQuery<SubscriptionPlan[]>({
    queryKey: ["/api/subscription-plans"],
    queryFn: async () => {
      const response = await apiRequest("GET", "/api/subscription-plans");
      return response.json();
    },
  });

  const handlePlanSelect = async (plan: SubscriptionPlan) => {
    setSelectedPlan(plan);
    setTrialDays(plan.trialDays || 0);
    
    // Create subscription intent with trial and coupon support
    try {
      const response = await apiRequest("POST", "/api/create-subscription", {
        email: "dxmylesx22@gmail.com", // Development fallback
        username: "Myles Barber", // Development fallback
        stripePriceId: plan.stripePriceId,
        couponCode: appliedCoupon?.code,
        startFreeTrial: true
      });
      
      const data = await response.json();
      
      if (data.trialDays > 0) {
        setTrialDays(data.trialDays);
        setClientSecret(""); // No payment needed for trial
        toast({
          title: "Trial Started!",
          description: `Your ${data.trialDays}-day free trial has begun!`,
        });
      } else if (data.clientSecret) {
        setClientSecret(data.clientSecret);
      } else {
        toast({
          title: "Setup Required",
          description: data.message || "Subscription processing is not configured yet.",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to create subscription. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Show payment success screen
  if (paymentStatus === "success" && selectedPlan) {
    return (
      <PaymentSuccess 
        paymentType="subscription"
        amount={`$${(selectedPlan.price / 100).toFixed(2)}`}
        plan={selectedPlan.name}
      />
    );
  }

  // Show payment error screen
  if (paymentStatus === "error") {
    return (
      <PaymentError 
        error={paymentError.message}
        errorCode={paymentError.code}
        onRetry={handleRetry}
        onGoBack={handleGoBack}
        isRetrying={isRetrying}
      />
    );
  }

  // Check if Stripe loading failed
  const [stripeLoaded, setStripeLoaded] = useState<boolean | null>(null);
  
  useEffect(() => {
    stripePromise.then((stripe) => {
      setStripeLoaded(stripe !== null);
    });
  }, []);
  
  const showDemoMode = stripeLoaded === false;

  if (plansLoading) {
    return (
      <div className="container mx-auto py-8">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full mx-auto" />
      </div>
    );
  }

  if (selectedPlan && (clientSecret || trialDays > 0 || showDemoMode)) {
    return (
      <div className="container mx-auto py-8 max-w-2xl">
        <Card>
          <CardHeader>
            <CardTitle>
              {showDemoMode ? `Demo: ${selectedPlan.name} Plan` : trialDays > 0 ? `Start Your ${trialDays}-Day Free Trial` : 'Complete Your Subscription'}
            </CardTitle>
            <CardDescription>
              {showDemoMode 
                ? `Development mode - Stripe payment processing will be available in production`
                : trialDays > 0 
                  ? `Try ${selectedPlan.name} free for ${trialDays} days, then ${appliedCoupon ? `$${((selectedPlan.price - (appliedCoupon.discountType === 'percentage' ? Math.round((selectedPlan.price * appliedCoupon.discountValue) / 100) : appliedCoupon.discountValue)) / 100).toFixed(2)}` : `$${(selectedPlan.price / 100).toFixed(2)}`}/${selectedPlan.interval}`
                  : `Subscribe to ${selectedPlan.name} for ${appliedCoupon ? `$${((selectedPlan.price - (appliedCoupon.discountType === 'percentage' ? Math.round((selectedPlan.price * appliedCoupon.discountValue) / 100) : appliedCoupon.discountValue)) / 100).toFixed(2)}` : `$${(selectedPlan.price / 100).toFixed(2)}`}/${selectedPlan.interval}`
              }
            </CardDescription>
          </CardHeader>
          <CardContent>
            {showDemoMode ? (
              <div className="space-y-6">
                <div className="p-4 border rounded-lg bg-blue-50 dark:bg-blue-950/30">
                  <h3 className="font-semibold mb-2">Development Mode Active</h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                    Stripe payment processing is not configured. In production, users would complete their payment here.
                  </p>
                  <div className="space-y-2 text-sm">
                    <p><strong>Selected Plan:</strong> {selectedPlan.name}</p>
                    <p><strong>Price:</strong> ${(selectedPlan.price / 100).toFixed(2)}/{selectedPlan.interval}</p>
                    <p><strong>Features:</strong></p>
                    <ul className="list-disc list-inside ml-4 space-y-1">
                      {selectedPlan.features.slice(0, 5).map((feature, index) => (
                        <li key={index}>{feature}</li>
                      ))}
                    </ul>
                  </div>
                  <div className="mt-4 flex gap-2">
                    <Button 
                      onClick={() => {
                        toast({
                          title: "Demo Subscription Activated",
                          description: `${selectedPlan.name} features are now available for testing.`,
                        });
                        setSelectedPlan(null);
                      }}
                      className="bg-green-600 hover:bg-green-700"
                    >
                      Simulate Successful Payment
                    </Button>
                    <Button 
                      onClick={() => setSelectedPlan(null)}
                      variant="outline"
                    >
                      Back to Plans
                    </Button>
                  </div>
                </div>
              </div>
            ) : stripePromise ? (
              <Elements stripe={stripePromise} options={clientSecret ? { clientSecret } : undefined}>
                <SubscribeForm 
                  plan={selectedPlan}
                  onSuccess={handlePaymentSuccess}
                  onError={handlePaymentError}
                  couponCode={appliedCoupon?.code}
                  appliedCoupon={appliedCoupon || undefined}
                  trialDays={trialDays}
                />
              </Elements>
            ) : (
              <div className="text-center">
                <p className="text-gray-600 mb-4">Payment processing is being configured.</p>
                <Button onClick={() => setSelectedPlan(null)} variant="outline">
                  Back to Plans
                </Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto py-8">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-4">Choose Your Plan</h1>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Upgrade your AI cooking experience with advanced features, unlimited meal plans, and priority support.
        </p>
      </div>

      {/* Coupon Input Section */}
      <div className="max-w-md mx-auto mb-8">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center space-x-2">
              <Tag className="h-5 w-5" />
              <span>Promo Code</span>
            </CardTitle>
            <CardDescription>
              Have a promo code? Enter it here to save on your subscription.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex space-x-2">
              <Input
                placeholder="Enter promo code"
                value={couponCode}
                onChange={(e) => setCouponCode(e.target.value.toUpperCase())}
                onKeyPress={(e) => {
                  if (e.key === 'Enter') {
                    validateCoupon(couponCode);
                  }
                }}
                className={couponError ? "border-red-500" : ""}
              />
              <Button 
                onClick={() => validateCoupon(couponCode)}
                disabled={isValidatingCoupon || !couponCode.trim()}
                variant="outline"
              >
                {isValidatingCoupon ? "Checking..." : "Apply"}
              </Button>
            </div>
            {couponError && (
              <div className="flex items-center space-x-2 text-red-600 text-sm">
                <AlertCircle className="h-4 w-4" />
                <span>{couponError}</span>
              </div>
            )}
            {appliedCoupon && (
              <div className="flex items-center space-x-2 text-green-600 text-sm">
                <Check className="h-4 w-4" />
                <span>{appliedCoupon.name} applied! Save ${appliedCoupon.discountType === 'percentage' ? `${appliedCoupon.discountValue}%` : `$${(appliedCoupon.discountValue / 100).toFixed(2)}`}</span>
              </div>
            )}
            
            {/* Sample codes hint */}
            <div className="text-xs text-muted-foreground">
              <p className="font-medium mb-1">Try these codes:</p>
              <div className="flex flex-wrap gap-2">
                <code className="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">WELCOME30</code>
                <code className="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">SAVE50</code>
                <code className="bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">FIRSTTRIAL</code>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
        {plans?.map((plan) => (
          <PlanCard 
            key={plan.id} 
            plan={plan} 
            onSelect={handlePlanSelect}
          />
        ))}
      </div>

      {(!plans || plans.length === 0) && (
        <Card className="max-w-2xl mx-auto">
          <CardContent className="text-center py-8">
            <h3 className="text-lg font-semibold mb-2">No Plans Available</h3>
            <p className="text-muted-foreground">
              Subscription plans are being set up. Please check back later.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}