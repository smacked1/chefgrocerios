import { VoiceCommandPanel } from "@/components/voice-command-panel";
import { PromotionalBanner } from "@/components/promotional-banner";
import { MealPlanCard } from "@/components/meal-plan-card";
import { EnhancedGroceryList } from "@/components/enhanced-grocery-list";
import { RecipeNutritionCard } from "@/components/recipe-nutrition-card";
import { StoreFinder } from "@/components/store-finder";
import { FoodDatabaseSearch } from "@/components/food-database-search";
import USDAFoodSearch from "@/components/usda-food-search";
import SpoonacularRecipeSearch from "@/components/spoonacular-recipe-search";
import { TheMealDBRecipeSearch } from "@/components/themealdb-recipe-search";
import { DeliveryServices } from "@/components/delivery-services";
import { FloatingVoiceAssistant } from "@/components/floating-voice-assistant";
import PaymentUpgrade from "@/components/payment-upgrade";
import OneClickUpgradeCTA from "@/components/one-click-upgrade-cta";
import AdvancedSearch from "@/components/advanced-search";
import GeminiAIPanel from "@/components/gemini-ai-panel";
import { VoiceIngredientSearch } from "@/components/voice-ingredient-search";
import { AffiliateTracker } from "@/components/affiliate-tracker";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useQuery } from "@tanstack/react-query";
// import { useSEO, pageSEO } from "@/lib/seo"; // Commented out - SEO lib not found
import { MealPlan, PantryItem, Recipe } from "@shared/schema";
import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { LoadingSkeleton } from "@/components/loading-skeleton";
import { FadeIn, SlideIn, StaggerContainer, StaggerItem } from "@/components/smooth-transitions";
import { PerformanceDashboard } from "@/components/performance-dashboard";
import { SmartSearch } from "@/components/smart-search";
import { LocationSearch } from "@/components/location-search";
import PrivacyFooter from "@/components/privacy-footer";
import { 
  ShoppingCart, 
  Search, 
  CalendarX, 
  Bell, 
  Utensils,
  TriangleAlert,
  Clock,
  ArrowRight,
  MapPin,
  DollarSign,
  Activity,
  Target,
  Truck,
  ChefHat,
  LogOut
} from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  // SEO optimization - disabled for now
  // useSEO(pageSEO.home);
  
  const { user, isAuthenticated } = useAuth();
  
  const today = new Date().toISOString().split('T')[0];
  const [searchResults, setSearchResults] = useState<any[]>([]);
  
  const { data: todayMealPlans = [], isLoading: mealsLoading } = useQuery<MealPlan[]>({
    queryKey: ['/api/meal-plans', { date: today }],
    queryFn: () => fetch(`/api/meal-plans?date=${today}`).then(res => res.json()),
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 10 * 60 * 1000 // 10 minutes (renamed from cacheTime in v5)
  });

  const { data: pantryItems = [] } = useQuery<PantryItem[]>({
    queryKey: ['/api/pantry-items']
  });

  const { data: recipes = [] } = useQuery<Recipe[]>({
    queryKey: ['/api/recipes']
  });

  const lowStockItems = pantryItems.filter(item => item.status === 'low');
  const expiringItems = pantryItems.filter(item => {
    if (!item.expiryDate) return false;
    const expiry = new Date(item.expiryDate);
    const weekFromNow = new Date();
    weekFromNow.setDate(weekFromNow.getDate() + 7);
    return expiry <= weekFromNow;
  });

  if (mealsLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <LoadingSkeleton type="recipe" count={6} />
        </div>
      </div>
    );
  }

  return (
    <FadeIn className="min-h-screen bg-gray-50">
      {/* Navigation Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-orange-500 rounded-lg flex items-center justify-center">
                <Utensils className="text-white text-sm" />
              </div>
              <h1 className="text-xl font-bold text-gray-900">AI Chef</h1>
            </div>
            
            <nav className="hidden md:flex space-x-8">
              <a href="#" className="text-orange-500 font-medium">Meal Plans</a>
              <a href="#recipes" className="text-gray-600 hover:text-gray-900">Recipes</a>
              <a href="#grocery" className="text-gray-600 hover:text-gray-900">Smart Shopping</a>
              <a href="#food-database" className="text-gray-600 hover:text-gray-900">Food Database</a>
              <a href="#delivery" className="text-gray-600 hover:text-gray-900">Delivery</a>
              <a href="#stores" className="text-gray-600 hover:text-gray-900">Store Finder</a>
              <a href="/revenue-dashboard" className="text-gray-600 hover:text-gray-900">Revenue Dashboard</a>
            </nav>
            
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2 bg-blue-100 px-3 py-1 rounded-full">
                <div className="w-2 h-2 bg-blue-600 rounded-full animate-pulse"></div>
                <span className="text-blue-600 text-sm font-medium">Voice Ready</span>
              </div>
              <Button variant="ghost" size="sm">
                <Bell className="w-5 h-5 text-gray-600" />
              </Button>
              <Button 
                onClick={async () => {
                  try {
                    await fetch('/api/auth/logout', { method: 'POST' });
                    window.location.href = '/';
                  } catch (error) {
                    console.error('Logout failed:', error);
                  }
                }}
                variant="ghost" 
                size="sm"
                className="text-gray-600 hover:text-gray-800"
              >
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
              <div className="w-8 h-8 bg-green-600 rounded-full flex items-center justify-center">
                <span className="text-white text-sm font-medium">TU</span>
              </div>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Promotional Banner - Drive Revenue While Waiting for iOS */}
        <div className="mb-6">
          <PromotionalBanner 
            onSubscribeClick={() => window.location.href = '/subscribe'} 
          />
        </div>

        {/* Voice Command Section */}
        <div className="mb-8">
          <VoiceCommandPanel />
        </div>

        {/* Advanced Search Section */}
        <div className="mb-8">
          <AdvancedSearch onResultsUpdate={setSearchResults} />
        </div>

        {/* Search Results Display */}
        {searchResults.length > 0 && (
          <div className="mb-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Search className="h-5 w-5 text-orange-500" />
                  <span>Search Results ({searchResults.length})</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {searchResults.slice(0, 12).map((result, index) => (
                    <Card key={index} className="hover:shadow-md transition-shadow">
                      <CardContent className="p-4">
                        <h3 className="font-semibold text-sm mb-2 line-clamp-1">
                          {result.title || result.name || result.description}
                        </h3>
                        {result.image && (
                          <img src={result.image} alt={result.title || result.name} 
                               className="w-full h-32 object-cover rounded mb-2" />
                        )}
                        {result.readyInMinutes && (
                          <div className="flex items-center text-xs text-gray-500 mb-1">
                            <Clock className="h-3 w-3 mr-1" />
                            {result.readyInMinutes} mins
                          </div>
                        )}
                        {result.calories && (
                          <div className="text-xs text-gray-500">
                            {result.calories} calories
                          </div>
                        )}
                        {result.price && (
                          <div className="text-xs font-medium text-green-600">
                            ${result.price}
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Today's Meal Plan */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <CardTitle className="text-2xl">Today's Meal Plan</CardTitle>
                  <Button variant="ghost" className="text-orange-500 hover:text-orange-600">
                    <span className="mr-1">Edit Plan</span>
                  </Button>
                </div>
              </CardHeader>
              
              <CardContent>
                {mealsLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="animate-pulse">
                        <div className="flex items-center space-x-4 p-4 border rounded-xl">
                          <div className="w-16 h-16 bg-gray-200 rounded-lg"></div>
                          <div className="flex-1 space-y-2">
                            <div className="h-4 bg-gray-200 rounded w-1/2"></div>
                            <div className="h-3 bg-gray-200 rounded w-1/4"></div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (!todayMealPlans || todayMealPlans.length === 0) ? (
                  <div className="text-center py-12">
                    <CalendarX className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No meals planned for today</h3>
                    <p className="text-gray-500 mb-4">Use voice commands to plan your meals</p>
                    <Button className="bg-orange-500 hover:bg-orange-600 text-white">
                      Plan Today's Meals
                    </Button>
                  </div>
                ) : (
                  <div className="space-y-4">
                    {todayMealPlans.map((mealPlan: MealPlan) => (
                      <MealPlanCard key={mealPlan.id} mealPlan={mealPlan} />
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Quick Actions */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <Link href="/barcode-scanner">
                    <Button 
                      variant="ghost" 
                      className="w-full justify-start p-3 h-auto hover:bg-gray-50"
                    >
                      <div className="flex items-center space-x-3">
                        <div className="w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center">
                          📱
                        </div>
                        <div className="text-left">
                          <div className="font-medium text-gray-900">Scan Barcode</div>
                          <div className="text-xs text-gray-500">Get nutrition info</div>
                        </div>
                      </div>
                    </Button>
                  </Link>
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start p-3 h-auto hover:bg-gray-50"
                    onClick={() => document.getElementById('grocery')?.scrollIntoView({ behavior: 'smooth' })}
                  >
                    <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center mr-3">
                      <ShoppingCart className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Smart Shopping</p>
                      <p className="text-gray-600 text-sm">Prices, nutrition & savings</p>
                    </div>
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start p-3 h-auto hover:bg-gray-50"
                    onClick={() => document.getElementById('stores')?.scrollIntoView({ behavior: 'smooth' })}
                  >
                    <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                      <MapPin className="w-5 h-5 text-blue-600" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Find Stores</p>
                      <p className="text-gray-600 text-sm">Compare prices & deals</p>
                    </div>
                  </Button>
                  
                  <Button 
                    variant="ghost" 
                    className="w-full justify-start p-3 h-auto hover:bg-gray-50"
                    onClick={() => document.getElementById('recipes')?.scrollIntoView({ behavior: 'smooth' })}
                  >
                    <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center mr-3">
                      <Activity className="w-5 h-5 text-orange-600" />
                    </div>
                    <div className="text-left">
                      <p className="font-medium text-gray-900">Recipe Nutrition</p>
                      <p className="text-gray-600 text-sm">Calories & cost breakdown</p>
                    </div>
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Budget Overview */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg flex items-center space-x-2">
                  <Target className="w-5 h-5 text-green-600" />
                  <span>Budget Tracker</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Weekly Budget</span>
                    <span className="font-bold text-green-600">$150</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Spent This Week</span>
                    <span className="font-bold text-orange-600">$89.50</span>
                  </div>
                  <div className="flex justify-between items-center">
                    <span className="text-sm text-gray-600">Potential Savings</span>
                    <span className="font-bold text-blue-600">$23.40</span>     
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div className="bg-green-600 h-2 rounded-full" style={{width: '59.7%'}}></div>
                  </div>
                  <Button 
                    variant="ghost" 
                    className="w-full text-green-600 hover:text-green-700"
                    onClick={() => document.getElementById('grocery')?.scrollIntoView({ behavior: 'smooth' })}
                  >
                    View Smart Shopping Tips
                  </Button>
                </div>
              </CardContent>
            </Card>

            {/* Pantry Status */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Pantry Status</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {lowStockItems.length > 0 && (
                    <div className="flex items-center justify-between p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                      <div className="flex items-center space-x-3">
                        <TriangleAlert className="w-5 h-5 text-yellow-600" />
                        <div>
                          <p className="font-medium text-yellow-800">Low Stock</p>
                          <p className="text-yellow-600 text-sm">
                            {lowStockItems.length} items running low
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="text-yellow-600 hover:text-yellow-800">
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                  
                  {expiringItems.length > 0 && (
                    <div className="flex items-center justify-between p-3 bg-red-50 rounded-lg border border-red-200">
                      <div className="flex items-center space-x-3">
                        <Clock className="w-5 h-5 text-red-600" />
                        <div>
                          <p className="font-medium text-red-800">Expiring Soon</p>
                          <p className="text-red-600 text-sm">
                            {expiringItems.length} items expire this week
                          </p>
                        </div>
                      </div>
                      <Button variant="ghost" size="sm" className="text-red-600 hover:text-red-800">
                        <ArrowRight className="w-4 h-4" />
                      </Button>
                    </div>
                  )}
                  
                  {lowStockItems.length === 0 && expiringItems.length === 0 && (
                    <div className="text-center py-4">
                      <p className="text-gray-500">All good! Your pantry is well stocked.</p>
                    </div>
                  )}
                  
                  <Button 
                    variant="ghost" 
                    className="w-full text-blue-600 hover:text-blue-700"
                  >
                    Update Pantry Inventory
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Smart Shopping Section */}
        <div id="grocery" className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <DollarSign className="w-6 h-6 text-green-600" />
              <span>Smart Shopping</span>
            </h2>
            <Badge className="bg-green-100 text-green-700">
              Save up to 40%
            </Badge>
          </div>
          
          <EnhancedGroceryList />
        </div>

        {/* Store Finder Section */}
        <div id="stores" className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <MapPin className="w-6 h-6 text-blue-600" />
              <span>Store Finder</span>
            </h2>
            <Badge className="bg-blue-100 text-blue-700">
              Find best deals nearby
            </Badge>
          </div>
          
          <StoreFinder />
        </div>

        {/* Food Database Section */}
        <div id="food-database" className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <Search className="w-6 h-6 text-purple-600" />
              <span>Food Database</span>
            </h2>
            <Badge className="bg-purple-100 text-purple-700">
              Comprehensive nutrition data
            </Badge>
          </div>
          
          <div className="space-y-8">
            <USDAFoodSearch />
            <FoodDatabaseSearch />
          </div>
        </div>

        {/* Free Recipe Discovery Section */}
        <div id="recipes-discovery" className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <ChefHat className="w-6 h-6 text-orange-600" />
              <span>Free Recipe Discovery</span>
            </h2>
            <Badge className="bg-green-100 text-green-700">
              306+ recipes - No API key required
            </Badge>
          </div>
          
          <TheMealDBRecipeSearch />
        </div>

        {/* Gemini AI Kitchen Assistant Section */}
        <div id="ai-assistant" className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <ChefHat className="w-6 h-6 text-blue-600" />
              <span>AI Kitchen Assistant</span>
            </h2>
            <Badge className="bg-blue-100 text-blue-700">
              Free Google Gemini AI - 1,500 requests/day
            </Badge>
          </div>
          
          <GeminiAIPanel />
        </div>

        {/* Voice-Activated Ingredient Search Section */}
        <div id="voice-ingredient-search" className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <svg className="w-6 h-6 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z" />
              </svg>
              <span>Voice Ingredient Search</span>
            </h2>
            <Badge className="bg-purple-100 text-purple-700">
              AI-Powered with Gemini
            </Badge>
          </div>
          
          <VoiceIngredientSearch 
            onIngredientSelect={(ingredient) => {
              console.log("Selected ingredient:", ingredient);
            }}
          />
        </div>

        {/* Revenue Optimization Components */}
        <div id="revenue-optimization" className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <DollarSign className="w-6 h-6 text-green-600" />
              <span>Revenue Optimization</span>
            </h2>
            <Badge className="bg-green-100 text-green-700">
              Live Revenue Tracking
            </Badge>
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Affiliate Tracker */}
            <div>
              <h3 className="text-xl font-semibold mb-4">Affiliate Revenue</h3>
              <AffiliateTracker />
            </div>
            
            {/* Quick Revenue Stats */}
            <div>
              <h3 className="text-xl font-semibold mb-4">Revenue Dashboard</h3>
              <Card>
                <CardContent className="p-6">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Total Revenue Today</span>
                      <span className="text-2xl font-bold text-green-600">$127.83</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Active Subscriptions</span>
                      <span className="text-lg font-semibold">153</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Restaurant Partners</span>
                      <span className="text-lg font-semibold">23</span>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600">Premium Content Sales</span>
                      <span className="text-lg font-semibold">8</span>
                    </div>
                    <Button asChild className="w-full mt-4">
                      <a href="/revenue-dashboard">View Full Dashboard</a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>

        {/* Delivery Services Section */}
        <div id="delivery" className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <Truck className="w-6 h-6 text-red-600" />
              <span>Food Delivery</span>
            </h2>
            <Badge className="bg-red-100 text-red-700">
              DoorDash, Grubhub & more
            </Badge>
          </div>
          
          <DeliveryServices />
        </div>

        {/* Payment Upgrade Section */}
        <div className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <DollarSign className="w-6 h-6 text-green-600" />
              <span>Upgrade to Premium</span>
            </h2>
            <Badge className="bg-green-100 text-green-700">
              Unlock advanced features
            </Badge>
          </div>
          
          <PaymentUpgrade />
        </div>

        {/* Enhanced Recipe Section with Nutrition */}
        <div id="recipes" className="mt-12">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold text-gray-900 flex items-center space-x-2">
              <Activity className="w-6 h-6 text-orange-600" />
              <span>Recipes with Nutrition</span>
            </h2>
            <Button variant="ghost" className="text-orange-500 hover:text-orange-600">
              View All
            </Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {recipes.slice(0, 6).map((recipe) => (
              <RecipeNutritionCard key={recipe.id} recipe={recipe} />
            ))}
          </div>
        </div>
      </main>

      {/* Floating Voice Assistant */}
      <FloatingVoiceAssistant />
      
      {/* Floating Upgrade CTA */}
      <OneClickUpgradeCTA variant="floating" />
      
      {/* Privacy Footer */}
      <PrivacyFooter />
    </FadeIn>
  );
}
