import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Clock, Users, Heart, TrendingUp, ChefHat, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface SpoonacularRecipe {
  id: number;
  title: string;
  image: string;
  readyInMinutes: number;
  servings: number;
  aggregateLikes: number;
  healthScore: number;
  spoonacularScore: number;
  pricePerServing: number;
  vegetarian: boolean;
  vegan: boolean;
  glutenFree: boolean;
  dairyFree: boolean;
  ketogenic: boolean;
  cuisines: string[];
  dishTypes: string[];
  diets: string[];
  summary: string;
}

interface SpoonacularSearchResult {
  results: SpoonacularRecipe[];
  offset: number;
  number: number;
  totalResults: number;
}

const SpoonacularRecipeSearch: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDiet, setSelectedDiet] = useState('any');
  const [selectedCuisine, setSelectedCuisine] = useState('any');
  const [maxReadyTime, setMaxReadyTime] = useState('any');
  const [isSearching, setIsSearching] = useState(false);
  const { toast } = useToast();

  const { data: searchResults, refetch, isLoading } = useQuery({
    queryKey: ['spoonacular-recipes', searchQuery, selectedDiet, selectedCuisine, maxReadyTime],
    queryFn: async (): Promise<SpoonacularSearchResult> => {
      const params = new URLSearchParams({
        query: searchQuery,
        number: '12'
      });
      
      if (selectedDiet && selectedDiet !== 'any') params.append('diet', selectedDiet);
      if (selectedCuisine && selectedCuisine !== 'any') params.append('cuisine', selectedCuisine);
      if (maxReadyTime && maxReadyTime !== 'any') params.append('maxReadyTime', maxReadyTime);

      const response = await fetch(`/api/spoonacular/recipes/search?${params}`);
      if (!response.ok) {
        throw new Error(`Search failed: ${response.statusText}`);
      }
      return response.json();
    },
    enabled: false // Only run when manually triggered
  });

  const handleSearch = () => {
    if (!searchQuery.trim()) {
      toast({
        title: "Search Required",
        description: "Please enter a recipe search term",
        variant: "destructive"
      });
      return;
    }
    setIsSearching(true);
    refetch().finally(() => setIsSearching(false));
  };

  const handleSaveRecipe = async (recipe: SpoonacularRecipe) => {
    try {
      const response = await apiRequest('POST', `/api/spoonacular/recipes/${recipe.id}/convert`, {
        save: true
      });
      
      toast({
        title: "Recipe Saved!",
        description: `${recipe.title} has been added to your recipe collection`,
      });
    } catch (error) {
      toast({
        title: "Save Failed",
        description: "Could not save recipe to your collection",
        variant: "destructive"
      });
    }
  };

  const formatPrice = (priceInCents: number) => {
    return `$${(priceInCents / 100).toFixed(2)}`;
  };

  const stripHtml = (html: string) => {
    return html.replace(/<[^>]*>/g, '').substring(0, 150) + '...';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-4">
        <Sparkles className="h-6 w-6 text-orange-500" />
        <h2 className="text-2xl font-bold text-gray-900 dark:text-white">
          Discover Recipes from Spoonacular
        </h2>
      </div>
      
      {/* Search Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ChefHat className="h-5 w-5" />
            Recipe Search
          </CardTitle>
          <CardDescription>
            Search through 365,000+ recipes with advanced filters
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium mb-1 block">Search Query</label>
              <Input
                placeholder="e.g., chicken pasta"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              />
            </div>
            
            <div>
              <label className="text-sm font-medium mb-1 block">Diet</label>
              <Select value={selectedDiet} onValueChange={setSelectedDiet}>
                <SelectTrigger>
                  <SelectValue placeholder="Any diet" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Any diet</SelectItem>
                  <SelectItem value="vegetarian">Vegetarian</SelectItem>
                  <SelectItem value="vegan">Vegan</SelectItem>
                  <SelectItem value="ketogenic">Ketogenic</SelectItem>
                  <SelectItem value="paleo">Paleo</SelectItem>
                  <SelectItem value="gluten free">Gluten Free</SelectItem>
                  <SelectItem value="dairy free">Dairy Free</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-1 block">Cuisine</label>
              <Select value={selectedCuisine} onValueChange={setSelectedCuisine}>
                <SelectTrigger>
                  <SelectValue placeholder="Any cuisine" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Any cuisine</SelectItem>
                  <SelectItem value="italian">Italian</SelectItem>
                  <SelectItem value="chinese">Chinese</SelectItem>
                  <SelectItem value="mexican">Mexican</SelectItem>
                  <SelectItem value="indian">Indian</SelectItem>
                  <SelectItem value="mediterranean">Mediterranean</SelectItem>
                  <SelectItem value="american">American</SelectItem>
                  <SelectItem value="french">French</SelectItem>
                  <SelectItem value="thai">Thai</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium mb-1 block">Max Cook Time</label>
              <Select value={maxReadyTime} onValueChange={setMaxReadyTime}>
                <SelectTrigger>
                  <SelectValue placeholder="Any time" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="any">Any time</SelectItem>
                  <SelectItem value="30">30 minutes</SelectItem>
                  <SelectItem value="60">1 hour</SelectItem>
                  <SelectItem value="120">2 hours</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          <Button 
            onClick={handleSearch} 
            disabled={isSearching || isLoading}
            className="w-full md:w-auto"
          >
            {isSearching || isLoading ? 'Searching...' : 'Search Recipes'}
          </Button>
        </CardContent>
      </Card>

      {/* Search Results */}
      {isLoading && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: 6 }).map((_, index) => (
            <Card key={index}>
              <Skeleton className="h-48 w-full rounded-t-lg" />
              <CardContent className="p-4 space-y-2">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-1/2" />
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {searchResults && searchResults.results && (
        <div className="space-y-4">
          <div className="flex justify-between items-center">
            <h3 className="text-lg font-semibold">
              {searchResults.totalResults.toLocaleString()} recipes found
            </h3>
            <Badge variant="outline">
              Showing {searchResults.results.length} results
            </Badge>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {searchResults.results.map((recipe) => (
              <Card key={recipe.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                <div className="relative">
                  <img
                    src={recipe.image}
                    alt={recipe.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-2 right-2 flex gap-1">
                    {recipe.vegetarian && (
                      <Badge variant="secondary" className="bg-green-100 text-green-800">
                        Vegetarian
                      </Badge>
                    )}
                    {recipe.vegan && (
                      <Badge variant="secondary" className="bg-green-200 text-green-900">
                        Vegan
                      </Badge>
                    )}
                  </div>
                </div>
                
                <CardContent className="p-4">
                  <CardTitle className="text-lg mb-2 line-clamp-2">
                    {recipe.title}
                  </CardTitle>
                  
                  <CardDescription className="mb-3 line-clamp-3">
                    {stripHtml(recipe.summary || 'Delicious recipe from Spoonacular')}
                  </CardDescription>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-300 mb-3">
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {recipe.readyInMinutes} min
                    </div>
                    <div className="flex items-center gap-1">
                      <Users className="h-4 w-4" />
                      {recipe.servings} servings
                    </div>
                    <div className="flex items-center gap-1">
                      <Heart className="h-4 w-4" />
                      {recipe.aggregateLikes}
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-orange-500" />
                      <span className="text-sm font-medium">
                        Health Score: {recipe.healthScore}/100
                      </span>
                    </div>
                    <div className="text-sm font-medium text-green-600">
                      {formatPrice(recipe.pricePerServing)}/serving
                    </div>
                  </div>
                  
                  <div className="flex flex-wrap gap-1 mb-3">
                    {recipe.cuisines?.slice(0, 2).map((cuisine) => (
                      <Badge key={cuisine} variant="outline" className="text-xs">
                        {cuisine}
                      </Badge>
                    ))}
                    {recipe.dishTypes?.slice(0, 2).map((type) => (
                      <Badge key={type} variant="outline" className="text-xs">
                        {type}
                      </Badge>
                    ))}
                  </div>
                  
                  <Button
                    onClick={() => handleSaveRecipe(recipe)}
                    className="w-full"
                    variant="outline"
                  >
                    Save to My Recipes
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      )}

      {searchResults && searchResults.results.length === 0 && (
        <Card className="text-center py-8">
          <CardContent>
            <ChefHat className="h-12 w-12 mx-auto mb-4 text-gray-400" />
            <h3 className="text-lg font-semibold mb-2">No recipes found</h3>
            <p className="text-gray-600 dark:text-gray-300">
              Try adjusting your search terms or filters
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default SpoonacularRecipeSearch;