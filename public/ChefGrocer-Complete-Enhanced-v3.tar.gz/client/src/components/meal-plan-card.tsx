import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Play, Mic, Clock, Users } from "lucide-react";
import { MealPlan } from "@shared/schema";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useVoice } from "@/hooks/use-voice";
import { useToast } from "@/hooks/use-toast";

interface MealPlanCardProps {
  mealPlan: MealPlan;
}

export function MealPlanCard({ mealPlan }: MealPlanCardProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { speak } = useVoice();

  const updateMealPlanMutation = useMutation({
    mutationFn: async (updates: Partial<MealPlan>) => {
      const response = await apiRequest("PATCH", `/api/meal-plans/${mealPlan.id}`, updates);
      return await response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/meal-plans'] });
    }
  });

  const handleStartCooking = () => {
    updateMealPlanMutation.mutate({ 
      status: "cooking", 
      currentStep: 1 
    });
    
    speak(`Starting to cook ${mealPlan.recipeName}. Let me guide you through the recipe.`);
    
    toast({
      title: "Started Cooking",
      description: `Now cooking ${mealPlan.recipeName}`,
    });
  };

  const handleVoiceAssist = () => {
    const message = mealPlan.status === "cooking" 
      ? `You're currently on step ${mealPlan.currentStep} of ${mealPlan.recipeName}. Would you like me to read the next step?`
      : `Ready to start cooking ${mealPlan.recipeName}? This recipe takes about ${mealPlan.cookTime} minutes.`;
    
    speak(message);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "cooking":
        return "bg-orange-500";
      case "completed":
        return "bg-green-500";
      default:
        return "bg-blue-500";
    }
  };

  const getMealTypeTime = (mealType: string) => {
    switch (mealType) {
      case "breakfast":
        return "8:00 AM";
      case "lunch":
        return "12:30 PM";
      case "dinner":
        return "7:00 PM";
      default:
        return "";
    }
  };

  const getMealImage = (mealType: string, recipeName: string) => {
    // Return appropriate image based on meal type and recipe name
    if (recipeName.toLowerCase().includes("pancake")) {
      return "https://pixabay.com/get/gc9a0b89548e8c23a0f125938c2051cbca13d96a12fc3b73cf4c0344b5dab0d222005faa18e3895176658c2937b62e518ac45508e394be9ae3ca1c5bf3f0cb1f2_1280.jpg";
    }
    if (recipeName.toLowerCase().includes("caesar") || recipeName.toLowerCase().includes("salad")) {
      return "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120";
    }
    if (recipeName.toLowerCase().includes("salmon")) {
      return "https://images.unsplash.com/photo-1467003909585-2f8a72700288?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120";
    }
    return "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?ixlib=rb-4.0.3&auto=format&fit=crop&w=120&h=120";
  };

  return (
    <Card className={`hover:shadow-md transition-shadow ${
      mealPlan.status === "cooking" ? "border-orange-500 bg-orange-50" : ""
    }`}>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <img 
              src={getMealImage(mealPlan.mealType, mealPlan.recipeName)}
              alt={mealPlan.recipeName}
              className="w-16 h-16 rounded-lg object-cover"
            />
            <div>
              <h4 className="font-semibold text-gray-900">{mealPlan.recipeName}</h4>
              <p className="text-gray-600 text-sm capitalize">
                {mealPlan.mealType} • {getMealTypeTime(mealPlan.mealType)}
              </p>
              <div className="flex items-center space-x-2 mt-1">
                <Clock className="w-4 h-4 text-green-600" />
                <span className="text-green-600 text-sm font-medium">
                  {mealPlan.cookTime} min cook time
                </span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            {mealPlan.status === "cooking" ? (
              <Badge className={`${getStatusColor(mealPlan.status)} text-white`}>
                Step {mealPlan.currentStep} of 6
              </Badge>
            ) : (
              <Button
                onClick={handleStartCooking}
                disabled={updateMealPlanMutation.isPending}
                className="p-2 text-blue-600 hover:bg-blue-50"
                variant="ghost"
              >
                <Play className="w-4 h-4" />
              </Button>
            )}
            
            <Button
              onClick={handleVoiceAssist}
              className="p-2 text-gray-400 hover:bg-gray-50"
              variant="ghost"
            >
              <Mic className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
