import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  MapPin, 
  Navigation, 
  Clock, 
  Phone, 
  ExternalLink,
  Car,
  ShoppingCart,
  Truck,
  Star,
  DollarSign,
  Target,
  Zap
} from "lucide-react";

interface UserLocation {
  latitude: number;
  longitude: number;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
}

interface NearbyStore {
  id: string;
  name: string;
  chain: string;
  address: string;
  city: string;
  state: string;
  zipCode: string;
  phone: string;
  latitude: number;
  longitude: number;
  distance: number;
  distanceText: string;
  isOpen: boolean;
  openingHours: {
    monday: string;
    tuesday: string;
    wednesday: string;
    thursday: string;
    friday: string;
    saturday: string;
    sunday: string;
  };
  services: {
    delivery: boolean;
    curbside: boolean;
    pharmacy: boolean;
    deli: boolean;
    bakery: boolean;
    gas: boolean;
  };
  website?: string;
  storeLocatorUrl?: string;
  estimatedPricing: 'budget' | 'moderate' | 'premium';
  specialOffers?: string[];
}

const PricingBadge = ({ pricing }: { pricing: 'budget' | 'moderate' | 'premium' }) => {
  const config = {
    budget: { color: 'bg-green-500', text: 'Budget-Friendly', icon: DollarSign },
    moderate: { color: 'bg-blue-500', text: 'Moderate', icon: Target },
    premium: { color: 'bg-purple-500', text: 'Premium', icon: Star }
  };
  
  const { color, text, icon: Icon } = config[pricing];
  
  return (
    <Badge className={`${color} text-white`}>
      <Icon className="h-3 w-3 mr-1" />
      {text}
    </Badge>
  );
};

export function StoreLocator() {
  const [userLocation, setUserLocation] = useState<UserLocation | null>(null);
  const [locationError, setLocationError] = useState<string>("");
  const [searchRadius, setSearchRadius] = useState<number>(10);
  const [storeFilter, setStoreFilter] = useState<string>("");
  const { toast } = useToast();

  // Get user's current location
  const requestLocation = () => {
    if (!navigator.geolocation) {
      setLocationError("Geolocation is not supported by this browser.");
      return;
    }

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const location: UserLocation = {
          latitude: position.coords.latitude,
          longitude: position.coords.longitude
        };
        
        try {
          // Reverse geocode to get address
          const response = await apiRequest("POST", "/api/location/reverse-geocode", {
            latitude: location.latitude,
            longitude: location.longitude
          });
          const addressData = await response.json();
          
          setUserLocation({
            ...location,
            ...addressData
          });
          
          toast({
            title: "Location Found",
            description: `Found stores near ${addressData.city || 'your location'}`,
          });
        } catch (error) {
          setUserLocation(location);
          toast({
            title: "Location Found",
            description: "Location acquired, searching for nearby stores...",
          });
        }
      },
      (error) => {
        let errorMessage = "Unable to get your location.";
        switch (error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = "Location access denied. Please enable location permissions.";
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = "Location information unavailable.";
            break;
          case error.TIMEOUT:
            errorMessage = "Location request timed out.";
            break;
        }
        setLocationError(errorMessage);
        toast({
          title: "Location Error",
          description: errorMessage,
          variant: "destructive"
        });
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 300000 // Cache for 5 minutes
      }
    );
  };

  // Query nearby stores
  const { data: nearbyStores = [], isLoading: storesLoading, refetch: refetchStores } = useQuery<NearbyStore[]>({
    queryKey: ['/api/stores/nearby', userLocation, searchRadius, storeFilter],
    queryFn: async () => {
      if (!userLocation) return [];
      
      const response = await apiRequest("POST", "/api/stores/find-nearby", {
        userLocation,
        radiusMiles: searchRadius,
        storeFilter: storeFilter || undefined
      });
      return await response.json();
    },
    enabled: !!userLocation
  });

  const openGoogleMaps = (store: NearbyStore) => {
    const address = encodeURIComponent(`${store.address}, ${store.city}, ${store.state} ${store.zipCode}`);
    window.open(`https://www.google.com/maps/search/?api=1&query=${address}`, '_blank');
  };

  const getDirections = (store: NearbyStore) => {
    if (userLocation) {
      const origin = `${userLocation.latitude},${userLocation.longitude}`;
      const destination = encodeURIComponent(`${store.address}, ${store.city}, ${store.state} ${store.zipCode}`);
      window.open(`https://www.google.com/maps/dir/${origin}/${destination}`, '_blank');
    }
  };

  const getTodayHours = (store: NearbyStore): string => {
    const today = new Date();
    const dayNames = ['sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday'];
    const todayKey = dayNames[today.getDay()] as keyof typeof store.openingHours;
    return store.openingHours[todayKey];
  };

  useEffect(() => {
    // Auto-request location on component mount
    requestLocation();
  }, []);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            Find Nearby Stores
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center gap-4">
            <Button onClick={requestLocation} variant="outline" className="flex items-center gap-2">
              <Navigation className="h-4 w-4" />
              Get My Location
            </Button>
            
            {userLocation && (
              <Badge variant="secondary" className="flex items-center gap-1">
                <MapPin className="h-3 w-3" />
                {userLocation.city}, {userLocation.state}
              </Badge>
            )}
          </div>

          {locationError && (
            <div className="text-red-600 text-sm">
              {locationError}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium">Search Radius (miles)</label>
              <Input
                type="number"
                value={searchRadius}
                onChange={(e) => setSearchRadius(Number(e.target.value))}
                min={1}
                max={50}
                className="mt-1"
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Filter by Store</label>
              <Input
                placeholder="e.g., Walmart, Target, ALDI"
                value={storeFilter}
                onChange={(e) => setStoreFilter(e.target.value)}
                className="mt-1"
              />
            </div>
          </div>

          {userLocation && (
            <Button onClick={() => refetchStores()} disabled={storesLoading}>
              {storesLoading ? "Searching..." : "Refresh Stores"}
            </Button>
          )}
        </CardContent>
      </Card>

      {/* Store Results */}
      {nearbyStores.length > 0 && (
        <div className="space-y-4">
          <h3 className="text-lg font-semibold">
            Found {nearbyStores.length} stores near you
          </h3>
          
          {nearbyStores.map((store) => (
            <Card key={store.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="text-lg font-semibold">{store.name}</h4>
                    <p className="text-gray-600">{store.chain}</p>
                    <p className="text-sm text-gray-500">
                      {store.address}, {store.city}, {store.state} {store.zipCode}
                    </p>
                  </div>
                  
                  <div className="text-right space-y-2">
                    <Badge variant={store.isOpen ? "default" : "destructive"}>
                      {store.isOpen ? "Open" : "Closed"}
                    </Badge>
                    <PricingBadge pricing={store.estimatedPricing} />
                    <p className="text-sm font-medium">{store.distanceText}</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <div className="flex items-center gap-2 text-sm">
                      <Clock className="h-4 w-4" />
                      <span>Today: {getTodayHours(store)}</span>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4" />
                      <span>{store.phone}</span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex flex-wrap gap-2">
                      {store.services.delivery && (
                        <Badge variant="outline">
                          <Truck className="h-3 w-3 mr-1" />
                          Delivery
                        </Badge>
                      )}
                      {store.services.curbside && (
                        <Badge variant="outline">
                          <Car className="h-3 w-3 mr-1" />
                          Curbside
                        </Badge>
                      )}
                      {store.services.pharmacy && (
                        <Badge variant="outline">
                          <Zap className="h-3 w-3 mr-1" />
                          Pharmacy
                        </Badge>
                      )}
                    </div>
                  </div>
                </div>

                {store.specialOffers && store.specialOffers.length > 0 && (
                  <div className="mb-4">
                    <p className="text-sm font-medium mb-2">Special Offers:</p>
                    <div className="flex flex-wrap gap-2">
                      {store.specialOffers.map((offer, index) => (
                        <Badge key={index} variant="secondary" className="text-xs">
                          {offer}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                <div className="flex gap-2">
                  <Button 
                    size="sm" 
                    onClick={() => getDirections(store)}
                    className="flex items-center gap-1"
                  >
                    <Navigation className="h-3 w-3" />
                    Directions
                  </Button>
                  
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => openGoogleMaps(store)}
                    className="flex items-center gap-1"
                  >
                    <MapPin className="h-3 w-3" />
                    View on Map
                  </Button>
                  
                  {store.website && (
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => window.open(store.website, '_blank')}
                      className="flex items-center gap-1"
                    >
                      <ExternalLink className="h-3 w-3" />
                      Website
                    </Button>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {userLocation && nearbyStores.length === 0 && !storesLoading && (
        <Card>
          <CardContent className="text-center py-8">
            <p className="text-gray-500">
              No stores found within {searchRadius} miles. Try increasing the search radius.
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}