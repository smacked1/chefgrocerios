import { useEffect, useState } from "react";
import { Badge } from "@/components/ui/badge";
import { AlertCircle, CheckCircle, Wifi, WifiOff } from "lucide-react";

interface PerformanceMetrics {
  loadTime: number;
  networkStatus: 'online' | 'offline';
  apiResponseTimes: Record<string, number>;
  memoryUsage?: number;
}

export function PerformanceMonitor() {
  const [metrics, setMetrics] = useState<PerformanceMetrics>({
    loadTime: 0,
    networkStatus: 'online',
    apiResponseTimes: {}
  });
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    // Monitor network status
    const updateNetworkStatus = () => {
      setMetrics(prev => ({
        ...prev,
        networkStatus: navigator.onLine ? 'online' : 'offline'
      }));
    };

    // Initial load time
    if (window.performance) {
      const loadTime = Math.round(window.performance.now());
      setMetrics(prev => ({ ...prev, loadTime }));
    }

    // Network status listeners
    window.addEventListener('online', updateNetworkStatus);
    window.addEventListener('offline', updateNetworkStatus);

    // Show monitor only in development
    if (import.meta.env.DEV) {
      setIsVisible(true);
    }

    return () => {
      window.removeEventListener('online', updateNetworkStatus);
      window.removeEventListener('offline', updateNetworkStatus);
    };
  }, []);

  if (!isVisible) return null;

  return (
    <div className="fixed bottom-4 right-4 z-50 bg-white border rounded-lg shadow-lg p-3 text-sm">
      <div className="flex items-center gap-2 mb-2">
        <Badge variant="outline" className="text-xs">
          Performance Monitor
        </Badge>
      </div>
      
      <div className="space-y-1 text-xs">
        <div className="flex items-center justify-between gap-2">
          <span>Load Time:</span>
          <Badge variant={metrics.loadTime < 1000 ? "default" : "destructive"}>
            {metrics.loadTime}ms
          </Badge>
        </div>
        
        <div className="flex items-center justify-between gap-2">
          <span>Network:</span>
          <div className="flex items-center gap-1">
            {metrics.networkStatus === 'online' ? (
              <>
                <Wifi className="h-3 w-3 text-green-500" />
                <span className="text-green-500">Online</span>
              </>
            ) : (
              <>
                <WifiOff className="h-3 w-3 text-red-500" />
                <span className="text-red-500">Offline</span>
              </>
            )}
          </div>
        </div>
        
        <div className="flex items-center justify-between gap-2">
          <span>Status:</span>
          <div className="flex items-center gap-1">
            <CheckCircle className="h-3 w-3 text-green-500" />
            <span className="text-green-500">Optimized</span>
          </div>
        </div>
      </div>
    </div>
  );
}