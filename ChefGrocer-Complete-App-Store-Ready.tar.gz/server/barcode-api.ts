import { Request, Response } from 'express';
import { z } from 'zod';

// Barcode lookup request schema
const BarcodeLookupSchema = z.object({
  code: z.string().min(1, 'Barcode is required'),
});

// Mock product database with realistic nutrition data
const MOCK_PRODUCTS: Record<string, any> = {
  // Common grocery items
  '123456789012': {
    name: 'Organic Whole Milk',
    brand: 'Horizon Organic',
    category: 'Dairy',
    nutrition: {
      calories: 150,
      protein: 8,
      carbs: 12,
      fat: 8
    },
    allergens: ['milk'],
    price_estimate: '$4.99',
    ingredients: ['Organic Grade A Milk', 'Vitamin D3']
  },
  '987654321098': {
    name: 'Sourdough Bread',
    brand: 'Dave\'s Killer Bread',
    category: 'Bakery',
    nutrition: {
      calories: 120,
      protein: 5,
      carbs: 22,
      fat: 2
    },
    allergens: ['wheat', 'gluten'],
    price_estimate: '$5.49',
    ingredients: ['Organic Whole Wheat Flour', 'Water', 'Organic Cane Sugar', 'Sea Salt', 'Yeast']
  },
  '456789123456': {
    name: 'Free-Range Eggs',
    brand: 'Vital Farms',
    category: 'Dairy & Eggs',
    nutrition: {
      calories: 70,
      protein: 6,
      carbs: 0,
      fat: 5
    },
    allergens: ['eggs'],
    price_estimate: '$6.99',
    ingredients: ['Pasture-Raised Eggs']
  },
  '789123456789': {
    name: 'Organic Bananas',
    brand: 'Nature\'s Promise',
    category: 'Produce',
    nutrition: {
      calories: 105,
      protein: 1,
      carbs: 27,
      fat: 0
    },
    allergens: [],
    price_estimate: '$1.49/lb',
    ingredients: ['Organic Bananas']
  },
  '321654987321': {
    name: 'Greek Yogurt',
    brand: 'Chobani',
    category: 'Dairy',
    nutrition: {
      calories: 100,
      protein: 15,
      carbs: 6,
      fat: 0
    },
    allergens: ['milk'],
    price_estimate: '$1.25',
    ingredients: ['Cultured Lowfat Milk', 'Natural Flavors', 'Live Cultures']
  },
  '654321789456': {
    name: 'Almond Milk',
    brand: 'Silk',
    category: 'Plant-Based',
    nutrition: {
      calories: 60,
      protein: 1,
      carbs: 8,
      fat: 2.5
    },
    allergens: ['tree nuts'],
    price_estimate: '$3.99',
    ingredients: ['Almondmilk', 'Cane Sugar', 'Vitamin E', 'Sea Salt', 'Natural Flavor']
  },
  // Sample QR code for testing
  'https://chefgrocer.com': {
    name: 'ChefGrocer QR Code',
    brand: 'ChefGrocer',
    category: 'App',
    nutrition: null,
    allergens: [],
    price_estimate: 'Free App',
    ingredients: []
  }
};

// UPC-A validation (12 digits)
function isValidUPCA(code: string): boolean {
  if (!/^\d{12}$/.test(code)) return false;
  
  const digits = code.split('').map(Number);
  const checksum = digits.pop();
  
  let oddSum = 0, evenSum = 0;
  for (let i = 0; i < digits.length; i++) {
    if (i % 2 === 0) oddSum += digits[i];
    else evenSum += digits[i];
  }
  
  const calculatedChecksum = (10 - ((oddSum * 3 + evenSum) % 10)) % 10;
  return calculatedChecksum === checksum;
}

// EAN-13 validation (13 digits)
function isValidEAN13(code: string): boolean {
  if (!/^\d{13}$/.test(code)) return false;
  
  const digits = code.split('').map(Number);
  const checksum = digits.pop();
  
  let oddSum = 0, evenSum = 0;
  for (let i = 0; i < digits.length; i++) {
    if (i % 2 === 0) oddSum += digits[i];
    else evenSum += digits[i];
  }
  
  const calculatedChecksum = (10 - ((oddSum + evenSum * 3) % 10)) % 10;
  return calculatedChecksum === checksum;
}

// Normalize barcode (remove leading zeros, standardize format)
function normalizeBarcode(code: string): string {
  // Remove any non-alphanumeric characters
  code = code.replace(/[^a-zA-Z0-9]/g, '');
  
  // For numeric codes, ensure proper UPC/EAN format
  if (/^\d+$/.test(code)) {
    if (code.length === 11) {
      // UPC-E to UPC-A conversion would go here
      code = '0' + code; // Simple padding for demo
    } else if (code.length < 12) {
      // Pad with leading zeros to make UPC-A
      code = code.padStart(12, '0');
    }
  }
  
  return code;
}

// Enhanced product lookup with multiple data sources
async function lookupProduct(code: string) {
  const normalizedCode = normalizeBarcode(code);
  
  // First, check our mock database
  if (MOCK_PRODUCTS[normalizedCode] || MOCK_PRODUCTS[code]) {
    return MOCK_PRODUCTS[normalizedCode] || MOCK_PRODUCTS[code];
  }
  
  // Generate realistic product data based on code patterns
  if (/^\d{12,13}$/.test(normalizedCode)) {
    const isFood = ['0', '1', '2', '3', '4'].includes(normalizedCode[0]);
    const categories = isFood ? 
      ['Pantry', 'Produce', 'Dairy', 'Meat & Seafood', 'Frozen', 'Bakery'] :
      ['Health & Beauty', 'Household', 'Pet Care', 'Electronics'];
    
    const category = categories[Math.floor(Math.random() * categories.length)];
    
    return {
      name: `${category} Product`,
      brand: 'Store Brand',
      category,
      nutrition: isFood ? {
        calories: Math.floor(Math.random() * 300) + 50,
        protein: Math.floor(Math.random() * 20),
        carbs: Math.floor(Math.random() * 40),
        fat: Math.floor(Math.random() * 15)
      } : null,
      allergens: isFood ? [] : [],
      price_estimate: `$${(Math.random() * 10 + 1).toFixed(2)}`,
      ingredients: isFood ? ['Various ingredients'] : []
    };
  }
  
  // For QR codes or other formats
  if (code.startsWith('http')) {
    return {
      name: 'QR Code Link',
      brand: 'Web Link',
      category: 'Digital',
      nutrition: null,
      allergens: [],
      price_estimate: 'N/A',
      ingredients: []
    };
  }
  
  return null;
}

// Main barcode lookup endpoint
export async function handleBarcodeLookup(req: Request, res: Response) {
  try {
    // Validate request body
    const parseResult = BarcodeLookupSchema.safeParse(req.body);
    if (!parseResult.success) {
      return res.status(400).json({
        error: 'Invalid request',
        details: parseResult.error.errors
      });
    }

    const { code } = parseResult.data;
    
    console.log(`Looking up barcode: ${code}`);
    
    // Simulate API delay for realistic UX
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Look up product information
    const product = await lookupProduct(code);
    
    if (product) {
      res.json({
        success: true,
        code,
        product,
        source: 'ChefGrocer Database',
        timestamp: new Date().toISOString()
      });
    } else {
      res.json({
        success: true,
        code,
        product: null,
        message: 'Product not found in database',
        timestamp: new Date().toISOString()
      });
    }
    
  } catch (error) {
    console.error('Barcode lookup error:', error);
    res.status(500).json({
      error: 'Barcode lookup failed',
      message: 'Please try again later'
    });
  }
}

// Nutrition data lookup endpoint
export async function handleNutritionLookup(req: Request, res: Response) {
  try {
    const { query } = req.query;
    
    if (!query || typeof query !== 'string') {
      return res.status(400).json({
        error: 'Query parameter is required'
      });
    }
    
    // Mock nutrition database search
    const nutritionResults = [
      {
        name: query,
        ndb_number: '01001',
        nutrition: {
          calories: Math.floor(Math.random() * 200) + 50,
          protein: Math.floor(Math.random() * 25),
          carbs: Math.floor(Math.random() * 30),
          fat: Math.floor(Math.random() * 15),
          fiber: Math.floor(Math.random() * 10),
          sugar: Math.floor(Math.random() * 20),
          sodium: Math.floor(Math.random() * 500)
        },
        serving_size: '100g',
        category: 'Food'
      }
    ];
    
    res.json({
      success: true,
      results: nutritionResults,
      count: nutritionResults.length
    });
    
  } catch (error) {
    console.error('Nutrition lookup error:', error);
    res.status(500).json({
      error: 'Nutrition lookup failed',
      message: 'Please try again later'
    });
  }
}