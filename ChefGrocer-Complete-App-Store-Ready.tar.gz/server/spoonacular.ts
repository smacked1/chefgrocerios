// Spoonacular API integration for enhanced recipe and nutrition features
const SPOONACULAR_BASE_URL = 'https://api.spoonacular.com';
const API_KEY = process.env.SPOONACULAR_API_KEY;

if (!API_KEY) {
  console.warn('SPOONACULAR_API_KEY not found. Recipe features will use fallback data.');
}

interface SpoonacularRecipe {
  id: number;
  title: string;
  image: string;
  readyInMinutes: number;
  servings: number;
  summary: string;
  instructions: string;
  extendedIngredients: Array<{
    id: number;
    name: string;
    amount: number;
    unit: string;
    originalString: string;
  }>;
  nutrition?: {
    calories: number;
    protein: string;
    fat: string;
    carbohydrates: string;
  };
}

interface SpoonacularNutrition {
  calories: number;
  protein: string;
  fat: string;
  carbohydrates: string;
  fiber: string;
  sugar: string;
  sodium: string;
}

export class SpoonacularService {
  private async makeRequest(endpoint: string, params: Record<string, any> = {}) {
    if (!API_KEY) {
      throw new Error('Spoonacular API key not configured');
    }

    const url = new URL(`${SPOONACULAR_BASE_URL}${endpoint}`);
    url.searchParams.append('apiKey', API_KEY);
    
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        url.searchParams.append(key, value.toString());
      }
    });

    const response = await fetch(url.toString());
    
    if (!response.ok) {
      throw new Error(`Spoonacular API error: ${response.status} ${response.statusText}`);
    }
    
    return await response.json();
  }

  async searchRecipes(query: string, options: {
    diet?: string;
    intolerances?: string;
    type?: string;
    number?: number;
    offset?: number;
  } = {}) {
    const params = {
      query,
      number: options.number || 12,
      offset: options.offset || 0,
      addRecipeInformation: true,
      addRecipeNutrition: true,
      fillIngredients: true,
      ...options
    };

    return await this.makeRequest('/recipes/complexSearch', params);
  }

  async getRecipeInformation(id: number) {
    const params = {
      includeNutrition: true
    };

    return await this.makeRequest(`/recipes/${id}/information`, params);
  }

  async searchRecipesByIngredients(ingredients: string[], options: {
    number?: number;
    ranking?: number;
    ignorePantry?: boolean;
  } = {}) {
    const params = {
      ingredients: ingredients.join(','),
      number: options.number || 12,
      ranking: options.ranking || 1,
      ignorePantry: options.ignorePantry || true
    };

    return await this.makeRequest('/recipes/findByIngredients', params);
  }

  async getRandomRecipes(options: {
    limitLicense?: boolean;
    tags?: string;
    number?: number;
  } = {}) {
    const params = {
      limitLicense: options.limitLicense || false,
      number: options.number || 6,
      ...options
    };

    return await this.makeRequest('/recipes/random', params);
  }

  async getNutritionByIngredients(ingredients: string[], servings: number = 1) {
    const params = {
      ingredientList: ingredients.join('\n'),
      servings,
      includeNutrition: true
    };

    return await this.makeRequest('/recipes/parseIngredients', params);
  }

  async getMealPlan(options: {
    timeFrame: 'day' | 'week';
    targetCalories?: number;
    diet?: string;
    exclude?: string;
  }) {
    const params = {
      timeFrame: options.timeFrame,
      targetCalories: options.targetCalories || 2000,
      ...options
    };

    return await this.makeRequest('/mealplanner/generate', params);
  }

  async autocompleteIngredient(query: string, number: number = 10) {
    const params = {
      query,
      number,
      metaInformation: true
    };

    return await this.makeRequest('/food/ingredients/autocomplete', params);
  }

  async getIngredientInformation(id: number, amount: number = 1, unit: string = 'serving') {
    const params = {
      amount,
      unit
    };

    return await this.makeRequest(`/food/ingredients/${id}/information`, params);
  }

  async searchGroceryProducts(query: string, options: {
    minCalories?: number;
    maxCalories?: number;
    minProtein?: number;
    maxProtein?: number;
    number?: number;
    offset?: number;
  } = {}) {
    const params = {
      query,
      number: options.number || 25,
      offset: options.offset || 0,
      ...options
    };

    return await this.makeRequest('/food/products/search', params);
  }

  async getProductInformation(id: number) {
    return await this.makeRequest(`/food/products/${id}`);
  }

  // Wine pairing functionality
  async getWinePairing(food: string) {
    const params = { food };
    return await this.makeRequest('/food/wine/pairing', params);
  }

  // Recipe cost estimation
  async getRecipePriceBreakdown(id: number) {
    return await this.makeRequest(`/recipes/${id}/priceBreakdownWidget.json`);
  }

  // Convert between units
  async convertAmounts(ingredientName: string, sourceAmount: number, sourceUnit: string, targetUnit: string) {
    const params = {
      ingredientName,
      sourceAmount,
      sourceUnit,
      targetUnit
    };

    return await this.makeRequest('/recipes/convert', params);
  }

  // Recipe analysis for dietary restrictions
  async analyzeRecipe(recipe: { title: string; servings: number; ingredients: string[]; instructions: string }) {
    const params = {
      title: recipe.title,
      servings: recipe.servings,
      ingredients: recipe.ingredients.join('\n'),
      instructions: recipe.instructions
    };

    return await this.makeRequest('/recipes/analyze', params);
  }

  // Substitute ingredients
  async getSubstituteIngredient(ingredientName: string) {
    const params = { ingredientName };
    return await this.makeRequest('/food/ingredients/substitutes', params);
  }

  // Taste profile analysis
  async getTasteProfile(id: number) {
    return await this.makeRequest(`/recipes/${id}/tasteWidget.json`);
  }
}

export const spoonacularService = new SpoonacularService();