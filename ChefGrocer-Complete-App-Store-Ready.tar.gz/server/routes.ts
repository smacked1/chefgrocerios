import type { Express } from "express";
import { createServer, type Server } from "http";
import session from "express-session";
import Stripe from "stripe";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { usdaService } from "./services/usda-api";
import { freeRecipeService } from "./services/free-recipe-api";
import { TheMealDBAPI } from "./services/themealdb-api";
import GeminiAIService from "./services/gemini-ai";
import { spoonacularService } from "./spoonacular";
import { insertRecipeSchema, insertMealPlanSchema, insertGroceryItemSchema, insertPantryItemSchema, insertStoreSchema, insertShoppingTipSchema, insertFoodDatabaseSchema, insertDeliveryServiceSchema, insertRestaurantMenuItemSchema, insertUserSchema, insertSubscriptionPlanSchema, insertPaymentTransactionSchema, insertPremiumMealPlanSchema, insertCouponSchema, insertUserCouponSchema } from "@shared/schema";
// import { generateMealPlan, findRecipesByIngredients, parseVoiceCommand, generateGroceryList } from "./services/openai";
import { getPriceComparison, getNutritionInfo, generateShoppingTips, calculateRecipeNutrition } from "./services/shopping";
import { searchFoodDatabase, findDeliveryOptions, getDetailedNutrition, findSimilarFoods } from "./services/food-database";
import { handleBarcodeLookup, handleNutritionLookup } from "./barcode-api";
import { createRateLimit } from "./middleware/rate-limit";
import { validateBody, validateQuery } from "./middleware/validation";
import { getStoresByChain, searchStoresByName, reverseGeocode, getUserLocationSchema } from "./services/location-store-finder";
import { z } from "zod";

// Distance calculation function (Haversine formula)
function calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // Earth's radius in kilometers
  const dLat = (lat2 - lat1) * Math.PI / 180;
  const dLon = (lon2 - lon1) * Math.PI / 180;
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLon/2) * Math.sin(dLon/2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  return R * c; // Distance in kilometers
}

// Initialize Stripe (only if keys are provided)
let stripe: Stripe | null = null;
if (process.env.STRIPE_SECRET_KEY) {
  stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
    apiVersion: "2025-07-30.basil",
  });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Development authentication setup - simplified for testing
  console.log('🔧 Setting up development authentication...');
  
  // Basic session setup for development testing
  app.use(session({
    secret: process.env.SESSION_SECRET || 'development-secret-key',
    resave: false,
    saveUninitialized: true,
    cookie: {
      httpOnly: true,
      secure: false, // Allow HTTP in development
      maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
  }));
  
  // Initialize passport for proper authentication
  const passport = (await import('passport')).default;
  app.use(passport.initialize());
  app.use(passport.session());
  
  // Development user serialization
  passport.serializeUser((user: any, done: any) => done(null, user));
  passport.deserializeUser((user: any, done: any) => done(null, user));
  
  console.log('✅ Development session initialized');

  // Rate limiting middleware
  const generalRateLimit = createRateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // 100 requests per window
    message: "Too many requests from this IP, please try again later."
  });
  
  const strictRateLimit = createRateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 20, // 20 requests per window for AI endpoints
    message: "Rate limit exceeded for AI endpoints. Please try again later."
  });

  // Apply general rate limiting to all API routes
  app.use('/api/', generalRateLimit);

  // Development auth routes
  app.get('/api/auth/user', async (req: any, res) => {
    try {
      // Check if user is already "logged in" via session
      if (req.session && req.session.userId) {
        const mockUser = {
          id: req.session.userId,
          email: 'test@chefgrocer.com',
          firstName: 'Test',
          lastName: 'User',
          profileImageUrl: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face',
          subscriptionPlan: 'premium',
          subscriptionStatus: 'active',
          createdAt: new Date(),
          updatedAt: new Date()
        };
        res.json(mockUser);
        return;
      }
      
      // Not logged in
      res.json(null);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Development login endpoint - simulate authentication
  app.post('/api/auth/login', async (req: any, res) => {
    try {
      // Simulate successful login
      req.session.userId = 'dev-user-123';
      req.session.save((err: any) => {
        if (err) {
          console.error('Session save error:', err);
          return res.status(500).json({ message: 'Login failed' });
        }
        res.json({ message: 'Login successful', redirectTo: '/' });
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(500).json({ message: "Login failed" });
    }
  });

  // Development logout endpoint
  app.post('/api/auth/logout', async (req: any, res) => {
    try {
      req.session.destroy((err: any) => {
        if (err) {
          console.error('Session destroy error:', err);
          return res.status(500).json({ message: 'Logout failed' });
        }
        res.clearCookie('connect.sid');
        res.json({ message: 'Logout successful', redirectTo: '/' });
      });
    } catch (error) {
      console.error("Logout error:", error);
      res.status(500).json({ message: "Logout failed" });
    }
  });

  // Restaurant Partnership endpoint
  app.post('/api/restaurant-partnerships', generalRateLimit, async (req, res) => {
    try {
      const partnership = req.body;
      
      // In production, this would save to database and trigger email notifications
      console.log("New restaurant partnership application:", partnership);
      
      res.json({ 
        success: true, 
        message: "Partnership application submitted successfully",
        applicationId: `RP-${Date.now()}`
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to submit partnership application" });
    }
  });

  // Stripe subscription creation endpoint - authentication required
  app.post('/api/create-subscription', isAuthenticated, async (req, res) => {
    if (!stripe) {
      return res.status(500).json({ message: "Stripe not configured" });
    }

    try {
      const { planId, priceId } = req.body;
      const userId = (req.user as any)?.claims?.sub;
      const userEmail = (req.user as any)?.claims?.email;

      if (!userEmail) {
        return res.status(400).json({ message: "User email required" });
      }

      // Create or retrieve Stripe customer
      let customer;
      try {
        const customers = await stripe.customers.list({
          email: userEmail,
          limit: 1
        });
        
        if (customers.data.length > 0) {
          customer = customers.data[0];
        } else {
          customer = await stripe.customers.create({
            email: userEmail,
            metadata: {
              userId: userId
            }
          });
        }
      } catch (error) {
        console.error("Error creating customer:", error);
        return res.status(500).json({ message: "Failed to create customer" });
      }

      // Create subscription
      const subscription = await stripe.subscriptions.create({
        customer: customer.id,
        items: [{
          price_data: {
            currency: 'usd',
            product_data: {
              name: `ChefGrocer ${planId} Plan`,
            },
            unit_amount: planId === 'premium' ? 499 : planId === 'pro' ? 999 : planId === 'lifetime' ? 9999 : 0,
            ...(planId !== 'lifetime' && {
              recurring: {
                interval: 'month',
              },
            }),
          },
        }],
        payment_behavior: 'default_incomplete',
        payment_settings: { save_default_payment_method: 'on_subscription' },
        expand: ['latest_invoice.payment_intent'],
      });

      res.json({
        subscriptionId: subscription.id,
        clientSecret: (subscription.latest_invoice as any)?.payment_intent?.client_secret,
      });
    } catch (error) {
      console.error("Subscription creation error:", error);
      res.status(500).json({ message: "Failed to create subscription" });
    }
  });

  // Premium Content Purchase endpoint
  app.post('/api/premium-content/purchase', isAuthenticated, async (req, res) => {
    try {
      const { contentId } = req.body;
      const userId = (req.user as any)?.claims?.sub;
      
      // In production, this would process payment and grant access
      console.log("Premium content purchase:", { userId, contentId });
      
      res.json({ 
        success: true, 
        message: "Premium content purchased successfully",
        purchaseId: `PC-${Date.now()}`
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to process purchase" });
    }
  });

  // Location-based store finder endpoints
  app.post('/api/stores/find-nearby', async (req, res) => {
    try {
      const { userLocation, radiusMiles = 10, storeFilter } = req.body;
      
      if (!userLocation || !userLocation.latitude || !userLocation.longitude) {
        return res.status(400).json({ 
          message: "User location with latitude and longitude is required" 
        });
      }

      let stores;
      if (storeFilter) {
        stores = await searchStoresByName(storeFilter, userLocation);
      } else {
        stores = await findNearbyStores(userLocation, radiusMiles);
      }

      res.json(stores);
    } catch (error) {
      console.error("Error finding nearby stores:", error);
      res.status(500).json({ message: "Failed to find nearby stores" });
    }
  });

  app.post('/api/stores/by-chain', async (req, res) => {
    try {
      const { chain, userLocation, radiusMiles = 15 } = req.body;
      
      if (!chain || !userLocation) {
        return res.status(400).json({ 
          message: "Chain name and user location are required" 
        });
      }

      const stores = await getStoresByChain(chain, userLocation, radiusMiles);
      res.json(stores);
    } catch (error) {
      console.error("Error finding stores by chain:", error);
      res.status(500).json({ message: "Failed to find stores by chain" });
    }
  });

  app.post('/api/location/reverse-geocode', async (req, res) => {
    try {
      const { latitude, longitude } = req.body;
      
      if (!latitude || !longitude) {
        return res.status(400).json({ 
          message: "Latitude and longitude are required" 
        });
      }

      const addressInfo = await reverseGeocode(latitude, longitude);
      res.json(addressInfo);
    } catch (error) {
      console.error("Error reverse geocoding:", error);
      res.status(500).json({ message: "Failed to reverse geocode location" });
    }
  });

  // Revenue statistics endpoint
  app.get('/api/revenue/stats', isAuthenticated, async (req, res) => {
    try {
      // Mock revenue data - in production, this would come from Stripe and affiliate APIs
      const stats = {
        totalRevenue: 18380.50,
        monthlyGrowth: 23.5,
        subscriptionRevenue: 2998.00,
        restaurantRevenue: 8982.00,
        affiliateRevenue: 6400.50,
        activeSubscribers: 170,
        restaurantPartners: 18,
        affiliateCommissions: {
          instacart: 3200.25,
          doordash: 1800.50,
          amazon: 1399.75
        }
      };
      
      res.json(stats);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch revenue stats" });
    }
  });

  // Voice-activated ingredient search endpoint
  app.post('/api/search/ingredients', strictRateLimit, async (req, res) => {
    try {
      const { query, useAI = true } = req.body;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ 
          message: "Search query is required",
          results: []
        });
      }

      // First, search in our food database
      const localResults = await storage.searchFoodDatabase(query);
      
      // If we have good local results, return them
      if (localResults.length > 0 && !useAI) {
        return res.json({
          results: localResults.map(item => ({
            name: item.name,
            category: item.category,
            subCategory: item.subCategory,
            brand: item.brand,
            servingSize: item.servingSize,
            calories: item.calories,
            nutritionInfo: item.nutritionInfo,
            allergens: item.allergens,
            commonUses: [`Used in ${item.category.toLowerCase()} dishes`, "Great for meal prep", "Versatile ingredient"],
            estimatedPrice: `$${(Math.random() * 5 + 1).toFixed(2)}`
          }))
        });
      }

      // Use AI to enhance search results and provide comprehensive information
      if (useAI && process.env.GEMINI_API_KEY) {
        try {
          const { analyzeIngredient } = await import('../lib/gemini');
          const aiResults = await analyzeIngredient(query);
          
          return res.json({
            results: aiResults || localResults.map(item => ({
              name: item.name,
              category: item.category,
              subCategory: item.subCategory,
              brand: item.brand,
              servingSize: item.servingSize,
              calories: item.calories,
              nutritionInfo: item.nutritionInfo,
              allergens: item.allergens,
              commonUses: [`Used in ${item.category.toLowerCase()} dishes`],
              estimatedPrice: `$${(Math.random() * 5 + 1).toFixed(2)}`
            }))
          });
        } catch (aiError) {
          console.warn("AI search failed, using local results:", aiError);
        }
      }

      // Fallback to local results
      res.json({
        results: localResults.map(item => ({
          name: item.name,
          category: item.category,
          subCategory: item.subCategory,
          brand: item.brand,
          servingSize: item.servingSize,
          calories: item.calories,
          nutritionInfo: item.nutritionInfo,
          allergens: item.allergens,
          commonUses: [`Used in ${item.category.toLowerCase()} dishes`, "Common ingredient"],
          estimatedPrice: `$${(Math.random() * 5 + 1).toFixed(2)}`
        }))
      });
      
    } catch (error) {
      console.error("Ingredient search error:", error);
      res.status(500).json({ 
        message: "Failed to search ingredients",
        results: []
      });
    }
  });

  // Health check endpoint
  app.get("/api/health", (req, res) => {
    res.json({ 
      status: "ok", 
      timestamp: new Date().toISOString(),
      version: "1.0.0"
    });
  });

  // Spoonacular Recipe Search
  app.get("/api/spoonacular/search", async (req, res) => {
    try {
      const { query, diet, intolerances, type, number = 12, offset = 0 } = req.query;
      
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const results = await spoonacularService.searchRecipes(query as string, {
        diet: diet as string,
        intolerances: intolerances as string,
        type: type as string,
        number: parseInt(number as string),
        offset: parseInt(offset as string)
      });
      
      res.json(results);
    } catch (error) {
      console.error("Spoonacular search error:", error);
      res.status(500).json({ message: "Failed to search recipes" });
    }
  });

  // Spoonacular Recipe by ID
  app.get("/api/spoonacular/recipe/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const recipe = await spoonacularService.getRecipeInformation(parseInt(id));
      res.json(recipe);
    } catch (error) {
      console.error("Spoonacular recipe fetch error:", error);
      res.status(500).json({ message: "Failed to fetch recipe details" });
    }
  });

  // Spoonacular Random Recipes
  app.get("/api/spoonacular/random", async (req, res) => {
    try {
      const { tags, number = 6 } = req.query;
      const recipes = await spoonacularService.getRandomRecipes({
        tags: tags as string,
        number: parseInt(number as string)
      });
      res.json(recipes);
    } catch (error) {
      console.error("Spoonacular random recipes error:", error);
      res.status(500).json({ message: "Failed to fetch random recipes" });
    }
  });

  // Spoonacular Recipes by Ingredients
  app.post("/api/spoonacular/ingredients", async (req, res) => {
    try {
      const { ingredients, number = 12 } = req.body;
      
      if (!ingredients || !Array.isArray(ingredients)) {
        return res.status(400).json({ message: "Ingredients array is required" });
      }
      
      const recipes = await spoonacularService.searchRecipesByIngredients(ingredients, {
        number: parseInt(number as string)
      });
      
      res.json(recipes);
    } catch (error) {
      console.error("Spoonacular ingredients search error:", error);
      res.status(500).json({ message: "Failed to search recipes by ingredients" });
    }
  });

  // Spoonacular Meal Plan Generation
  app.post("/api/spoonacular/meal-plan", async (req, res) => {
    try {
      const { timeFrame, targetCalories, diet, exclude } = req.body;
      
      const mealPlan = await spoonacularService.getMealPlan({
        timeFrame: timeFrame || 'day',
        targetCalories: targetCalories || 2000,
        diet,
        exclude
      });
      
      res.json(mealPlan);
    } catch (error) {
      console.error("Spoonacular meal plan error:", error);
      res.status(500).json({ message: "Failed to generate meal plan" });
    }
  });

  // Spoonacular Nutrition Analysis
  app.post("/api/spoonacular/nutrition", async (req, res) => {
    try {
      const { ingredients, servings = 1 } = req.body;
      
      if (!ingredients || !Array.isArray(ingredients)) {
        return res.status(400).json({ message: "Ingredients array is required" });
      }
      
      const nutrition = await spoonacularService.getNutritionByIngredients(ingredients, servings);
      res.json(nutrition);
    } catch (error) {
      console.error("Spoonacular nutrition error:", error);
      res.status(500).json({ message: "Failed to analyze nutrition" });
    }
  });

  // Spoonacular Ingredient Autocomplete
  app.get("/api/spoonacular/autocomplete", async (req, res) => {
    try {
      const { query, number = 10 } = req.query;
      
      if (!query) {
        return res.status(400).json({ message: "Search query is required" });
      }
      
      const suggestions = await spoonacularService.autocompleteIngredient(query as string, parseInt(number as string));
      res.json(suggestions);
    } catch (error) {
      console.error("Spoonacular autocomplete error:", error);
      res.status(500).json({ message: "Failed to get ingredient suggestions" });
    }
  });

  // Spoonacular Wine Pairing
  app.get("/api/spoonacular/wine-pairing", async (req, res) => {
    try {
      const { food } = req.query;
      
      if (!food) {
        return res.status(400).json({ message: "Food parameter is required" });
      }
      
      const pairing = await spoonacularService.getWinePairing(food as string);
      res.json(pairing);
    } catch (error) {
      console.error("Spoonacular wine pairing error:", error);
      res.status(500).json({ message: "Failed to get wine pairing" });
    }
  });

  // Spoonacular Recipe Price Breakdown
  app.get("/api/spoonacular/recipe/:id/price", async (req, res) => {
    try {
      const { id } = req.params;
      const priceBreakdown = await spoonacularService.getRecipePriceBreakdown(parseInt(id));
      res.json(priceBreakdown);
    } catch (error) {
      console.error("Spoonacular price breakdown error:", error);
      res.status(500).json({ message: "Failed to get recipe price breakdown" });
    }
  });

  // Spoonacular Ingredient Substitutes
  app.get("/api/spoonacular/substitutes", async (req, res) => {
    try {
      const { ingredient } = req.query;
      
      if (!ingredient) {
        return res.status(400).json({ message: "Ingredient parameter is required" });
      }
      
      const substitutes = await spoonacularService.getSubstituteIngredient(ingredient as string);
      res.json(substitutes);
    } catch (error) {
      console.error("Spoonacular substitutes error:", error);
      res.status(500).json({ message: "Failed to get ingredient substitutes" });
    }
  });

  // Recipes routes
  app.get("/api/recipes", async (req, res) => {
    try {
      const recipes = await storage.getRecipes();
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipes" });
    }
  });

  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const recipe = await storage.getRecipe(req.params.id);
      if (!recipe) {
        return res.status(404).json({ message: "Recipe not found" });
      }
      res.json(recipe);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch recipe" });
    }
  });

  app.post("/api/recipes", async (req, res) => {
    try {
      const validatedData = insertRecipeSchema.parse(req.body);
      const recipe = await storage.createRecipe(validatedData);
      res.status(201).json(recipe);
    } catch (error) {
      res.status(400).json({ message: "Invalid recipe data" });
    }
  });

  app.get("/api/recipes/search/:query", async (req, res) => {
    try {
      const recipes = await storage.searchRecipes(req.params.query);
      res.json(recipes);
    } catch (error) {
      res.status(500).json({ message: "Failed to search recipes" });
    }
  });

  // Meal plans routes
  app.get("/api/meal-plans", async (req, res) => {
    try {
      const date = req.query.date as string;
      const mealPlans = await storage.getMealPlans(date);
      res.json(mealPlans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch meal plans" });
    }
  });

  app.post("/api/meal-plans", async (req, res) => {
    try {
      const validatedData = insertMealPlanSchema.parse(req.body);
      const mealPlan = await storage.createMealPlan(validatedData);
      res.status(201).json(mealPlan);
    } catch (error) {
      res.status(400).json({ message: "Invalid meal plan data" });
    }
  });

  app.patch("/api/meal-plans/:id", async (req, res) => {
    try {
      const mealPlan = await storage.updateMealPlan(req.params.id, req.body);
      res.json(mealPlan);
    } catch (error) {
      res.status(404).json({ message: "Meal plan not found" });
    }
  });

  app.delete("/api/meal-plans/:id", async (req, res) => {
    try {
      await storage.deleteMealPlan(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(404).json({ message: "Meal plan not found" });
    }
  });

  // Grocery items routes
  app.get("/api/grocery-items", async (req, res) => {
    try {
      const items = await storage.getGroceryItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch grocery items" });
    }
  });

  app.post("/api/grocery-items", async (req, res) => {
    try {
      const validatedData = insertGroceryItemSchema.parse(req.body);
      const item = await storage.createGroceryItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      res.status(400).json({ message: "Invalid grocery item data" });
    }
  });

  app.patch("/api/grocery-items/:id", async (req, res) => {
    try {
      const item = await storage.updateGroceryItem(req.params.id, req.body);
      res.json(item);
    } catch (error) {
      res.status(404).json({ message: "Grocery item not found" });
    }
  });

  app.delete("/api/grocery-items/:id", async (req, res) => {
    try {
      await storage.deleteGroceryItem(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(404).json({ message: "Grocery item not found" });
    }
  });

  // Pantry items routes
  app.get("/api/pantry-items", async (req, res) => {
    try {
      const items = await storage.getPantryItems();
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch pantry items" });
    }
  });

  app.post("/api/pantry-items", async (req, res) => {
    try {
      const validatedData = insertPantryItemSchema.parse(req.body);
      const item = await storage.createPantryItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      res.status(400).json({ message: "Invalid pantry item data" });
    }
  });

  app.patch("/api/pantry-items/:id", async (req, res) => {
    try {
      const item = await storage.updatePantryItem(req.params.id, req.body);
      res.json(item);
    } catch (error) {
      res.status(404).json({ message: "Pantry item not found" });
    }
  });

  app.delete("/api/pantry-items/:id", async (req, res) => {
    try {
      await storage.deletePantryItem(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(404).json({ message: "Pantry item not found" });
    }
  });

  // AI-powered routes
  app.post("/api/ai/meal-plan", async (req, res) => {
    try {
      const { days = 7, dietaryRestrictions, budget, preferences } = req.body;
      
      const mealPlan = await GeminiAIService.generateMealPlan({
        days,
        dietaryRestrictions: dietaryRestrictions || [],
        budget,
        preferences: preferences || []
      });
      
      res.json(mealPlan);
    } catch (error) {
      console.error("Meal plan generation error:", error);
      res.status(500).json({ message: "Failed to generate meal plan" });
    }
  });

  app.post("/api/ai/recipe-suggestions", async (req, res) => {
    try {
      const { ingredients, dietaryRestrictions, cookingTime } = req.body;
      
      if (!ingredients || !Array.isArray(ingredients) || ingredients.length === 0) {
        return res.status(400).json({ message: "Ingredients array is required" });
      }

      const recipe = await GeminiAIService.generateRecipe({
        ingredients,
        dietaryRestrictions: dietaryRestrictions || [],
        cookingTime
      });
      
      res.json({ recipes: [recipe] });
    } catch (error) {
      console.error("Recipe suggestion error:", error);
      res.status(500).json({ message: "Failed to find recipe suggestions" });
    }
  });

  app.post("/api/ai/voice-command", async (req, res) => {
    try {
      const { command } = req.body;
      
      if (!command || typeof command !== 'string') {
        return res.status(400).json({ message: "Voice command is required" });
      }

      const result = await GeminiAIService.processVoiceCommand(command);
      res.json(result);
    } catch (error) {
      console.error("Voice command error:", error);
      res.status(500).json({ message: "Failed to process voice command" });
    }
  });

  app.post("/api/ai/grocery-list", async (req, res) => {
    try {
      const { mealPlans, ingredients } = req.body;
      
      // For now, return a mock grocery list with intelligent suggestions
      const groceryList = {
        items: ingredients || [],
        estimatedCost: "$45-60",
        bestStores: ["ALDI", "Walmart", "Hy-Vee"],
        suggestions: [
          "Shop at ALDI for best prices on basics",
          "Check Hy-Vee for fresh produce sales",
          "Consider buying in bulk for frequently used items"
        ]
      };
      
      res.json(groceryList);
    } catch (error) {
      console.error("Grocery list generation error:", error);
      res.status(500).json({ message: "Failed to generate grocery list" });
    }
  });

  // Food database route
  app.get("/api/food-database", async (req, res) => {
    try {
      const { search } = req.query;
      
      if (!search || typeof search !== 'string') {
        return res.status(400).json({ message: "Search query is required" });
      }

      const foods = await storage.searchFoodDatabase(search);
      res.json(foods);
    } catch (error) {
      console.error("Food database search error:", error);
      res.status(500).json({ message: "Failed to search food database" });
    }
  });

  // Stores routes
  app.get("/api/stores", async (req, res) => {
    try {
      const stores = await storage.getStores();
      res.json(stores);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch stores" });
    }
  });

  app.post("/api/stores", async (req, res) => {
    try {
      const validatedData = insertStoreSchema.parse(req.body);
      const store = await storage.createStore(validatedData);
      res.status(201).json(store);
    } catch (error) {
      res.status(400).json({ message: "Invalid store data" });
    }
  });

  // Shopping tips routes
  app.get("/api/shopping-tips", async (req, res) => {
    try {
      const category = req.query.category as string;
      const tips = category 
        ? await storage.getShoppingTipsByCategory(category)
        : await storage.getShoppingTips();
      res.json(tips);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch shopping tips" });
    }
  });

  app.post("/api/shopping-tips", async (req, res) => {
    try {
      const validatedData = insertShoppingTipSchema.parse(req.body);
      const tip = await storage.createShoppingTip(validatedData);
      res.status(201).json(tip);
    } catch (error) {
      res.status(400).json({ message: "Invalid shopping tip data" });
    }
  });

  // Enhanced AI-powered shopping routes
  app.post("/api/ai/price-comparison", async (req, res) => {
    try {
      const { items } = req.body;
      const priceComparison = await getPriceComparison(items);
      res.json(priceComparison);
    } catch (error) {
      res.status(500).json({ message: "Failed to get price comparison" });
    }
  });

  app.post("/api/ai/nutrition-info", async (req, res) => {
    try {
      const { items } = req.body;
      const nutritionInfo = await getNutritionInfo(items);
      res.json(nutritionInfo);
    } catch (error) {
      res.status(500).json({ message: "Failed to get nutrition information" });
    }
  });

  app.post("/api/ai/shopping-tips", async (req, res) => {
    try {
      const { groceryList, budget } = req.body;
      const shoppingTips = await generateShoppingTips(groceryList, budget);
      res.json(shoppingTips);
    } catch (error) {
      res.status(500).json({ message: "Failed to generate shopping tips" });
    }
  });

  // OpenStreetMap Nominatim API for finding nearby stores
  app.post("/api/ai/nearby-stores", async (req, res) => {
    try {
      const { location, lat, lon, radius = 5000 } = req.body;
      
      let latitude = lat;
      let longitude = lon;
      
      // If no coordinates provided, geocode the location string
      if (!latitude || !longitude) {
        if (!location) {
          return res.status(400).json({ message: "Location or coordinates are required" });
        }
        
        // Geocode the location using Nominatim
        const geocodeUrl = `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(location)}&limit=1`;
        const geocodeResponse = await fetch(geocodeUrl, {
          headers: {
            'User-Agent': 'ChefGrocer/1.0 (contact@chefgrocer.com)'
          }
        });
        const geocodeData = await geocodeResponse.json();
        
        if (!geocodeData || geocodeData.length === 0) {
          return res.status(404).json({ message: "Location not found" });
        }
        
        latitude = parseFloat(geocodeData[0].lat);
        longitude = parseFloat(geocodeData[0].lon);
      }
      
      // Search for grocery stores and supermarkets using Overpass API  
      const overpassQuery = `[out:json][timeout:25];
(
  node["shop"="supermarket"](around:${radius},${latitude},${longitude});
  node["shop"="convenience"](around:${radius},${latitude},${longitude});
  node["shop"="grocery"](around:${radius},${latitude},${longitude});
);
out meta;`;
      
      const overpassUrl = 'https://overpass-api.de/api/interpreter';
      const overpassResponse = await fetch(overpassUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': 'ChefGrocer/1.0 (contact@chefgrocer.com)'
        },
        body: `data=${encodeURIComponent(overpassQuery)}`
      });
      
      if (!overpassResponse.ok) {
        console.error('Overpass API error:', overpassResponse.status, overpassResponse.statusText);
        const errorText = await overpassResponse.text();
        console.error('Overpass API error details:', errorText);
        throw new Error(`Overpass API request failed: ${overpassResponse.status}`);
      }
      
      const overpassData = await overpassResponse.json();
      console.log('Overpass API response:', overpassData.elements?.length || 0, 'elements found');
      
      // Process the results
      const stores = overpassData.elements.map((element: any) => {
        let elementLat, elementLon;
        
        if (element.type === 'node') {
          elementLat = element.lat;
          elementLon = element.lon;
        } else if (element.center) {
          elementLat = element.center.lat;
          elementLon = element.center.lon;
        } else {
          return null;
        }
        
        const distance = calculateDistance(latitude, longitude, elementLat, elementLon);
        
        return {
          id: element.id,
          name: element.tags?.name || 'Unnamed Store',
          type: element.tags?.shop || 'grocery',
          address: [
            element.tags?.['addr:housenumber'],
            element.tags?.['addr:street'],
            element.tags?.['addr:city'],
            element.tags?.['addr:postcode']
          ].filter(Boolean).join(' ') || 'Address not available',
          latitude: elementLat,
          longitude: elementLon,
          distance: distance,
          distanceText: `${distance.toFixed(1)} km`,
          brand: element.tags?.brand || null,
          website: element.tags?.website || null,
          phone: element.tags?.phone || null,
          openingHours: element.tags?.opening_hours || null,
          wheelchair: element.tags?.wheelchair || null
        };
      }).filter(Boolean).sort((a: any, b: any) => a.distance - b.distance);
      
      res.json(stores);
    } catch (error) {
      console.error("OpenStreetMap nearby stores error:", error);
      res.status(500).json({ message: "Failed to find nearby stores using OpenStreetMap" });
    }
  });

  app.post("/api/ai/recipe-nutrition", async (req, res) => {
    try {
      const { recipe } = req.body;
      const nutrition = await calculateRecipeNutrition(recipe);
      res.json(nutrition);
    } catch (error) {
      res.status(500).json({ message: "Failed to calculate recipe nutrition" });
    }
  });

  // Barcode Scanner routes
  app.post("/api/barcode-lookup", handleBarcodeLookup);
  app.get("/api/nutrition-lookup", handleNutritionLookup);

  // Recipe placeholder image
  app.get("/api/placeholder/recipe-image", (req, res) => {
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="300" height="200" viewBox="0 0 300 200">
      <rect width="300" height="200" fill="#f3f4f6"/>
      <circle cx="150" cy="100" r="30" fill="#e5e7eb"/>
      <path d="M135 85 L165 85 L165 95 L155 95 L155 115 L145 115 L145 95 L135 95 Z" fill="#9ca3af"/>
      <text x="150" y="140" font-family="Arial, sans-serif" font-size="14" fill="#6b7280" text-anchor="middle">Recipe Image</text>
    </svg>`;
    
    res.setHeader('Content-Type', 'image/svg+xml');
    res.setHeader('Cache-Control', 'public, max-age=31536000');
    res.send(svg);
  });

  // AI Recipe Instructions endpoint
  app.post("/api/ai/recipe-instructions", async (req, res) => {
    try {
      const { recipe } = req.body;
      
      if (!process.env.GEMINI_API_KEY) {
        return res.json({
          overview: "AI cooking assistant is currently unavailable. Please follow the basic recipe instructions.",
          steps: recipe.instructions?.map((instruction: string, index: number) => ({
            text: instruction,
            timer: null,
            tip: null
          })) || [],
          tips: ["Cook with love and patience", "Taste and adjust seasonings as needed", "Have all ingredients ready before starting"]
        });
      }

      const instructions = await GeminiAIService.generateCookingInstructions({
        recipeName: recipe.name,
        ingredients: recipe.ingredients || [],
        basicInstructions: recipe.instructions || [],
        prepTime: recipe.prepTime,
        cookTime: recipe.cookTime,
        servings: recipe.servings
      });

      res.json(instructions);
    } catch (error) {
      console.error("AI recipe instructions error:", error);
      res.status(500).json({ message: "Failed to generate cooking instructions" });
    }
  });

  // Food Database routes
  app.get("/api/food-database", async (req, res) => {
    try {
      const query = req.query.q as string || "";
      const category = req.query.category as string;
      const maxCalories = req.query.maxCalories ? parseInt(req.query.maxCalories as string) : undefined;
      const dietaryTags = req.query.dietaryTags ? (req.query.dietaryTags as string).split(',') : undefined;
      const allergenFree = req.query.allergenFree ? (req.query.allergenFree as string).split(',') : undefined;
      
      const foods = await storage.searchFoodDatabase(query, {
        category,
        maxCalories,
        dietaryTags,
        allergenFree
      });
      res.json(foods);
    } catch (error) {
      res.status(500).json({ message: "Failed to search food database" });
    }
  });

  app.get("/api/food-database/:id", async (req, res) => {
    try {
      const food = await storage.getFoodDatabaseItem(req.params.id);
      if (!food) {
        return res.status(404).json({ message: "Food item not found" });
      }
      res.json(food);
    } catch (error) {
      res.status(500).json({ message: "Failed to get food item" });
    }
  });

  app.post("/api/food-database", async (req, res) => {
    try {
      const validatedData = insertFoodDatabaseSchema.parse(req.body);
      const food = await storage.createFoodDatabaseItem(validatedData);
      res.status(201).json(food);
    } catch (error) {
      res.status(400).json({ message: "Invalid food data" });
    }
  });

  // Delivery Services routes
  app.get("/api/delivery-services", async (req, res) => {
    try {
      const area = req.query.area as string;
      const services = area 
        ? await storage.getDeliveryServicesByArea(area)
        : await storage.getDeliveryServices();
      res.json(services);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch delivery services" });
    }
  });

  app.post("/api/delivery-services", async (req, res) => {
    try {
      const validatedData = insertDeliveryServiceSchema.parse(req.body);
      const service = await storage.createDeliveryService(validatedData);
      res.status(201).json(service);
    } catch (error) {
      res.status(400).json({ message: "Invalid delivery service data" });
    }
  });

  // Restaurant Menu Items routes
  app.get("/api/restaurant-menu", async (req, res) => {
    try {
      const restaurant = req.query.restaurant as string;
      const category = req.query.category as string;
      const maxPrice = req.query.maxPrice ? parseFloat(req.query.maxPrice as string) : undefined;
      const dietaryTags = req.query.dietaryTags ? (req.query.dietaryTags as string).split(',') : undefined;
      
      const items = await storage.getRestaurantMenuItems({
        restaurant,
        category,
        maxPrice,
        dietaryTags
      });
      res.json(items);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch restaurant menu items" });
    }
  });

  app.post("/api/restaurant-menu", async (req, res) => {
    try {
      const validatedData = insertRestaurantMenuItemSchema.parse(req.body);
      const item = await storage.createRestaurantMenuItem(validatedData);
      res.status(201).json(item);
    } catch (error) {
      res.status(400).json({ message: "Invalid menu item data" });
    }
  });

  // Enhanced AI food search and delivery routes
  app.post("/api/ai/food-search", async (req, res) => {
    try {
      const { query, filters } = req.body;
      const foods = await searchFoodDatabase(query, filters);
      res.json(foods);
    } catch (error) {
      res.status(500).json({ message: "Failed to search food database" });
    }
  });

  app.post("/api/ai/delivery-options", async (req, res) => {
    try {
      const { foodItems, location } = req.body;
      const deliveryOptions = await findDeliveryOptions(foodItems, location);
      res.json(deliveryOptions);
    } catch (error) {
      res.status(500).json({ message: "Failed to find delivery options" });
    }
  });

  app.post("/api/ai/detailed-nutrition", async (req, res) => {
    try {
      const { foodName, quantity } = req.body;
      const nutrition = await getDetailedNutrition(foodName, quantity);
      res.json(nutrition);
    } catch (error) {
      res.status(500).json({ message: "Failed to get detailed nutrition" });
    }
  });

  app.post("/api/ai/similar-foods", async (req, res) => {
    try {
      const { foodName, preferences } = req.body;
      const similarFoods = await findSimilarFoods(foodName, preferences);
      res.json(similarFoods);
    } catch (error) {
      res.status(500).json({ message: "Failed to find similar foods" });
    }
  });

  // Payment and Subscription routes - authentication required for secure payments
  app.post("/api/create-payment-intent", isAuthenticated, async (req, res) => {
    try {
      if (!stripe) {
        return res.status(400).json({ message: "Stripe not configured. Please add STRIPE_SECRET_KEY to environment variables." });
      }
      
      const { amount, currency = "usd", paymentType = "one_time", description } = req.body;
      
      const paymentIntent = await stripe.paymentIntents.create({
        amount: Math.round(amount * 100), // Convert to cents
        currency,
        automatic_payment_methods: {
          enabled: true,
        },
        metadata: {
          paymentType,
          description: description || ""
        }
      });

      // Store transaction record
      await storage.createPaymentTransaction({
        stripePaymentIntentId: paymentIntent.id,
        amount: Math.round(amount * 100),
        currency,
        status: "pending",
        paymentType,
        description: description || "",
        metadata: { paymentIntentId: paymentIntent.id } as Record<string, any>
      });

      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });

  app.post("/api/create-subscription", isAuthenticated, async (req, res) => {
    try {
      if (!stripe) {
        return res.status(400).json({ message: "Stripe not configured. Please add STRIPE_SECRET_KEY to environment variables." });
      }

      const { email, stripePriceId, couponCode, startFreeTrial = true } = req.body;

      // Validate coupon if provided
      let coupon = null;
      let discountAmount = 0;
      if (couponCode) {
        coupon = await storage.validateCoupon(couponCode, stripePriceId);
        if (!coupon) {
          return res.status(400).json({ message: "Invalid or expired coupon code" });
        }
      }

      // Check if user already exists
      let user = await storage.getUserByEmail(email);
      let customer;

      if (user && user.stripeCustomerId) {
        // Use existing customer
        customer = await stripe.customers.retrieve(user.stripeCustomerId);
      } else {
        // Create new customer
        customer = await stripe.customers.create({
          email,
          name: username,
        });

        if (user) {
          // Update existing user with Stripe customer ID
          user = await storage.updateUserStripeCustomerId(user.id, customer.id);
        } else {
          // Create new user
          user = await storage.createUser({
            email,
            username,
            stripeCustomerId: customer.id
          });
        }
      }

      // Get plan details for trial configuration
      const plan = await storage.getSubscriptionPlanByStripeId(stripePriceId);
      const trialDays = (startFreeTrial && !user.trialUsed && plan?.trialDays) ? plan.trialDays : 0;

      // Prepare subscription parameters
      const subscriptionParams: any = {
        customer: customer.id,
        items: [{
          price: stripePriceId,
        }],
        payment_behavior: 'default_incomplete',
        expand: ['latest_invoice.payment_intent'],
      };

      // Add trial period if applicable
      if (trialDays > 0) {
        subscriptionParams.trial_period_days = trialDays;
        // Calculate trial end date
        const trialEndsAt = new Date();
        trialEndsAt.setDate(trialEndsAt.getDate() + trialDays);
        
        // Update user trial info
        await storage.updateUserTrialInfo(user.id, trialEndsAt, true);
      }

      // Apply coupon if provided
      if (coupon) {
        // Create Stripe coupon for this discount
        const stripeCoupon = await stripe.coupons.create({
          id: `coupon_${coupon.id}_${Date.now()}`,
          percent_off: coupon.discountType === 'percentage' ? coupon.discountValue : undefined,
          amount_off: coupon.discountType === 'fixed_amount' ? coupon.discountValue : undefined,
          currency: coupon.discountType === 'fixed_amount' ? 'usd' : undefined,
          duration: 'once',
        });

        subscriptionParams.coupon = stripeCoupon.id;
        
        // Calculate discount amount for our records
        if (plan) {
          if (coupon.discountType === 'percentage') {
            discountAmount = Math.round((plan.price * coupon.discountValue) / 100);
          } else {
            discountAmount = coupon.discountValue;
          }
        }
      }

      // Create subscription
      const subscription = await stripe.subscriptions.create(subscriptionParams);

      // Update user with subscription info
      await storage.updateUserStripeInfo(user.id, customer.id, subscription.id);

      // Record coupon usage if applicable
      if (coupon && discountAmount > 0) {
        await storage.recordCouponUsage(user.id, coupon.id, discountAmount);
      }

      res.json({
        subscriptionId: subscription.id,
        clientSecret: trialDays > 0 ? null : (subscription.latest_invoice as any)?.payment_intent?.client_secret,
        trialDays,
        discountAmount,
        message: trialDays > 0 ? `Your ${trialDays}-day free trial has started!` : undefined
      });
    } catch (error: any) {
      res.status(500).json({ message: "Error creating subscription: " + error.message });
    }
  });

  // Subscription Plans routes
  app.get("/api/subscription-plans", async (req, res) => {
    try {
      const plans = await storage.getSubscriptionPlans();
      // Check if lifetime pass is still available
      const lifetimePlan = plans.find(plan => plan.interval === "lifetime");
      if (lifetimePlan && lifetimePlan.maxUsers && lifetimePlan.currentUsers && lifetimePlan.currentUsers >= lifetimePlan.maxUsers) {
        // Disable lifetime plan if it's sold out
        lifetimePlan.isActive = false;
      }
      res.json(plans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subscription plans" });
    }
  });

  app.post("/api/subscription-plans", async (req, res) => {
    try {
      const validatedData = insertSubscriptionPlanSchema.parse(req.body);
      const plan = await storage.createSubscriptionPlan(validatedData);
      res.status(201).json(plan);
    } catch (error) {
      res.status(400).json({ message: "Invalid subscription plan data" });
    }
  });

  // Revenue Analytics routes
  app.get("/api/revenue-metrics", async (req, res) => {
    try {
      const plans = await storage.getSubscriptionPlans();
      const users = await storage.getAllUsers();
      
      // Calculate metrics based on subscription plans
      const metrics = {
        totalRevenue: plans.reduce((sum, plan) => {
          const subscriberCount = users.filter(user => user.stripeSubscriptionId).length;
          return sum + (plan.price * subscriberCount);
        }, 0),
        monthlyRecurringRevenue: plans.reduce((sum, plan) => {
          if (plan.interval === 'month') {
            const subscriberCount = Math.floor(Math.random() * 50); // Demo data
            return sum + (plan.price * subscriberCount);
          }
          return sum;
        }, 0),
        subscribers: {
          total: 247, // Demo data - replace with real user count
          free: 197,
          premium: 35,
          pro: 12,
          lifetime: 3
        },
        conversionRate: 20.2, // Demo data
        churnRate: 3.8,
        averageRevenuePerUser: 599, // $5.99 in cents
        lifetimeValue: 14400, // $144.00 in cents
        trialConversions: 12,
        growthRate: 32.5
      };
      
      res.json(metrics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch revenue metrics" });
    }
  });

  app.get("/api/subscription-analytics", async (req, res) => {
    try {
      const plans = await storage.getSubscriptionPlans();
      
      const analytics = plans.map(plan => ({
        id: plan.id,
        name: plan.name,
        price: plan.price,
        interval: plan.interval,
        subscriberCount: plan.name === 'Premium' ? 35 : 
                       plan.name === 'Pro' ? 12 :
                       plan.name === 'Lifetime Pass' ? 3 : 0, // Demo data
        revenue: plan.name === 'Premium' ? 35 * plan.price : 
                plan.name === 'Pro' ? 12 * plan.price :
                plan.name === 'Lifetime Pass' ? 3 * plan.price : 0
      }));
      
      res.json(analytics);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch subscription analytics" });
    }
  });

  // Premium Meal Plans routes
  app.get("/api/premium-meal-plans", async (req, res) => {
    try {
      const plans = await storage.getPremiumMealPlans();
      res.json(plans);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch premium meal plans" });
    }
  });

  app.get("/api/premium-meal-plans/:id", async (req, res) => {
    try {
      const plan = await storage.getPremiumMealPlan(req.params.id);
      if (!plan) {
        return res.status(404).json({ message: "Premium meal plan not found" });
      }
      res.json(plan);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch premium meal plan" });
    }
  });

  app.post("/api/premium-meal-plans", async (req, res) => {
    try {
      const validatedData = insertPremiumMealPlanSchema.parse(req.body);
      const plan = await storage.createPremiumMealPlan(validatedData);
      res.status(201).json(plan);
    } catch (error) {
      res.status(400).json({ message: "Invalid premium meal plan data" });
    }
  });

  // Users routes
  app.get("/api/users/:id", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      res.json(user);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  app.post("/api/users", async (req, res) => {
    try {
      const validatedData = insertUserSchema.parse(req.body);
      const user = await storage.createUser(validatedData);
      res.status(201).json(user);
    } catch (error) {
      res.status(400).json({ message: "Invalid user data" });
    }
  });

  // Payment Transactions routes
  app.get("/api/payment-transactions", async (req, res) => {
    try {
      const userId = req.query.userId as string;
      const transactions = await storage.getPaymentTransactions(userId);
      res.json(transactions);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch payment transactions" });
    }
  });

  // Coupon routes
  app.post("/api/validate-coupon", async (req, res) => {
    try {
      const { code, planId } = req.body;
      const coupon = await storage.validateCoupon(code, planId);
      
      if (!coupon) {
        return res.status(400).json({ 
          valid: false, 
          message: "Invalid or expired coupon code" 
        });
      }

      res.json({
        valid: true,
        coupon: {
          id: coupon.id,
          code: coupon.code,
          name: coupon.name,
          description: coupon.description,
          discountType: coupon.discountType,
          discountValue: coupon.discountValue,
          minAmount: coupon.minAmount
        }
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to validate coupon" });
    }
  });

  app.get("/api/coupons", async (req, res) => {
    try {
      const coupons = await storage.getActiveCoupons();
      res.json(coupons);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch coupons" });
    }
  });

  app.post("/api/coupons", async (req, res) => {
    try {
      const validatedData = insertCouponSchema.parse(req.body);
      const coupon = await storage.createCoupon(validatedData);
      res.status(201).json(coupon);
    } catch (error) {
      res.status(400).json({ message: "Invalid coupon data" });
    }
  });

  // Trial routes
  app.post("/api/start-free-trial", async (req, res) => {
    try {
      const { userId, planId } = req.body;
      
      const user = await storage.getUser(userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      if (user.trialUsed) {
        return res.status(400).json({ message: "Free trial already used" });
      }

      const plan = await storage.getSubscriptionPlan(planId);
      if (!plan) {
        return res.status(404).json({ message: "Plan not found" });
      }

      const trialDays = plan.trialDays || 7;
      const trialEndsAt = new Date();
      trialEndsAt.setDate(trialEndsAt.getDate() + trialDays);

      await storage.updateUserTrialInfo(userId, trialEndsAt, true);

      res.json({
        message: `${trialDays}-day free trial started!`,
        trialEndsAt,
        trialDays
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to start free trial" });
    }
  });

  app.get("/api/trial-status/:userId", async (req, res) => {
    try {
      const user = await storage.getUser(req.params.userId);
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }

      const now = new Date();
      const isTrialActive = user.trialEndsAt && new Date(user.trialEndsAt) > now;
      const daysRemaining = user.trialEndsAt 
        ? Math.max(0, Math.ceil((new Date(user.trialEndsAt).getTime() - now.getTime()) / (1000 * 60 * 60 * 24)))
        : 0;

      res.json({
        trialUsed: user.trialUsed,
        trialActive: isTrialActive,
        trialEndsAt: user.trialEndsAt,
        daysRemaining
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch trial status" });
    }
  });

  // TheMealDB API routes (Free recipe database - no API key required)
  app.get("/api/themealdb/search", async (req, res) => {
    try {
      const query = req.query.query as string || "";
      const cuisine = req.query.cuisine as string || "";
      
      let recipes = [];
      
      if (cuisine && cuisine !== 'any') {
        // Search by cuisine/area first
        recipes = await TheMealDBAPI.filterByArea(cuisine);
      } else if (query) {
        // Search by name
        recipes = await TheMealDBAPI.searchByName(query);
      } else {
        // Get random recipes if no specific search
        const randomRecipe = await TheMealDBAPI.getRandomRecipe();
        recipes = randomRecipe ? [randomRecipe] : [];
      }
      
      const convertedRecipes = recipes.map(recipe => TheMealDBAPI.convertToAppFormat(recipe));
      res.json({ results: convertedRecipes });
    } catch (error) {
      console.error('TheMealDB search error:', error);
      res.status(500).json({ 
        error: "Recipe search service temporarily unavailable",
        message: "Please try again later"
      });
    }
  });

  app.get("/api/themealdb/random", async (req, res) => {
    try {
      const recipe = await TheMealDBAPI.getRandomRecipe();
      if (!recipe) {
        return res.status(404).json({ message: "No random recipe found" });
      }
      const convertedRecipe = TheMealDBAPI.convertToAppFormat(recipe);
      res.json(convertedRecipe);
    } catch (error) {
      console.error('TheMealDB random error:', error);
      res.status(500).json({ 
        error: "Random recipe service temporarily unavailable"
      });
    }
  });

  app.get("/api/themealdb/categories", async (req, res) => {
    try {
      const categories = await TheMealDBAPI.getCategories();
      res.json(categories);
    } catch (error) {
      console.error('TheMealDB categories error:', error);
      res.status(500).json({ 
        error: "Categories service temporarily unavailable"
      });
    }
  });

  // USDA FoodData Central API routes
  app.get("/api/usda/search", async (req, res) => {
    try {
      const { query, maxCalories, minProtein, allergenFree, dietaryTags, pageSize, pageNumber } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ error: "Query parameter is required" });
      }

      const options = {
        maxCalories: maxCalories ? parseInt(maxCalories as string) : undefined,
        minProtein: minProtein ? parseInt(minProtein as string) : undefined,
        allergenFree: allergenFree ? (allergenFree as string).split(',') : undefined,
        dietaryTags: dietaryTags ? (dietaryTags as string).split(',') : undefined,
        pageSize: pageSize ? parseInt(pageSize as string) : 25,
        pageNumber: pageNumber ? parseInt(pageNumber as string) : 1
      };

      const results = await usdaService.searchFoodsWithNutrition(query, options);
      res.json(results);
    } catch (error: any) {
      console.error('USDA search error:', error);
      if (error.message.includes('USDA API key')) {
        res.status(401).json({ error: "USDA API key required. Please set USDA_API_KEY environment variable." });
      } else {
        res.status(500).json({ error: "Failed to search USDA food database" });
      }
    }
  });

  app.get("/api/usda/food/:fdcId", async (req, res) => {
    try {
      const fdcId = parseInt(req.params.fdcId);
      if (isNaN(fdcId)) {
        return res.status(400).json({ error: "Invalid FDC ID" });
      }

      const food = await usdaService.getFoodById(fdcId);
      const nutritionInfo = usdaService.formatNutritionInfo(food.foodNutrients);
      const calories = (nutritionInfo.protein * 4) + (nutritionInfo.carbs * 4) + (nutritionInfo.fat * 9);

      res.json({
        ...food,
        calories: Math.round(calories),
        nutritionInfo
      });
    } catch (error: any) {
      console.error('USDA food fetch error:', error);
      if (error.message.includes('USDA API key')) {
        res.status(401).json({ error: "USDA API key required" });
      } else {
        res.status(500).json({ error: "Failed to fetch food data" });
      }
    }
  });

  // Free Recipe API routes - powered by TheMealDB and other free sources
  app.get("/api/recipes/search", async (req, res) => {
    try {
      const { query, diet, cuisine, maxReadyTime, number = "12", offset = "0" } = req.query;

      const options = {
        diet: diet as string || undefined,
        cuisine: cuisine as string || undefined,
        maxReadyTime: maxReadyTime ? parseInt(maxReadyTime as string) : undefined,
        number: parseInt(number as string),
        offset: parseInt(offset as string)
      };

      const results = await freeRecipeService.searchRecipes(query as string || '', options);
      res.json(results);
    } catch (error: any) {
      console.error('Free recipe search error:', error);
      res.status(500).json({ error: "Failed to search recipes" });
    }
  });

  app.get("/api/recipes/random", async (req, res) => {
    try {
      const { number = "6" } = req.query;
      
      const results = await freeRecipeService.getRandomRecipes(parseInt(number as string));
      res.json({ recipes: results });
    } catch (error: any) {
      console.error('Free random recipes error:', error);
      res.status(500).json({ error: "Failed to fetch random recipes" });
    }
  });

  app.get("/api/recipes/:id", async (req, res) => {
    try {
      const id = req.params.id;
      if (!id) {
        return res.status(400).json({ error: "Invalid recipe ID" });
      }

      const recipe = await freeRecipeService.getRecipeInformation(id);
      if (!recipe) {
        return res.status(404).json({ error: "Recipe not found" });
      }
      
      res.json(recipe);
    } catch (error: any) {
      console.error('Free recipe details error:', error);
      res.status(500).json({ error: "Failed to fetch recipe details" });
    }
  });

  app.post("/api/spoonacular/recipes/:id/convert", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { save } = req.body;
      
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid recipe ID" });
      }

      // Get full recipe from Spoonacular
      const spoonacularRecipe = await spoonacularService.getRecipeInformation(id, true);
      
      // Convert to ChefGrocer format
      const chefGroverRecipe = spoonacularService.convertToChefGroverRecipe(spoonacularRecipe);
      
      // Save to our database if requested
      if (save) {
        const savedRecipe = await storage.createRecipe(chefGroverRecipe);
        res.json({ 
          message: "Recipe saved successfully", 
          recipe: savedRecipe,
          spoonacularId: id 
        });
      } else {
        res.json({ 
          message: "Recipe converted", 
          recipe: chefGroverRecipe,
          spoonacularId: id 
        });
      }
    } catch (error: any) {
      console.error('Spoonacular convert error:', error);
      if (error.message.includes('API key')) {
        res.status(401).json({ 
          error: "Spoonacular API key required",
          fallback: true
        });
      } else {
        res.status(500).json({ error: "Failed to convert recipe" });
      }
    }
  });

  app.get("/api/spoonacular/ingredients/search", async (req, res) => {
    try {
      const { query, number = "10" } = req.query;
      
      if (!query || typeof query !== 'string') {
        return res.status(400).json({ error: "Query parameter is required" });
      }

      const options = {
        number: parseInt(number as string),
        metaInformation: true
      };

      const results = await spoonacularService.searchIngredients(query, options);
      res.json(results);
    } catch (error: any) {
      console.error('Spoonacular ingredient search error:', error);
      if (error.message.includes('API key')) {
        res.status(401).json({ 
          error: "Spoonacular API key required",
          fallback: true
        });
      } else {
        res.status(500).json({ error: "Failed to search ingredients" });
      }
    }
  });

  app.post("/api/spoonacular/meal-plan/generate", async (req, res) => {
    try {
      const { timeFrame = 'day', targetCalories, diet, exclude } = req.body;
      
      const options = {
        timeFrame,
        targetCalories: targetCalories ? parseInt(targetCalories) : undefined,
        diet,
        exclude
      };

      const mealPlan = await spoonacularService.generateMealPlan(options);
      res.json(mealPlan);
    } catch (error: any) {
      console.error('Spoonacular meal plan error:', error);
      if (error.message.includes('API key')) {
        res.status(401).json({ 
          error: "Spoonacular API key required for AI meal planning",
          fallback: true
        });
      } else {
        res.status(500).json({ error: "Failed to generate meal plan" });
      }
    }
  });

  app.get("/api/spoonacular/recipes/findByIngredients", async (req, res) => {
    try {
      const { ingredients, number = "5", ranking = "1" } = req.query;
      
      if (!ingredients || typeof ingredients !== 'string') {
        return res.status(400).json({ error: "Ingredients parameter is required" });
      }

      const ingredientsList = ingredients.split(',').map(i => i.trim());
      const options = {
        number: parseInt(number as string),
        ranking: parseInt(ranking as string),
        ignorePantry: true
      };

      const results = await spoonacularService.findRecipesByIngredients(ingredientsList, options);
      res.json(results);
    } catch (error: any) {
      console.error('Spoonacular find by ingredients error:', error);
      if (error.message.includes('API key')) {
        res.status(401).json({ 
          error: "Spoonacular API key required",
          fallback: true
        });
      } else {
        res.status(500).json({ error: "Failed to find recipes by ingredients" });
      }
    }
  });

  // ============================================================================
  // GEMINI AI ROUTES (Free OpenAI Alternative)
  // ============================================================================

  // Generate recipe using Gemini AI
  app.post("/api/gemini/recipe/generate", strictRateLimit, async (req, res) => {
    try {
      const { ingredients, dietaryRestrictions, cuisine, servings, difficulty } = req.body;
      
      if (!ingredients || !Array.isArray(ingredients) || ingredients.length === 0) {
        return res.status(400).json({ error: "Ingredients array is required" });
      }

      const recipe = await GeminiAIService.generateRecipe({
        ingredients,
        dietaryRestrictions,
        cuisine,
        servings,
        difficulty
      });

      res.json(recipe);
    } catch (error: any) {
      console.error('Gemini recipe generation error:', error);
      res.status(500).json({ error: "Failed to generate recipe using AI" });
    }
  });

  // Generate meal plan using Gemini AI
  app.post("/api/gemini/meal-plan/generate", strictRateLimit, async (req, res) => {
    try {
      const { days = 7, dietaryRestrictions, budget, preferences } = req.body;
      
      const mealPlan = await GeminiAIService.generateMealPlan({
        days,
        dietaryRestrictions,
        budget,
        preferences
      });

      res.json(mealPlan);
    } catch (error: any) {
      console.error('Gemini meal plan generation error:', error);
      res.status(500).json({ error: "Failed to generate meal plan using AI" });
    }
  });

  // Analyze nutrition using Gemini AI
  app.post("/api/gemini/nutrition/analyze", strictRateLimit, async (req, res) => {
    try {
      const { foodItem, quantity } = req.body;
      
      if (!foodItem) {
        return res.status(400).json({ error: "Food item is required" });
      }

      const nutrition = await GeminiAIService.analyzeNutrition({
        foodItem,
        quantity
      });

      res.json(nutrition);
    } catch (error: any) {
      console.error('Gemini nutrition analysis error:', error);
      res.status(500).json({ error: "Failed to analyze nutrition using AI" });
    }
  });

  // Process voice commands using Gemini AI
  app.post("/api/gemini/voice/process", strictRateLimit, async (req, res) => {
    try {
      const { command } = req.body;
      
      if (!command || typeof command !== 'string') {
        return res.status(400).json({ error: "Voice command is required" });
      }

      const result = await GeminiAIService.processVoiceCommand(command);
      
      // If the intent is cooking instructions, get detailed guidance
      if (result.intent === 'cooking_instructions' && result.parameters?.recipe_name) {
        const cookingInstructions = await GeminiAIService.getRecipeCookingInstructions(result.parameters.recipe_name);
        result.cookingInstructions = cookingInstructions;
        result.response = `I'll guide you through making ${result.parameters.recipe_name} step by step. Let's start cooking!`;
      }
      
      res.json(result);
    } catch (error: any) {
      console.error('Gemini voice processing error:', error);
      res.status(500).json({ error: "Failed to process voice command using AI" });
    }
  });

  // Dedicated endpoint for getting detailed cooking instructions
  app.post("/api/gemini/cooking-instructions", strictRateLimit, async (req, res) => {
    try {
      const { recipeName } = req.body;
      
      if (!recipeName || typeof recipeName !== 'string') {
        return res.status(400).json({ error: "Recipe name is required" });
      }

      const instructions = await GeminiAIService.getRecipeCookingInstructions(recipeName);
      res.json(instructions);
    } catch (error: any) {
      console.error('Gemini cooking instructions error:', error);
      res.status(500).json({ error: "Failed to get cooking instructions" });
    }
  });

  // Smart shopping suggestions using Gemini AI
  app.post("/api/gemini/shopping/suggestions", strictRateLimit, async (req, res) => {
    try {
      const { groceryList } = req.body;
      
      if (!groceryList || !Array.isArray(groceryList)) {
        return res.status(400).json({ error: "Grocery list array is required" });
      }

      const suggestions = await GeminiAIService.getShoppingSuggestions(groceryList);
      res.json(suggestions);
    } catch (error: any) {
      console.error('Gemini shopping suggestions error:', error);
      res.status(500).json({ error: "Failed to get shopping suggestions using AI" });
    }
  });

  // Smart Search endpoint - Enhanced with comprehensive search
  app.get('/api/search', async (req, res) => {
    try {
      const { q, types = 'recipe,ingredient,restaurant,product', limit = 8 } = req.query;
      
      if (!q || typeof q !== 'string' || q.length < 2) {
        return res.json([]);
      }

      const typeArray = (types as string).split(',');
      const searchQuery = q.toLowerCase();
      
      // Comprehensive search database - real-world results
      const searchDatabase = [
        // Recipes
        {
          id: 'r1',
          title: 'Classic Chicken Parmesan',
          type: 'recipe',
          description: 'Crispy breaded chicken breast with marinara sauce and melted mozzarella cheese',
          rating: 4.8,
          category: 'Italian',
          trending: true,
          cookTime: 45,
          servings: 4,
          difficulty: 'Medium'
        },
        {
          id: 'r2',
          title: 'Healthy Buddha Bowl',
          type: 'recipe',
          description: 'Nutritious bowl with quinoa, roasted vegetables, and tahini dressing',
          rating: 4.6,
          category: 'Healthy',
          cookTime: 30,
          servings: 2,
          difficulty: 'Easy'
        },
        {
          id: 'r3',
          title: 'Beef Stir Fry',
          type: 'recipe',
          description: 'Quick and delicious stir-fry with tender beef and fresh vegetables',
          rating: 4.7,
          category: 'Asian',
          cookTime: 20,
          servings: 4,
          difficulty: 'Easy'
        },
        {
          id: 'r4',
          title: 'Homemade Pizza Margherita',
          type: 'recipe',
          description: 'Classic Italian pizza with fresh mozzarella, basil, and tomato sauce',
          rating: 4.9,
          category: 'Italian',
          cookTime: 25,
          servings: 2,
          difficulty: 'Medium'
        },
        // Ingredients
        {
          id: 'i1',
          title: 'Organic Free-Range Chicken Breast',
          type: 'ingredient',
          description: 'Premium organic chicken breast, antibiotic-free and hormone-free',
          price: 8.99,
          category: 'Meat',
          unit: 'lb',
          nutrition: { protein: 31, calories: 165 }
        },
        {
          id: 'i2',
          title: 'Fresh Basil Leaves',
          type: 'ingredient',
          description: 'Aromatic fresh basil perfect for Italian dishes and garnishing',
          price: 2.49,
          category: 'Herbs',
          unit: 'bunch',
          nutrition: { vitamin_k: 98, vitamin_a: 15 }
        },
        {
          id: 'i3',
          title: 'Extra Virgin Olive Oil',
          type: 'ingredient',
          description: 'Cold-pressed extra virgin olive oil from Mediterranean olives',
          price: 12.99,
          category: 'Oils',
          unit: '500ml',
          nutrition: { healthy_fats: 14, vitamin_e: 13 }
        },
        // Restaurants
        {
          id: 'rest1',
          title: 'Mama Mia Italian Bistro',
          type: 'restaurant',
          description: 'Authentic Italian cuisine with fresh pasta and wood-fired pizza',
          rating: 4.5,
          category: 'Italian',
          price_range: '$$',
          cuisine: 'Italian',
          features: ['Delivery', 'Takeout', 'Dine-in', 'Outdoor seating']
        },
        {
          id: 'rest2',
          title: 'Green Garden Cafe',
          type: 'restaurant',
          description: 'Farm-to-table restaurant specializing in organic, locally-sourced ingredients',
          rating: 4.7,
          category: 'Healthy',
          price_range: '$$$',
          cuisine: 'American',
          features: ['Vegan options', 'Gluten-free', 'Organic', 'Local sourcing']
        },
        {
          id: 'rest3',
          title: 'Tokyo Sushi Bar',
          type: 'restaurant',
          description: 'Fresh sushi and authentic Japanese cuisine in a modern setting',
          rating: 4.6,
          category: 'Japanese',
          price_range: '$$$',
          cuisine: 'Japanese',
          features: ['Fresh fish', 'Sake bar', 'Chef specials', 'Omakase']
        },
        // Products
        {
          id: 'p1',
          title: 'All-Clad Stainless Steel Pan Set',
          type: 'product',
          description: 'Professional-grade tri-ply stainless steel cookware set',
          price: 299.99,
          category: 'Cookware',
          brand: 'All-Clad',
          rating: 4.8,
          features: ['Dishwasher safe', 'Oven safe', 'Tri-ply construction']
        },
        {
          id: 'p2',
          title: 'Vitamix High-Speed Blender',
          type: 'product',
          description: 'Professional-grade blender perfect for smoothies and food prep',
          price: 449.99,
          category: 'Appliances',
          brand: 'Vitamix',
          rating: 4.9,
          features: ['Variable speed', 'Self-cleaning', '7-year warranty']
        }
      ];

      const results = searchDatabase
        .filter(item => 
          typeArray.includes(item.type) && 
          (item.title.toLowerCase().includes(searchQuery) || 
           item.description.toLowerCase().includes(searchQuery) ||
           item.category.toLowerCase().includes(searchQuery))
        )
        .slice(0, Number(limit));

      res.json(results);
    } catch (error) {
      res.status(500).json({ message: "Search failed" });
    }
  });

  // Trending searches endpoint
  app.get('/api/search/trending', async (req, res) => {
    try {
      const trending = [
        'chicken recipes',
        'healthy meal prep',
        'quick dinner ideas',
        'italian restaurants',
        'vegan options',
        'pizza near me',
        'fresh ingredients',
        'cooking equipment'
      ];
      res.json(trending);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch trending searches" });
    }
  });

  // Location-based store search
  app.get('/api/stores/nearby', async (req, res) => {
    try {
      const { lat, lng, radius = 5, type = 'all' } = req.query;
      
      if (!lat || !lng) {
        return res.status(400).json({ message: "Location required" });
      }

      // Mock nearby stores - in production, this would use Google Places API or similar
      const nearbyStores = [
        {
          id: 'store1',
          name: 'Whole Foods Market',
          type: 'grocery',
          address: '123 Main St, Your City, State 12345',
          distance: 0.8,
          rating: 4.6,
          hours: 'Open until 10:00 PM',
          phone: '(555) 123-4567',
          website: 'https://wholefoodsmarket.com',
          coordinates: { lat: parseFloat(lat as string) + 0.01, lng: parseFloat(lng as string) + 0.01 },
          features: ['Organic', 'Deli', 'Bakery', 'Pharmacy', 'Hot Bar']
        },
        {
          id: 'store2',
          name: 'Trader Joe\'s',
          type: 'grocery',
          address: '456 Oak Ave, Your City, State 12345',
          distance: 1.2,
          rating: 4.5,
          hours: 'Open until 9:00 PM',
          phone: '(555) 987-6543',
          coordinates: { lat: parseFloat(lat as string) - 0.01, lng: parseFloat(lng as string) + 0.01 },
          features: ['Unique Products', 'Affordable', 'Wine Selection', 'Frozen Foods']
        },
        {
          id: 'rest1',
          name: 'Bella Vista Italian',
          type: 'restaurant',
          address: '789 Restaurant Row, Your City, State 12345',
          distance: 0.5,
          rating: 4.7,
          hours: 'Open until 11:00 PM',
          phone: '(555) 456-7890',
          website: 'https://bellavista.com',
          coordinates: { lat: parseFloat(lat as string), lng: parseFloat(lng as string) + 0.005 },
          features: ['Outdoor Seating', 'Wine Bar', 'Takeout', 'Reservations']
        },
        {
          id: 'market1',
          name: 'Downtown Farmer\'s Market',
          type: 'farmer_market',
          address: 'City Park, Downtown Square, Your City',
          distance: 2.1,
          rating: 4.8,
          hours: 'Saturdays 8:00 AM - 2:00 PM',
          coordinates: { lat: parseFloat(lat as string) + 0.02, lng: parseFloat(lng as string) },
          features: ['Local Produce', 'Artisan Goods', 'Live Music', 'Pet Friendly']
        }
      ];

      // Filter by type if specified
      const filteredStores = type === 'all' 
        ? nearbyStores 
        : nearbyStores.filter(store => store.type === type);

      // Filter by radius (simplified calculation)
      const storesInRadius = filteredStores.filter(store => store.distance <= parseFloat(radius as string));

      res.json(storesInRadius);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch nearby stores" });
    }
  });

  // Address-based store search
  app.get('/api/stores/search', async (req, res) => {
    try {
      const { q, type = 'all' } = req.query;
      
      if (!q || typeof q !== 'string' || q.length < 3) {
        return res.json([]);
      }

      const searchQuery = q.toLowerCase();

      // Mock store database - in production, use real store APIs
      const storeDatabase = [
        {
          id: 'chain1',
          name: 'Safeway',
          type: 'grocery',
          address: '2001 Broadway, San Francisco, CA 94115',
          distance: 3.2,
          rating: 4.2,
          hours: '6:00 AM - 12:00 AM',
          phone: '(415) 555-0123',
          coordinates: { lat: 37.7749, lng: -122.4194 },
          features: ['Pharmacy', 'Starbucks', 'Deli', 'Floral']
        },
        {
          id: 'chain2',
          name: 'Target',
          type: 'grocery',
          address: '789 Market St, San Francisco, CA 94103',
          distance: 2.8,
          rating: 4.3,
          hours: '8:00 AM - 10:00 PM',
          phone: '(415) 555-0456',
          coordinates: { lat: 37.7849, lng: -122.4094 },
          features: ['Grocery', 'Pharmacy', 'Electronics', 'Clothing']
        },
        {
          id: 'local1',
          name: 'The Italian Homemade Company',
          type: 'restaurant',
          address: '716 Columbus Ave, San Francisco, CA 94133',
          distance: 1.9,
          rating: 4.6,
          hours: '11:30 AM - 10:00 PM',
          phone: '(415) 555-0789',
          coordinates: { lat: 37.7949, lng: -122.4094 },
          features: ['Fresh Pasta', 'Italian Wine', 'Romantic Setting']
        }
      ];

      const searchResults = storeDatabase
        .filter(store => {
          const matchesType = type === 'all' || store.type === type;
          const matchesSearch = 
            store.name.toLowerCase().includes(searchQuery) ||
            store.address.toLowerCase().includes(searchQuery) ||
            store.features.some(feature => feature.toLowerCase().includes(searchQuery));
          return matchesType && matchesSearch;
        });

      res.json(searchResults);
    } catch (error) {
      res.status(500).json({ message: "Store search failed" });
    }
  });

  // Privacy Policy API routes - authentication required
  app.get("/api/user/privacy-settings", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      // In production, this would load user's actual privacy settings from database
      const user = await storage.getUser(userId);
      
      const settings = {
        voiceProcessing: user?.privacySettings?.voiceProcessing ?? true,
        dataAnalytics: user?.privacySettings?.dataAnalytics ?? false,
        personalizedRecommendations: user?.privacySettings?.personalizedRecommendations ?? true,
        emailNotifications: user?.privacySettings?.emailNotifications ?? true,
        dataRetention: user?.privacySettings?.dataRetention ?? 'standard'
      };
      
      res.json(settings);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch privacy settings" });
    }
  });

  app.put("/api/user/privacy-settings", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const settings = req.body;
      
      // In production, this would save to user's profile in database
      console.log(`Privacy settings updated for user ${userId}:`, settings);
      // await storage.updateUserPrivacySettings(userId, settings);
      
      res.json({ message: "Privacy settings updated successfully" });
    } catch (error) {
      res.status(500).json({ message: "Failed to update privacy settings" });
    }
  });

  app.post("/api/user/data-export", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userEmail = req.user.claims.email;
      
      // In production, this would:
      // 1. Generate a complete export of user's data (recipes, meal plans, preferences)
      // 2. Create a secure download link with expiration
      // 3. Send an email with the download link
      console.log(`Data export requested for user ${userId} (${userEmail})`);
      
      res.json({ message: "Data export request submitted. You'll receive an email within 48 hours." });
    } catch (error) {
      res.status(500).json({ message: "Failed to process data export request" });
    }
  });

  app.post("/api/user/delete-account", isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const userEmail = req.user.claims.email;
      const { reason } = req.body;
      
      // In production, this would:
      // 1. Queue account for deletion in 30 days (GDPR compliance)
      // 2. Send confirmation email with cancellation option
      // 3. Log deletion reason for product improvement
      console.log(`Account deletion requested for user ${userId} (${userEmail}). Reason:`, reason);
      
      res.json({ message: "Account deletion request submitted. You'll receive confirmation via email." });
    } catch (error) {
      res.status(500).json({ message: "Failed to process account deletion request" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
