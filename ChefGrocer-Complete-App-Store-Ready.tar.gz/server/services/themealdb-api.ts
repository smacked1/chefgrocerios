// TheMealDB API service - Free recipe database with no API key required
export interface MealDBRecipe {
  idMeal: string;
  strMeal: string;
  strCategory: string;
  strArea: string;
  strInstructions: string;
  strMealThumb: string;
  strIngredient1?: string;
  strIngredient2?: string;
  strIngredient3?: string;
  strIngredient4?: string;
  strIngredient5?: string;
  strIngredient6?: string;
  strIngredient7?: string;
  strIngredient8?: string;
  strIngredient9?: string;
  strIngredient10?: string;
  strMeasure1?: string;
  strMeasure2?: string;
  strMeasure3?: string;
  strMeasure4?: string;
  strMeasure5?: string;
  strMeasure6?: string;
  strMeasure7?: string;
  strMeasure8?: string;
  strMeasure9?: string;
  strMeasure10?: string;
}

export interface MealDBResponse {
  meals: MealDBRecipe[] | null;
}

const BASE_URL = 'https://www.themealdb.com/api/json/v1/1';

export class TheMealDBAPI {
  // Search recipes by name
  static async searchByName(query: string): Promise<MealDBRecipe[]> {
    try {
      const response = await fetch(`${BASE_URL}/search.php?s=${encodeURIComponent(query)}`);
      const data: MealDBResponse = await response.json();
      return data.meals || [];
    } catch (error) {
      console.error('TheMealDB search error:', error);
      return [];
    }
  }

  // Get random recipe
  static async getRandomRecipe(): Promise<MealDBRecipe | null> {
    try {
      const response = await fetch(`${BASE_URL}/random.php`);
      const data: MealDBResponse = await response.json();
      return data.meals?.[0] || null;
    } catch (error) {
      console.error('TheMealDB random recipe error:', error);
      return null;
    }
  }

  // Get recipe by ID
  static async getRecipeById(id: string): Promise<MealDBRecipe | null> {
    try {
      const response = await fetch(`${BASE_URL}/lookup.php?i=${id}`);
      const data: MealDBResponse = await response.json();
      return data.meals?.[0] || null;
    } catch (error) {
      console.error('TheMealDB lookup error:', error);
      return null;
    }
  }

  // Filter by ingredient
  static async filterByIngredient(ingredient: string): Promise<MealDBRecipe[]> {
    try {
      const response = await fetch(`${BASE_URL}/filter.php?i=${encodeURIComponent(ingredient)}`);
      const data: MealDBResponse = await response.json();
      return data.meals || [];
    } catch (error) {
      console.error('TheMealDB ingredient filter error:', error);
      return [];
    }
  }

  // Filter by category
  static async filterByCategory(category: string): Promise<MealDBRecipe[]> {
    try {
      const response = await fetch(`${BASE_URL}/filter.php?c=${encodeURIComponent(category)}`);
      const data: MealDBResponse = await response.json();
      return data.meals || [];
    } catch (error) {
      console.error('TheMealDB category filter error:', error);
      return [];
    }
  }

  // Filter by cuisine/area
  static async filterByArea(area: string): Promise<MealDBRecipe[]> {
    try {
      const response = await fetch(`${BASE_URL}/filter.php?a=${encodeURIComponent(area)}`);
      const data: MealDBResponse = await response.json();
      return data.meals || [];
    } catch (error) {
      console.error('TheMealDB area filter error:', error);
      return [];
    }
  }

  // Get all categories
  static async getCategories(): Promise<{ idCategory: string; strCategory: string; strCategoryThumb: string; strCategoryDescription: string; }[]> {
    try {
      const response = await fetch(`${BASE_URL}/categories.php`);
      const data = await response.json();
      return data.categories || [];
    } catch (error) {
      console.error('TheMealDB categories error:', error);
      return [];
    }
  }

  // Get all areas/cuisines
  static async getAreas(): Promise<{ strArea: string; }[]> {
    try {
      const response = await fetch(`${BASE_URL}/list.php?a=list`);
      const data = await response.json();
      return data.meals || [];
    } catch (error) {
      console.error('TheMealDB areas error:', error);
      return [];
    }
  }

  // Get all ingredients
  static async getIngredients(): Promise<{ idIngredient: string; strIngredient: string; strDescription: string; }[]> {
    try {
      const response = await fetch(`${BASE_URL}/list.php?i=list`);
      const data = await response.json();
      return data.meals || [];
    } catch (error) {
      console.error('TheMealDB ingredients error:', error);
      return [];
    }
  }

  // Convert MealDB recipe to our app format
  static convertToAppFormat(meal: MealDBRecipe) {
    // Extract ingredients and measurements
    const ingredients = [];
    for (let i = 1; i <= 20; i++) {
      const ingredient = meal[`strIngredient${i}` as keyof MealDBRecipe];
      const measure = meal[`strMeasure${i}` as keyof MealDBRecipe];
      
      if (ingredient && ingredient.trim()) {
        ingredients.push({
          name: ingredient.trim(),
          amount: measure?.trim() || '1',
          unit: ''
        });
      }
    }

    return {
      id: meal.idMeal,
      title: meal.strMeal,
      name: meal.strMeal,
      description: meal.strInstructions?.substring(0, 200) + '...' || '',
      instructions: meal.strInstructions || '',
      image: meal.strMealThumb,
      category: meal.strCategory,
      cuisine: meal.strArea,
      ingredients,
      readyInMinutes: 30, // Default since TheMealDB doesn't provide cook time
      servings: 4, // Default
      source: 'TheMealDB'
    };
  }
}