import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface FoodSearchResult {
  id: string;
  name: string;
  category: string;
  subCategory: string;
  brand?: string;
  servingSize: string;
  calories: number;
  nutritionInfo: {
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    sugar: number;
    sodium: number;
    cholesterol?: number;
    potassium?: number;
    vitaminA?: number;
    vitaminC?: number;
    calcium?: number;
    iron?: number;
  };
  allergens: string[];
  dietaryTags: string[];
  averagePrice?: string;
  seasonality?: string;
  preparationTips: string[];
  commonUses: string[];
}

export interface DeliveryOption {
  serviceName: string;
  restaurantName: string;
  itemName: string;
  description: string;
  price: string;
  deliveryTime: string;
  deliveryFee: string;
  doordashUrl?: string;
  grubhubUrl?: string;
  ubereatsUrl?: string;
  calories?: number;
  rating?: number;
  reviews?: number;
}

export async function searchFoodDatabase(query: string, filters?: {
  category?: string;
  dietaryTags?: string[];
  maxCalories?: number;
  allergenFree?: string[];
}): Promise<FoodSearchResult[]> {
  try {
    const filterText = filters ? `
    Filters:
    ${filters.category ? `- Category: ${filters.category}` : ''}
    ${filters.dietaryTags?.length ? `- Dietary requirements: ${filters.dietaryTags.join(', ')}` : ''}
    ${filters.maxCalories ? `- Maximum calories: ${filters.maxCalories}` : ''}
    ${filters.allergenFree?.length ? `- Must be free from: ${filters.allergenFree.join(', ')}` : ''}
    ` : '';

    const prompt = `Search for foods matching: "${query}"
    ${filterText}

    Provide detailed nutrition information for each food item found. Include comprehensive nutritional data, allergen information, dietary tags, preparation tips, and common uses.

    Respond with JSON in this format:
    {
      "foods": [
        {
          "id": "unique_id",
          "name": "Food Name",
          "category": "fruits|vegetables|proteins|grains|dairy|nuts|oils|beverages|snacks|condiments",
          "subCategory": "more specific category",
          "brand": "Brand Name (if applicable)",
          "servingSize": "1 cup, 100g, 1 medium, etc.",
          "calories": number,
          "nutritionInfo": {
            "protein": number,
            "carbs": number,
            "fat": number,
            "fiber": number,
            "sugar": number,
            "sodium": number,
            "cholesterol": number,
            "potassium": number,
            "vitaminA": number,
            "vitaminC": number,
            "calcium": number,
            "iron": number
          },
          "allergens": ["milk", "eggs", "fish", "shellfish", "nuts", "peanuts", "wheat", "soy"],
          "dietaryTags": ["vegan", "vegetarian", "gluten_free", "keto", "paleo", "low_carb", "high_protein"],
          "averagePrice": "$X.XX per unit",
          "seasonality": "spring|summer|fall|winter|year_round",
          "preparationTips": ["tip1", "tip2"],
          "commonUses": ["use1", "use2"]
        }
      ]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a comprehensive food database expert with access to detailed nutritional information for thousands of foods. Provide accurate, detailed nutritional data based on USDA standards and common food databases."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{"foods": []}');
    return result.foods || [];
  } catch (error) {
    console.error("Failed to search food database:", error);
    throw new Error("Failed to search food database: " + (error as Error).message);
  }
}

export async function findDeliveryOptions(foodItems: string[], location: string): Promise<DeliveryOption[]> {
  try {
    const prompt = `Find delivery options for these food items: ${foodItems.join(', ')}
    Location: ${location}

    Search for restaurants and delivery services that offer these items. Include DoorDash, Grubhub, Uber Eats, and other popular delivery platforms. Provide realistic pricing, delivery times, and service information.

    Respond with JSON in this format:
    {
      "deliveryOptions": [
        {
          "serviceName": "DoorDash|Grubhub|Uber Eats|Postmates",
          "restaurantName": "Restaurant Name",
          "itemName": "Menu Item Name",
          "description": "Brief description of the item",
          "price": "$XX.XX",
          "deliveryTime": "25-40 min",
          "deliveryFee": "$X.XX",
          "doordashUrl": "https://doordash.com/...",
          "grubhubUrl": "https://grubhub.com/...",
          "ubereatsUrl": "https://ubereats.com/...",
          "calories": number,
          "rating": 4.5,
          "reviews": 1234
        }
      ]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a delivery service expert with access to real-time information about restaurants and food delivery options. Provide accurate delivery information with realistic pricing and timing."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{"deliveryOptions": []}');
    return result.deliveryOptions || [];
  } catch (error) {
    console.error("Failed to find delivery options:", error);
    throw new Error("Failed to find delivery options: " + (error as Error).message);
  }
}

export async function getDetailedNutrition(foodName: string, quantity: string): Promise<{
  name: string;
  quantity: string;
  calories: number;
  macros: {
    protein: number;
    carbs: number;
    fat: number;
  };
  micros: {
    fiber: number;
    sugar: number;
    sodium: number;
    cholesterol: number;
    potassium: number;
    vitaminA: number;
    vitaminC: number;
    calcium: number;
    iron: number;
  };
  dailyValues: {
    protein: number;
    fiber: number;
    vitaminA: number;
    vitaminC: number;
    calcium: number;
    iron: number;
  };
}> {
  try {
    const prompt = `Provide detailed nutritional information for: ${quantity} of ${foodName}

    Include comprehensive macro and micronutrient data, plus daily value percentages based on a 2000-calorie diet.

    Respond with JSON in this format:
    {
      "name": "${foodName}",
      "quantity": "${quantity}",
      "calories": number,
      "macros": {
        "protein": number,
        "carbs": number,
        "fat": number
      },
      "micros": {
        "fiber": number,
        "sugar": number,
        "sodium": number,
        "cholesterol": number,
        "potassium": number,
        "vitaminA": number,
        "vitaminC": number,
        "calcium": number,
        "iron": number
      },
      "dailyValues": {
        "protein": number,
        "fiber": number,
        "vitaminA": number,
        "vitaminC": number,
        "calcium": number,
        "iron": number
      }
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a nutrition expert providing detailed nutritional analysis based on USDA food composition databases. Provide accurate nutritional data and daily value percentages."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{}');
    return result;
  } catch (error) {
    console.error("Failed to get detailed nutrition:", error);
    throw new Error("Failed to get detailed nutrition: " + (error as Error).message);
  }
}

export async function findSimilarFoods(foodName: string, preferences?: {
  healthier?: boolean;
  cheaper?: boolean;
  sameFlavor?: boolean;
  dietaryRestrictions?: string[];
}): Promise<{
  name: string;
  reason: string;
  nutritionComparison: string;
  priceComparison: string;
  availabilityInfo: string;
}[]> {
  try {
    const preferenceText = preferences ? `
    Preferences:
    ${preferences.healthier ? '- Find healthier alternatives' : ''}
    ${preferences.cheaper ? '- Find more affordable options' : ''}
    ${preferences.sameFlavor ? '- Maintain similar taste profile' : ''}
    ${preferences.dietaryRestrictions?.length ? `- Must meet dietary restrictions: ${preferences.dietaryRestrictions.join(', ')}` : ''}
    ` : '';

    const prompt = `Find similar food alternatives to: ${foodName}
    ${preferenceText}

    Provide detailed comparisons including nutritional benefits, price differences, and availability information.

    Respond with JSON in this format:
    {
      "alternatives": [
        {
          "name": "Alternative Food Name",
          "reason": "Why this is a good alternative",
          "nutritionComparison": "Detailed nutrition comparison",
          "priceComparison": "Price comparison details",
          "availabilityInfo": "Where to find this alternative"
        }
      ]
    }`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        {
          role: "system",
          content: "You are a food substitution expert who helps people find better alternatives to foods based on their preferences and dietary needs."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      response_format: { type: "json_object" }
    });

    const result = JSON.parse(response.choices[0].message.content || '{"alternatives": []}');
    return result.alternatives || [];
  } catch (error) {
    console.error("Failed to find similar foods:", error);
    throw new Error("Failed to find similar foods: " + (error as Error).message);
  }
}