import { z } from 'zod';

// USDA FoodData Central API types
export const USDAFoodSchema = z.object({
  fdcId: z.number(),
  description: z.string(),
  dataType: z.string().optional(),
  brandOwner: z.string().optional(),
  brandName: z.string().optional(),
  ingredients: z.string().optional(),
  foodNutrients: z.array(z.object({
    nutrient: z.object({
      id: z.number(),
      number: z.string(),
      name: z.string(),
      unitName: z.string()
    }),
    amount: z.number()
  })).optional(),
  foodCategory: z.object({
    id: z.number(),
    code: z.string(),
    description: z.string()
  }).optional()
});

export const USDASearchResultSchema = z.object({
  foods: z.array(USDAFoodSchema),
  totalHits: z.number(),
  currentPage: z.number(),
  totalPages: z.number()
});

export type USDAFood = z.infer<typeof USDAFoodSchema>;
export type USDASearchResult = z.infer<typeof USDASearchResultSchema>;

const USDA_BASE_URL = 'https://api.nal.usda.gov/fdc/v1';

export class USDAFoodDataService {
  private apiKey: string;

  constructor(apiKey?: string) {
    this.apiKey = apiKey || process.env.USDA_API_KEY || '';
  }

  private async makeRequest(endpoint: string, params: Record<string, any> = {}) {
    if (!this.apiKey) {
      throw new Error('USDA API key is required. Please set USDA_API_KEY environment variable.');
    }

    const url = new URL(`${USDA_BASE_URL}${endpoint}`);
    url.searchParams.append('api_key', this.apiKey);
    
    Object.entries(params).forEach(([key, value]) => {
      if (value !== undefined && value !== null) {
        url.searchParams.append(key, value.toString());
      }
    });

    const response = await fetch(url.toString());
    
    if (!response.ok) {
      throw new Error(`USDA API error: ${response.status} ${response.statusText}`);
    }

    return response.json();
  }

  async searchFoods(query: string, pageSize: number = 25, pageNumber: number = 1): Promise<USDASearchResult> {
    try {
      const data = await this.makeRequest('/foods/search', {
        query,
        pageSize,
        pageNumber
      });
      
      return USDASearchResultSchema.parse(data);
    } catch (error) {
      console.error('Error searching USDA foods:', error);
      throw error;
    }
  }

  async getFoodById(fdcId: number): Promise<USDAFood> {
    try {
      const data = await this.makeRequest(`/food/${fdcId}`);
      return USDAFoodSchema.parse(data);
    } catch (error) {
      console.error('Error fetching USDA food by ID:', error);
      throw error;
    }
  }

  async getFoodsByIds(fdcIds: number[]): Promise<USDAFood[]> {
    try {
      const data = await this.makeRequest('/foods', {
        fdcIds: fdcIds.join(',')
      });
      
      if (Array.isArray(data)) {
        return data.map(food => USDAFoodSchema.parse(food));
      }
      
      return [];
    } catch (error) {
      console.error('Error fetching USDA foods by IDs:', error);
      throw error;
    }
  }

  // Convert USDA nutrition data to our app's format
  formatNutritionInfo(foodNutrients: USDAFood['foodNutrients']): {
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
    sugar: number;
    sodium: number;
    cholesterol?: number;
    calcium?: number;
    iron?: number;
    vitaminC?: number;
    vitaminA?: number;
  } {
    if (!foodNutrients) return {
      protein: 0, carbs: 0, fat: 0, fiber: 0, sugar: 0, sodium: 0
    };

    const nutritionMap: Record<string, keyof ReturnType<typeof this.formatNutritionInfo>> = {
      '203': 'protein',      // Protein (g)
      '205': 'carbs',        // Carbohydrate, by difference (g)
      '204': 'fat',          // Total lipid (fat) (g)
      '291': 'fiber',        // Fiber, total dietary (g)
      '269': 'sugar',        // Sugars, total including NLEA (g)
      '307': 'sodium',       // Sodium, Na (mg)
      '601': 'cholesterol',  // Cholesterol (mg)
      '301': 'calcium',      // Calcium, Ca (mg)
      '303': 'iron',         // Iron, Fe (mg)
      '401': 'vitaminC',     // Vitamin C, total ascorbic acid (mg)
      '320': 'vitaminA'      // Vitamin A, RAE (µg)
    };

    const nutrition: any = {
      protein: 0, carbs: 0, fat: 0, fiber: 0, sugar: 0, sodium: 0
    };

    foodNutrients.forEach(nutrient => {
      const key = nutritionMap[nutrient.nutrient.number];
      if (key) {
        nutrition[key] = Math.round((nutrient.amount || 0) * 100) / 100;
      }
    });

    return nutrition;
  }

  // Enhanced search with nutrition filtering
  async searchFoodsWithNutrition(
    query: string, 
    options: {
      maxCalories?: number;
      minProtein?: number;
      allergenFree?: string[];
      dietaryTags?: string[];
      pageSize?: number;
      pageNumber?: number;
    } = {}
  ): Promise<{
    foods: Array<USDAFood & { 
      calories: number; 
      nutritionInfo: ReturnType<typeof this.formatNutritionInfo>;
      allergens: string[];
      dietaryTags: string[];
    }>;
    totalHits: number;
    currentPage: number;
    totalPages: number;
  }> {
    const searchResult = await this.searchFoods(
      query, 
      options.pageSize || 25, 
      options.pageNumber || 1
    );

    const enhancedFoods = searchResult.foods.map(food => {
      const nutritionInfo = this.formatNutritionInfo(food.foodNutrients);
      const calories = this.calculateCalories(nutritionInfo);
      
      return {
        ...food,
        calories,
        nutritionInfo,
        allergens: this.extractAllergens(food.ingredients || ''),
        dietaryTags: this.extractDietaryTags(food.ingredients || '', nutritionInfo)
      };
    }).filter(food => {
      // Apply filters
      if (options.maxCalories && food.calories > options.maxCalories) return false;
      if (options.minProtein && food.nutritionInfo.protein < options.minProtein) return false;
      if (options.allergenFree && options.allergenFree.some(allergen => 
        food.allergens.includes(allergen.toLowerCase())
      )) return false;
      
      return true;
    });

    return {
      foods: enhancedFoods,
      totalHits: searchResult.totalHits,
      currentPage: searchResult.currentPage,
      totalPages: searchResult.totalPages
    };
  }

  private calculateCalories(nutrition: ReturnType<typeof this.formatNutritionInfo>): number {
    // 4 calories per gram of protein and carbs, 9 calories per gram of fat
    return Math.round((nutrition.protein * 4) + (nutrition.carbs * 4) + (nutrition.fat * 9));
  }

  private extractAllergens(ingredients: string): string[] {
    const allergens: string[] = [];
    const ingredientsLower = ingredients.toLowerCase();
    
    const allergenMap = {
      'milk': ['milk', 'dairy', 'lactose', 'whey', 'casein'],
      'eggs': ['egg', 'albumin'],
      'fish': ['fish', 'salmon', 'tuna', 'cod'],
      'shellfish': ['shrimp', 'crab', 'lobster', 'shellfish'],
      'tree nuts': ['almond', 'walnut', 'pecan', 'cashew', 'pistachio'],
      'peanuts': ['peanut'],
      'wheat': ['wheat', 'gluten'],
      'soy': ['soy', 'soybean']
    };

    Object.entries(allergenMap).forEach(([allergen, keywords]) => {
      if (keywords.some(keyword => ingredientsLower.includes(keyword))) {
        allergens.push(allergen);
      }
    });

    return allergens;
  }

  private extractDietaryTags(ingredients: string, nutrition: ReturnType<typeof this.formatNutritionInfo>): string[] {
    const tags: string[] = [];
    const ingredientsLower = ingredients.toLowerCase();

    // Basic dietary classifications
    if (!ingredientsLower.includes('meat') && 
        !ingredientsLower.includes('chicken') && 
        !ingredientsLower.includes('beef') && 
        !ingredientsLower.includes('pork')) {
      tags.push('vegetarian');
    }

    if (!ingredientsLower.includes('milk') && 
        !ingredientsLower.includes('egg') && 
        !ingredientsLower.includes('dairy')) {
      tags.push('vegan');
    }

    if (!ingredientsLower.includes('wheat') && 
        !ingredientsLower.includes('gluten')) {
      tags.push('gluten-free');
    }

    // Nutritional tags
    if (nutrition.protein > 15) tags.push('high-protein');
    if (nutrition.fiber > 5) tags.push('high-fiber');
    if (nutrition.sodium < 140) tags.push('low-sodium');
    if (nutrition.fat < 3) tags.push('low-fat');

    return tags;
  }
}

export const usdaService = new USDAFoodDataService();