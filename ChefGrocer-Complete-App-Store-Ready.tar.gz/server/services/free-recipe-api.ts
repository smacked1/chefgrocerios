// Enhanced Free Recipe API service combining multiple free sources
import { TheMealDBAPI, MealDBRecipe } from './themealdb-api';

export interface FreeRecipeSearchOptions {
  diet?: string;
  cuisine?: string;
  maxReadyTime?: number;
  number?: number;
  offset?: number;
  includeIngredients?: boolean;
}

export interface FreeRecipe {
  id: string;
  title: string;
  image: string;
  readyInMinutes: number;
  servings: number;
  instructions: string[];
  ingredients: Array<{
    name: string;
    amount: string;
    unit: string;
  }>;
  cuisine: string;
  category: string;
  dietary: string[];
  source: string;
  sourceUrl?: string;
  nutrition?: {
    calories: number;
    protein: number;
    carbohydrates: number;
    fat: number;
  };
}

export interface FreeRecipeSearchResult {
  results: FreeRecipe[];
  totalResults: number;
  offset: number;
  number: number;
}

export class FreeRecipeAPI {
  // Search recipes using free APIs
  static async searchRecipes(
    query: string, 
    options: FreeRecipeSearchOptions = {}
  ): Promise<FreeRecipeSearchResult> {
    try {
      const results: FreeRecipe[] = [];
      
      // Search TheMealDB
      if (query) {
        const themealdbResults = await TheMealDBAPI.searchByName(query);
        const convertedResults = themealdbResults.map(recipe => 
          this.convertTheMealDBToFreeRecipe(recipe)
        );
        results.push(...convertedResults);
      }

      // Filter by cuisine if specified
      if (options.cuisine && !query) {
        const cuisineResults = await TheMealDBAPI.filterByArea(options.cuisine);
        const convertedResults = cuisineResults.map(recipe => 
          this.convertTheMealDBToFreeRecipe(recipe)
        );
        results.push(...convertedResults);
      }

      // Add random recipes if no specific search
      if (!query && !options.cuisine) {
        const randomRecipes = await this.getMultipleRandomRecipes(options.number || 10);
        results.push(...randomRecipes);
      }

      // Apply filters
      let filteredResults = results;
      
      if (options.diet) {
        filteredResults = this.filterByDiet(filteredResults, options.diet);
      }

      if (options.maxReadyTime) {
        filteredResults = filteredResults.filter(recipe => 
          recipe.readyInMinutes <= options.maxReadyTime!
        );
      }

      // Apply pagination
      const offset = options.offset || 0;
      const number = options.number || 12;
      const paginatedResults = filteredResults.slice(offset, offset + number);

      return {
        results: paginatedResults,
        totalResults: filteredResults.length,
        offset,
        number
      };
    } catch (error) {
      console.error('Free recipe search error:', error);
      return {
        results: [],
        totalResults: 0,
        offset: 0,
        number: 0
      };
    }
  }

  // Get random recipes
  static async getRandomRecipes(count: number = 1): Promise<FreeRecipe[]> {
    const recipes = await this.getMultipleRandomRecipes(count);
    return recipes;
  }

  // Find recipes by ingredients
  static async findRecipesByIngredients(
    ingredients: string[], 
    options: { number?: number } = {}
  ): Promise<FreeRecipe[]> {
    try {
      const results: FreeRecipe[] = [];
      
      // Search for each ingredient individually and combine results
      for (const ingredient of ingredients.slice(0, 3)) { // Limit to 3 ingredients for performance
        const recipes = await TheMealDBAPI.filterByIngredient(ingredient);
        const convertedRecipes = recipes.map(recipe => 
          this.convertTheMealDBToFreeRecipe(recipe)
        );
        results.push(...convertedRecipes);
      }

      // Remove duplicates and limit results
      const uniqueRecipes = results.filter((recipe, index, self) => 
        index === self.findIndex(r => r.id === recipe.id)
      );

      return uniqueRecipes.slice(0, options.number || 10);
    } catch (error) {
      console.error('Free recipes by ingredients error:', error);
      return [];
    }
  }

  // Get recipe details by ID
  static async getRecipeInformation(id: string): Promise<FreeRecipe | null> {
    try {
      const recipe = await TheMealDBAPI.getRecipeById(id);
      return recipe ? this.convertTheMealDBToFreeRecipe(recipe) : null;
    } catch (error) {
      console.error('Free recipe information error:', error);
      return null;
    }
  }

  // Get multiple random recipes
  private static async getMultipleRandomRecipes(count: number): Promise<FreeRecipe[]> {
    const recipes: FreeRecipe[] = [];
    const promises = Array(Math.min(count, 20)).fill(null).map(() => 
      TheMealDBAPI.getRandomRecipe()
    );
    
    const results = await Promise.allSettled(promises);
    
    for (const result of results) {
      if (result.status === 'fulfilled' && result.value) {
        const converted = this.convertTheMealDBToFreeRecipe(result.value);
        // Avoid duplicates
        if (!recipes.find(r => r.id === converted.id)) {
          recipes.push(converted);
        }
      }
    }
    
    return recipes;
  }

  // Convert TheMealDB recipe to our format
  private static convertTheMealDBToFreeRecipe(mealDBRecipe: MealDBRecipe): FreeRecipe {
    const ingredients = [];
    
    // Extract ingredients and measurements
    for (let i = 1; i <= 20; i++) {
      const ingredient = mealDBRecipe[`strIngredient${i}` as keyof MealDBRecipe] as string;
      const measure = mealDBRecipe[`strMeasure${i}` as keyof MealDBRecipe] as string;
      
      if (ingredient && ingredient.trim()) {
        ingredients.push({
          name: ingredient.trim(),
          amount: measure ? measure.trim() : '1',
          unit: this.extractUnit(measure)
        });
      }
    }

    // Parse instructions
    const instructions = mealDBRecipe.strInstructions
      ? mealDBRecipe.strInstructions.split(/\r\n|\n|\r/).filter(step => step.trim())
      : [];

    // Determine dietary information
    const dietary = this.getDietaryInfo(mealDBRecipe, ingredients);

    return {
      id: mealDBRecipe.idMeal,
      title: mealDBRecipe.strMeal,
      image: mealDBRecipe.strMealThumb,
      readyInMinutes: this.estimateCookTime(ingredients.length, instructions.length),
      servings: 4, // Default serving size
      instructions,
      ingredients,
      cuisine: mealDBRecipe.strArea || 'International',
      category: mealDBRecipe.strCategory || 'Main Course',
      dietary,
      source: 'TheMealDB',
      sourceUrl: `https://www.themealdb.com/meal/${mealDBRecipe.idMeal}`,
      nutrition: this.estimateNutrition(ingredients, mealDBRecipe.strCategory)
    };
  }

  // Extract unit from measurement string
  private static extractUnit(measure?: string): string {
    if (!measure) return 'piece';
    
    const unitMap: { [key: string]: string } = {
      'cup': 'cup',
      'cups': 'cup',
      'tsp': 'tsp',
      'tbsp': 'tbsp',
      'tablespoon': 'tbsp',
      'teaspoon': 'tsp',
      'lb': 'lb',
      'lbs': 'lb',
      'oz': 'oz',
      'g': 'g',
      'kg': 'kg',
      'ml': 'ml',
      'l': 'l',
      'pint': 'pint',
      'quart': 'quart'
    };

    const lowerMeasure = measure.toLowerCase();
    for (const [key, value] of Object.entries(unitMap)) {
      if (lowerMeasure.includes(key)) {
        return value;
      }
    }
    
    return 'piece';
  }

  // Estimate cooking time based on complexity
  private static estimateCookTime(ingredientCount: number, instructionCount: number): number {
    const baseTime = 20;
    const ingredientTime = ingredientCount * 2;
    const instructionTime = instructionCount * 3;
    
    return Math.min(Math.max(baseTime + ingredientTime + instructionTime, 15), 120);
  }

  // Get dietary information
  private static getDietaryInfo(recipe: MealDBRecipe, ingredients: any[]): string[] {
    const dietary: string[] = [];
    
    // Check for common dietary restrictions based on ingredients
    const ingredientNames = ingredients.map(ing => ing.name.toLowerCase()).join(' ');
    
    if (!ingredientNames.includes('meat') && 
        !ingredientNames.includes('chicken') && 
        !ingredientNames.includes('beef') && 
        !ingredientNames.includes('pork') && 
        !ingredientNames.includes('fish') && 
        !ingredientNames.includes('salmon') &&
        !ingredientNames.includes('tuna')) {
      dietary.push('vegetarian');
    }
    
    if (!ingredientNames.includes('milk') && 
        !ingredientNames.includes('cheese') && 
        !ingredientNames.includes('butter') && 
        !ingredientNames.includes('cream') &&
        !ingredientNames.includes('yogurt')) {
      dietary.push('dairy-free');
    }
    
    if (!ingredientNames.includes('flour') && 
        !ingredientNames.includes('bread') && 
        !ingredientNames.includes('pasta') &&
        !ingredientNames.includes('wheat')) {
      dietary.push('gluten-free');
    }

    return dietary;
  }

  // Estimate nutrition based on ingredients and category
  private static estimateNutrition(ingredients: any[], category?: string): {
    calories: number;
    protein: number;
    carbohydrates: number;
    fat: number;
  } {
    // Basic nutrition estimation based on category and ingredient count
    const baseNutrition = {
      'Beef': { calories: 400, protein: 35, carbohydrates: 20, fat: 20 },
      'Chicken': { calories: 350, protein: 40, carbohydrates: 15, fat: 15 },
      'Seafood': { calories: 300, protein: 35, carbohydrates: 10, fat: 12 },
      'Vegetarian': { calories: 250, protein: 15, carbohydrates: 40, fat: 8 },
      'Pasta': { calories: 450, protein: 15, carbohydrates: 60, fat: 15 },
      'Dessert': { calories: 500, protein: 8, carbohydrates: 70, fat: 20 },
      'Breakfast': { calories: 300, protein: 20, carbohydrates: 35, fat: 12 }
    };

    const defaultNutrition = { calories: 350, protein: 25, carbohydrates: 30, fat: 15 };
    
    return baseNutrition[category as keyof typeof baseNutrition] || defaultNutrition;
  }

  // Filter recipes by diet
  private static filterByDiet(recipes: FreeRecipe[], diet: string): FreeRecipe[] {
    const dietMap: { [key: string]: string[] } = {
      'vegetarian': ['vegetarian'],
      'vegan': ['vegetarian', 'dairy-free'],
      'gluten-free': ['gluten-free'],
      'dairy-free': ['dairy-free'],
      'keto': ['gluten-free'], // Simplified for demo
      'paleo': ['gluten-free', 'dairy-free']
    };

    const requiredDietary = dietMap[diet.toLowerCase()];
    if (!requiredDietary) return recipes;

    return recipes.filter(recipe => 
      requiredDietary.every(dietary => recipe.dietary.includes(dietary))
    );
  }
}

export const freeRecipeService = new FreeRecipeAPI();