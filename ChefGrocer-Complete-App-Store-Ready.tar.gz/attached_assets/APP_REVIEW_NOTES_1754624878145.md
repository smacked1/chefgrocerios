App Review Notes — ChefGrocer
Last updated: Aug 8, 2025

Guidance for App Review team:

- ChefGrocer uses server-side AI services (Google Gemini and OpenAI) to generate recipe suggestions, meal plans, and to process short audio voice commands. All AI requests are processed on our servers and API keys are never included in the app binary or client bundle.

- Audio data: short audio clips used only for voice commands are uploaded and processed; we do not store raw audio longer than necessary. Users can disable voice features in settings. Privacy policy: <PRIVACY_POLICY_URL> (please replace with hosted URL before submission).

- Permissions: The app requests microphone access for voice commands and camera access for barcode scanning. Info.plist usage descriptions are included in the binary.

- Data handling: dynamic API responses (user-specific content) are NOT cached in the service worker to avoid storing personal content offline. Only static assets are cached for PWA offline support.

- Security: Production builds should set ENABLE_AUTH=true to require user authentication and protect saved data. AI endpoints are rate-limited to prevent abusive usage.

If the reviewer needs any test accounts or additional details, please contact: privacy@your-domain.com
