TestFlight Checklist — ChefGrocer
Last updated: Aug 8, 2025

1. Build & upload the iOS archive to App Store Connect.
2. Invite testers or create an internal testing group.
3. On device (iPhone):
   - Install TestFlight build.
   - Confirm microphone permission prompt appears when using voice features.
   - Turn OFF voice features in settings and verify no audio recording/upload occurs.
   - Test voice commands: say "Add 2 apples to my grocery list" and verify correct parsing.
   - Test AI flows: generate a meal plan (7 days) and ensure responses return and UI shows AIDisclosure.
   - Test offline behavior: disable network and attempt to access recipes — static content should still load; API calls should fail gracefully with a friendly message.
   - Test sign-in flows (if ENABLE_AUTH=true): sign up, sign in, sign out.
   - Test purchases/payments flows (if enabled): create a test subscription using Apple sandbox.
4. Confirm no API keys appear in client bundle (build the app and inspect the JS bundle).
5. Check crash logs and analytics for obvious runtime errors.
6. Report any issues and iterate before public submission.
