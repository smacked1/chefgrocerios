import puppeteer from 'puppeteer';
import ffmpeg from 'fluent-ffmpeg';
import fs from 'fs';
import path from 'path';

class AppStoreVideoCreator {
    constructor() {
        this.outputDir = './video-frames';
        this.videoPath = './ChefGrocer-App-Preview.mp4';
        this.frames = this.getFrameDefinitions();
    }

    async createVideo() {
        console.log('🎬 Creating ChefGrocer App Store Preview Video...');
        
        // Create output directory
        if (!fs.existsSync(this.outputDir)) {
            fs.mkdirSync(this.outputDir);
        }

        // Launch browser
        const browser = await puppeteer.launch({
            headless: true,
            args: ['--no-sandbox', '--disable-setuid-sandbox']
        });

        try {
            const page = await browser.newPage();
            await page.setViewport({ width: 430, height: 932 });

            // Generate each frame
            for (let i = 0; i < 30; i++) {
                console.log(`📱 Generating frame ${i + 1}/30...`);
                await this.generateFrame(page, i);
            }

            console.log('🎞️ Combining frames into video...');
            await this.combineFramesToVideo();
            
            console.log('✅ Video created successfully: ChefGrocer-App-Preview.mp4');
            
        } finally {
            await browser.close();
        }
    }

    async generateFrame(page, frameIndex) {
        const frame = this.frames[frameIndex];
        
        const html = `
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { margin: 0; font-family: -apple-system, BlinkMacSystemFont, sans-serif; }
                .phone { width: 430px; height: 932px; background: #000; border-radius: 50px; padding: 8px; }
                .screen { width: 414px; height: 916px; background: white; border-radius: 42px; overflow: hidden; }
                .status-bar { height: 44px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                             display: flex; justify-content: space-between; align-items: center; 
                             padding: 0 20px; color: white; font-weight: 600; }
                .content { height: 872px; ${frame.background || ''} }
                .hero { background: linear-gradient(135deg, #4f46e5 0%, #7c3aed 50%, #ec4899 100%); 
                       color: white; height: 100%; display: flex; flex-direction: column; 
                       justify-content: center; align-items: center; text-align: center; padding: 40px; }
                .voice-dot { width: 16px; height: 16px; background: #ef4444; border-radius: 50%; 
                            animation: pulse 1.5s infinite; margin-right: 8px; }
                @keyframes pulse { 0%, 100% { opacity: 1; transform: scale(1); } 
                                  50% { opacity: 0.7; transform: scale(1.1); } }
                .card { background: white; border-radius: 16px; padding: 20px; margin: 16px; 
                       box-shadow: 0 8px 24px rgba(0,0,0,0.1); }
                .recipe-img { height: 160px; background: linear-gradient(135deg, #f97316, #ec4899); 
                             display: flex; align-items: center; justify-content: center; 
                             font-size: 4rem; border-radius: 16px 16px 0 0; }
                .store-header { display: flex; justify-content: space-between; align-items: start; margin-bottom: 12px; }
                .price-card { border-radius: 20px; padding: 24px; margin: 16px; text-align: center; color: white; }
                .premium-bg { background: linear-gradient(135deg, #22c55e, #3b82f6); }
                .lifetime-bg { background: linear-gradient(135deg, #9333ea, #ec4899); }
                .btn { background: #3b82f6; color: white; padding: 8px 16px; border-radius: 16px; 
                      text-align: center; font-weight: 600; margin-top: 12px; }
                .white-btn { background: white; color: #22c55e; }
            </style>
        </head>
        <body>
            <div class="phone">
                <div class="screen">
                    <div class="status-bar">
                        <span>9:41</span>
                        <span>${frame.title}</span>
                        <span>100%</span>
                    </div>
                    <div class="content">
                        ${frame.content}
                    </div>
                </div>
            </div>
        </body>
        </html>`;

        await page.setContent(html);
        await page.screenshot({
            path: `${this.outputDir}/frame-${String(frameIndex + 1).padStart(2, '0')}.png`,
            type: 'png'
        });
    }

    async combineFramesToVideo() {
        return new Promise((resolve, reject) => {
            ffmpeg()
                .input(`${this.outputDir}/frame-%02d.png`)
                .inputFPS(1)
                .videoCodec('libx264')
                .outputOptions([
                    '-pix_fmt yuv420p',
                    '-r 30'
                ])
                .size('430x932')
                .duration(30)
                .output(this.videoPath)
                .on('end', () => {
                    console.log('✅ Video processing completed');
                    // Clean up frames
                    this.cleanupFrames();
                    resolve();
                })
                .on('error', (err) => {
                    console.error('❌ Video processing failed:', err);
                    reject(err);
                })
                .run();
        });
    }

    cleanupFrames() {
        if (fs.existsSync(this.outputDir)) {
            fs.readdirSync(this.outputDir).forEach(file => {
                fs.unlinkSync(path.join(this.outputDir, file));
            });
            fs.rmdirSync(this.outputDir);
        }
    }

    getFrameDefinitions() {
        return [
            // Hero frames (0-4)
            { title: 'ChefGrocer', content: '<div class="hero"><div style="font-size: 6rem; margin-bottom: 2rem;">👨‍🍳</div><h1 style="font-size: 3rem; font-weight: bold; margin-bottom: 1rem;">ChefGrocer</h1><p style="font-size: 1.25rem; opacity: 0.9; margin-bottom: 2rem;">Your AI-Powered Kitchen Assistant</p></div>' },
            { title: 'ChefGrocer', content: '<div class="hero"><div style="font-size: 6rem; margin-bottom: 2rem;">👨‍🍳</div><h1 style="font-size: 3rem; font-weight: bold; margin-bottom: 1rem;">ChefGrocer</h1><div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 2rem; padding: 1rem 2rem; display: inline-flex; align-items: center;"><div class="voice-dot"></div><span style="font-weight: 600;">Voice Commands Ready</span></div></div>' },
            { title: 'ChefGrocer', content: '<div class="hero"><div style="font-size: 5rem; margin-bottom: 1.5rem;">🎯</div><h1 style="font-size: 2.5rem; font-weight: bold; margin-bottom: 1rem;">Smart Cooking</h1><p style="font-size: 1.125rem; opacity: 0.9;">AI-Powered Assistance</p></div>' },
            { title: 'ChefGrocer', content: '<div class="hero"><div style="font-size: 5rem; margin-bottom: 1.5rem;">🛒</div><h1 style="font-size: 2.5rem; font-weight: bold; margin-bottom: 1rem;">Smart Shopping</h1><p style="font-size: 1.125rem; opacity: 0.9;">Real Store Locations</p></div>' },
            { title: 'ChefGrocer', content: '<div class="hero"><div style="font-size: 5rem; margin-bottom: 1.5rem;">🎤</div><h1 style="font-size: 2.5rem; font-weight: bold; margin-bottom: 1rem;">Voice Control</h1><p style="font-size: 1.125rem; opacity: 0.9;">Hands-Free Cooking</p></div>' },
            
            // Voice cooking frames (5-9)
            { title: 'Voice Cooking', background: 'background: linear-gradient(to bottom, #f3f4f6, white);', content: '<div style="text-align: center; padding-top: 4rem;"><div style="font-size: 5rem; margin-bottom: 1.5rem;">🎤</div><h1 style="font-size: 2rem; font-weight: bold; color: #1f2937; margin-bottom: 1rem;">Voice Cooking</h1><p style="color: #4b5563; font-size: 1.125rem;">Hands-free AI guidance</p></div>' },
            { title: 'Voice Cooking', background: 'background: linear-gradient(to bottom, #f3f4f6, white);', content: '<div style="padding: 2rem;"><div class="card"><div style="text-align: center;"><div style="background: #fef2f2; border-radius: 1rem; padding: 1rem; display: inline-flex; align-items: center; margin-bottom: 1rem;"><div class="voice-dot"></div><span style="color: #b91c1c; font-weight: 600;">Listening...</span></div></div></div></div>' },
            { title: 'Voice Cooking', background: 'background: linear-gradient(to bottom, #f3f4f6, white);', content: '<div style="padding: 2rem;"><div class="card"><div style="background: #f9fafb; border-radius: 1rem; padding: 1.5rem;"><h3 style="font-weight: bold; margin-bottom: 0.75rem; color: #1f2937;">You said:</h3><p style="color: #374151; font-size: 1.125rem; font-style: italic;">"What\'s the next step?"</p></div></div></div>' },
            { title: 'Voice Cooking', background: 'background: linear-gradient(to bottom, #f3f4f6, white);', content: '<div style="padding: 2rem;"><div class="card"><div style="background: #eff6ff; border-radius: 1rem; padding: 1.5rem;"><h3 style="font-weight: bold; margin-bottom: 0.75rem; color: #1e3a8a;">ChefGrocer says:</h3><p style="color: #1d4ed8; font-size: 1.125rem;">"Add cream and simmer for 3 minutes!"</p></div></div></div>' },
            { title: 'Voice Cooking', background: 'background: linear-gradient(to bottom, #f3f4f6, white);', content: '<div style="padding: 2rem;"><div style="background: #22c55e; color: white; border-radius: 1rem; padding: 1.5rem; text-align: center; margin: 1rem;"><div style="font-size: 2rem; margin-bottom: 0.75rem;">⏰</div><h3 style="font-size: 1.25rem; font-weight: bold; margin-bottom: 0.5rem;">Timer: 2:45</h3><p style="opacity: 0.9;">Simmering cream sauce</p></div></div>' },
            
            // Recipe frames (10-14)
            { title: 'Recipe Discovery', background: 'background: #f9fafb;', content: '<div style="background: white; padding: 1.5rem; border-bottom: 1px solid #e5e7eb;"><h2 style="font-size: 1.5rem; font-weight: bold; margin-bottom: 1rem; color: #1f2937;">500,000+ Recipes</h2><div style="background: #f3f4f6; border-radius: 1rem; padding: 0.75rem; display: flex; align-items: center;"><div style="color: #9ca3af; font-size: 1.25rem; margin-right: 0.75rem;">🔍</div><span style="color: #4b5563;">Search anything...</span></div></div>' },
            { title: 'Recipe Discovery', background: 'background: #f9fafb;', content: '<div style="padding: 1rem;"><div class="card" style="border-radius: 20px; overflow: hidden; margin: 16px;"><div class="recipe-img">🍝</div><div style="padding: 1.25rem;"><h3 style="font-weight: bold; font-size: 1.125rem; margin-bottom: 0.5rem;">Creamy Garlic Pasta</h3><div style="display: flex; font-size: 0.875rem; color: #4b5563; margin-bottom: 0.75rem;"><span style="margin-right: 1rem;">⭐ 4.8</span><span style="margin-right: 1rem;">⏱️ 20 min</span><span>💰 $12.50</span></div></div></div></div>' },
            { title: 'Recipe Discovery', background: 'background: #f9fafb;', content: '<div style="padding: 1rem;"><div class="card" style="border-radius: 20px; overflow: hidden; margin: 16px;"><div class="recipe-img">🍝</div><div style="padding: 1.25rem;"><h3 style="font-weight: bold; font-size: 1.125rem; margin-bottom: 0.5rem;">Creamy Garlic Pasta</h3><div style="display: flex; font-size: 0.875rem; color: #4b5563; margin-bottom: 1rem;"><span style="margin-right: 1rem;">⭐ 4.8 (2.1k)</span><span style="margin-right: 1rem;">⏱️ 20 min</span><span>👥 4 servings</span></div><div class="btn">Cook Now</div></div></div></div>' },
            { title: 'Recipe Discovery', background: 'background: #f9fafb;', content: '<div style="padding: 1rem;"><div class="card" style="border-radius: 20px; overflow: hidden; margin: 16px;"><div style="height: 8rem; background: linear-gradient(135deg, #22c55e, #3b82f6); display: flex; align-items: center; justify-content: center; font-size: 3rem; border-radius: 16px 16px 0 0;">🥗</div><div style="padding: 1rem;"><h3 style="font-weight: bold; margin-bottom: 0.5rem;">Mediterranean Bowl</h3><div style="display: flex; font-size: 0.875rem; color: #4b5563; margin-bottom: 0.75rem;"><span style="margin-right: 1rem;">⭐ 4.9</span><span style="margin-right: 1rem;">⏱️ 15 min</span><span>💰 $8.75</span></div><div class="btn">Cook Now</div></div></div></div>' },
            { title: 'Recipe Discovery', background: 'background: #f9fafb;', content: '<div style="padding: 1rem;"><div class="card" style="border-radius: 20px; overflow: hidden; margin: 16px;"><div style="height: 8rem; background: linear-gradient(135deg, #22c55e, #3b82f6); display: flex; align-items: center; justify-content: center; font-size: 3rem; border-radius: 16px 16px 0 0;">🥗</div><div style="padding: 1rem;"><h3 style="font-weight: bold; margin-bottom: 0.5rem;">Mediterranean Bowl</h3><div style="display: flex; font-size: 0.875rem; color: #4b5563; margin-bottom: 0.75rem;"><span style="margin-right: 1rem;">⭐ 4.9</span><span style="margin-right: 1rem;">⏱️ 15 min</span><span>💰 $8.75</span></div><div class="btn">Cook Now</div></div></div></div>' },
            
            // Store locator frames (15-19)
            { title: 'Store Locator', background: 'background: #f9fafb;', content: '<div style="background: white; padding: 1.5rem; border-bottom: 1px solid #e5e7eb;"><h2 style="font-size: 1.5rem; font-weight: bold; margin-bottom: 1rem;">Nearby Stores</h2><div style="display: flex; align-items: center; color: #4b5563;"><span style="margin-right: 0.5rem;">📍</span><span>Real locations via OpenStreetMap</span></div></div>' },
            { title: 'Store Locator', background: 'background: #f9fafb;', content: '<div style="padding: 1rem;"><div class="card"><div class="store-header"><div><h3 style="font-weight: bold; font-size: 1.125rem;">Walmart Supercenter</h3><p style="color: #4b5563;">3405 W Kimberly Rd</p></div><div style="text-align: right;"><div style="font-weight: 600; color: #22c55e;">0.8 miles</div><div style="font-size: 0.75rem; color: #6b7280;">Open 24/7</div></div></div></div></div>' },
            { title: 'Store Locator', background: 'background: #f9fafb;', content: '<div style="padding: 1rem;"><div class="card"><div class="store-header"><div><h3 style="font-weight: bold; font-size: 1.125rem;">Hy-Vee Food Store</h3><p style="color: #4b5563;">1823 E Kimberly Rd</p></div><div style="text-align: right;"><div style="font-weight: 600; color: #22c55e;">1.2 miles</div><div style="font-size: 0.75rem; color: #6b7280;">6am - 11pm</div></div></div><div class="btn">Get Directions</div></div></div>' },
            { title: 'Store Locator', background: 'background: #f9fafb;', content: '<div style="padding: 1rem;"><div class="card"><div class="store-header"><div><h3 style="font-weight: bold; font-size: 1.125rem;">ALDI</h3><p style="color: #4b5563;">2600 W Locust St</p></div><div style="text-align: right;"><div style="font-weight: 600; color: #22c55e;">1.8 miles</div><div style="font-size: 0.75rem; color: #6b7280;">9am - 8pm</div></div></div><div style="display: flex; gap: 0.5rem; margin-bottom: 0.75rem;"><span style="background: #dbeafe; color: #1e40af; font-size: 0.75rem; padding: 0.25rem 0.75rem; border-radius: 1rem;">Supermarket</span><span style="background: #fef3c7; color: #92400e; font-size: 0.75rem; padding: 0.25rem 0.75rem; border-radius: 1rem;">💰 Budget</span></div><div class="btn">Get Directions</div></div></div>' },
            { title: 'Store Locator', background: 'background: #f9fafb;', content: '<div style="padding: 1rem;"><div class="card"><div class="store-header"><div><h3 style="font-weight: bold; font-size: 1.125rem;">ALDI</h3><p style="color: #4b5563;">2600 W Locust St</p></div><div style="text-align: right;"><div style="font-weight: 600; color: #22c55e;">1.8 miles</div><div style="font-size: 0.75rem; color: #6b7280;">9am - 8pm</div></div></div><div style="display: flex; gap: 0.5rem; margin-bottom: 0.75rem;"><span style="background: #dbeafe; color: #1e40af; font-size: 0.75rem; padding: 0.25rem 0.75rem; border-radius: 1rem;">Supermarket</span><span style="background: #fef3c7; color: #92400e; font-size: 0.75rem; padding: 0.25rem 0.75rem; border-radius: 1rem;">💰 Budget</span></div><div class="btn">Get Directions</div></div></div>' },
            
            // Pricing frames (20-24)
            { title: 'Premium Plans', background: 'background: linear-gradient(to bottom, #eef2ff, white);', content: '<div style="text-align: center; padding-top: 2rem;"><div style="font-size: 4rem; margin-bottom: 1rem;">✨</div><h1 style="font-size: 2rem; font-weight: bold; margin-bottom: 0.75rem; color: #1f2937;">Choose Your Plan</h1><p style="color: #4b5563;">Unlock the full potential</p></div>' },
            { title: 'Premium Plans', background: 'background: linear-gradient(to bottom, #eef2ff, white);', content: '<div style="padding: 1rem;"><div class="price-card premium-bg"><h3 style="font-size: 1.5rem; font-weight: bold; margin-bottom: 0.5rem;">Premium</h3><div style="font-size: 2.5rem; font-weight: bold; margin-bottom: 1rem;">$4.99<span style="font-size: 1rem; opacity: 0.75;">/month</span></div></div></div>' },
            { title: 'Premium Plans', background: 'background: linear-gradient(to bottom, #eef2ff, white);', content: '<div style="padding: 1rem;"><div class="price-card premium-bg"><h3 style="font-size: 1.5rem; font-weight: bold; margin-bottom: 0.5rem;">Premium</h3><div style="font-size: 2.5rem; font-weight: bold; margin-bottom: 1rem;">$4.99<span style="font-size: 1rem; opacity: 0.75;">/month</span></div><div style="text-align: left; margin-bottom: 1.5rem; opacity: 0.95;"><div style="margin-bottom: 0.5rem;">✓ Voice cooking guidance</div><div style="margin-bottom: 0.5rem;">✓ AI meal planning</div><div style="margin-bottom: 0.5rem;">✓ Price comparison</div><div>✓ Nutrition tracking</div></div><div class="white-btn">Start Free Trial</div></div></div>' },
            { title: 'Premium Plans', background: 'background: linear-gradient(to bottom, #eef2ff, white);', content: '<div style="padding: 1rem;"><div class="price-card lifetime-bg"><h3 style="font-size: 1.25rem; font-weight: bold; margin-bottom: 0.5rem;">Lifetime Pass</h3><div style="font-size: 2rem; font-weight: bold; margin-bottom: 1rem;">$99.99<span style="font-size: 1rem; opacity: 0.75;"> once</span></div><p style="margin-bottom: 1rem; opacity: 0.9;">All premium features forever!</p><div style="background: white; color: #9333ea; padding: 0.75rem 1.5rem; border-radius: 1rem; font-weight: bold;">Best Value</div></div></div>' },
            { title: 'Premium Plans', background: 'background: linear-gradient(to bottom, #eef2ff, white);', content: '<div style="padding: 1rem;"><div class="price-card lifetime-bg"><h3 style="font-size: 1.25rem; font-weight: bold; margin-bottom: 0.5rem;">Lifetime Pass</h3><div style="font-size: 2rem; font-weight: bold; margin-bottom: 1rem;">$99.99<span style="font-size: 1rem; opacity: 0.75;"> once</span></div><p style="margin-bottom: 1rem; opacity: 0.9;">All premium features forever!</p><div style="background: white; color: #9333ea; padding: 0.75rem 1.5rem; border-radius: 1rem; font-weight: bold;">Best Value</div></div></div>' },
            
            // CTA frames (25-29)
            { title: 'Download Now', content: '<div class="hero"><div style="font-size: 5rem; margin-bottom: 1.5rem;">🚀</div><h1 style="font-size: 2.5rem; font-weight: bold; margin-bottom: 1.5rem;">Start Cooking Smarter</h1></div>' },
            { title: 'Download Now', content: '<div class="hero"><h1 style="font-size: 2.5rem; font-weight: bold; margin-bottom: 2rem;">Start Cooking Smarter</h1><div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 1rem; padding: 1rem 2rem; margin-bottom: 1rem;"><div style="font-size: 1.5rem; font-weight: bold;">500,000+ Recipes</div></div></div>' },
            { title: 'Download Now', content: '<div class="hero"><h1 style="font-size: 2.5rem; font-weight: bold; margin-bottom: 2rem;">Start Cooking Smarter</h1><div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 1rem; padding: 1rem 2rem; margin-bottom: 1rem;"><div style="font-size: 1.5rem; font-weight: bold;">Voice AI Guidance</div></div></div>' },
            { title: 'Download Now', content: '<div class="hero"><h1 style="font-size: 2.5rem; font-weight: bold; margin-bottom: 2rem;">Start Cooking Smarter</h1><div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 1rem; padding: 1rem 2rem; margin-bottom: 1rem;"><div style="font-size: 1.5rem; font-weight: bold;">Real Store Locations</div></div></div>' },
            { title: 'Download Now', content: '<div class="hero"><h1 style="font-size: 2.5rem; font-weight: bold; margin-bottom: 2rem;">Start Cooking Smarter</h1><div style="background: white; color: #9333ea; padding: 1rem 2.5rem; border-radius: 1rem; font-size: 1.25rem; font-weight: bold;">Download ChefGrocer</div></div>' }
        ];
    }
}

// Run the video creator
async function main() {
    try {
        const creator = new AppStoreVideoCreator();
        await creator.createVideo();
    } catch (error) {
        console.error('❌ Error creating video:', error);
        process.exit(1);
    }
}

// Run the video creator
main();